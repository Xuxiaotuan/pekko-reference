from pathlib import Path
import hashlib,json,re,subprocess,tarfile,io,os,shutil,zipfile
repo=Path.cwd();tmp=Path('/tmp/pekko-stage-a-20261019');root=repo/'docs/experiments/2026-10-19-stage-a-convergence';root.mkdir(exist_ok=True)
hashof=lambda data:hashlib.sha256(data).hexdigest()
baseline=json.loads((tmp/'baseline.json').read_text());settings=json.load(open('/tmp/pekko-cdc-stage-a-settings.json'))
assert all((repo/f).is_file() and hashof((repo/f).read_bytes())==h for f,h in baseline['protected'].items())
migrations=[]
for f,h in baseline['migrated'].items():
 dest=f.replace('src/main/scala/','src/test/scala/examples/legacy/');data=(repo/dest).read_bytes();assert hashof(data)==h and not (repo/f).exists()
 migrations.append(dict(before=f,after=dest,sha256=h,lines=len(data.splitlines())))
assert (repo/'pekko-server/src/test/examples/legacy-datafusion/quick-test.sh').read_bytes()==(tmp/'quick-test.sh.before').read_bytes()
jar=repo/'pekko-server/target/scala-2.13/pekko-reference_2.13-0.1.jar'
with zipfile.ZipFile(jar) as z:
 prefixes=[m['before'].split('src/main/scala/')[1][:-6] for m in migrations]
 assert not any(n==p+'.class' or n.startswith(p+'$') for n in z.namelist() for p in prefixes)
 assert 'cn/xuyinyin/magic/workflow/actors/EventSourcedWorkflowActor.class' in z.namelist()
 retained=['cn/xuyinyin/magic/workflow/actors/EventSourcedWorkflowActor.class','cn/xuyinyin/magic/workflow/scheduler/SchedulerCoordinator.class','cn/xuyinyin/magic/workflow/nodes/sources/MySQLCdcSourceNode.class','cn/xuyinyin/magic/workflow/nodes/sinks/MySQLCdcApplySinkNode.class']
 assert all(n in z.namelist() for n in retained)
validation=dict(migrations=migrations,protectedFiles=len(baseline['protected']),protectedMismatches=[],productionJar=dict(file=jar.name,sha256=hashof(jar.read_bytes()),legacyClassesAbsent=True,retainedClasses=retained),binaryBaselineComparison='not claimed: initial pre-change JAR copy selected a stale artifact; only current explicitly named packageBin JAR is asserted',dependencyComparison=json.loads((tmp/'dependency-comparison.json').read_text()),examples=json.loads((tmp/'examples-result.json').read_text()),startup=json.loads((tmp/'startup-result.json').read_text()),aliasStartup=json.loads((tmp/'alias-startup-result.json').read_text()),checks=dict(quickTestPassed=54,fullModulePassed=410,fullModuleAborted=['MySQLPerformanceTest','HealthRoutesSpec','MysqlSqlParserSpec','ComprehensiveCalciteTest'],fullModuleExit=1,isolatedPortSuites=json.loads((tmp/'isolated-tests-result.json').read_text()),isolatedPortTestsPassed=8,realWindowAssertionsPassed=8,realConverged=7,realAutomaticRecoveryFailure=['C2']),limitations=['No capacity or memory/throughput comparison','No DDL, multiple owners, shared reader or protocol change','Calcite full module gate remains evidence_incomplete','Docker build/publish were inspected, not executed'])
(root/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
(root/'preservation-manifest.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2)+'\n')
files={};log=(tmp/'real-eight.log').read_text();runs=dict(re.findall(r'CDC_RECOVERY_WINDOW_OBSERVED scenario=(\w+) evidence=(\S+)',log));assert len(runs)==8
records=[]
for case,folder in runs.items():
 p=Path(folder);env=json.load(open(p/'environment.json'));schema=env['schema']
 e=os.environ.copy();e['MYSQL_PWD']=settings['CDC_WINDOW_MYSQL_PASSWORD']
 r=subprocess.run(['docker','exec','-e','MYSQL_PWD','pekko-cdc-stage-a-20261019','mysqldump','-uroot','--single-transaction','--hex-blob','--set-gtid-purged=OFF','--skip-comments',schema],env=e,capture_output=True);assert r.returncode==0,r.stderr.decode()
 (p/'database-final.sql').write_bytes(r.stdout)
 for f in p.iterdir():
  if f.is_file():files[case+'/'+f.name]=f.read_bytes()
 records.append(dict(scenario=case,runDirectory=p.name,schema=schema,originalBatchSize=env['originalBatchSize'],recoveredBatchSize=env['recoveredBatchSize']))
for f in tmp.iterdir():
 if f.suffix in ('.log','.json','.py','.conf') and f.name not in ('baseline.json',):files['checks/'+f.name]=f.read_bytes()
# Source snapshots for this changed runtime, rather than rewriting an earlier experiment's source manifest.
sources=list((repo/'pekko-server/src/main').rglob('*'))+list((repo/'pekko-server/src/test/scala/examples/legacy').rglob('*.scala'))
old=json.load(open(repo/'docs/experiments/2026-10-19-recovery-windows/source-manifest.json'))
sources += [repo/f for f in old['sourceSha256']]+[repo/'build.sbt',repo/'quick-test.sh']
sourcehash={}
for f in sources:
 if not f.is_file():continue
 rel=str(f.relative_to(repo));data=f.read_bytes();files['source/'+rel]=data;sourcehash[rel]=hashof(data)
source=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),workingTree='Stage A build/source-scope edits plus pre-existing uncommitted recovery probes',productionProtocolReference='65ab5410c32933d0aa3d23510e6c62252d84009b',productionProtocolUnchanged=True,sourceSha256=sourcehash)
(root/'source-manifest.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
image=json.loads(subprocess.check_output(['docker','inspect','pekko-cdc-stage-a-20261019']))[0]
manifest=dict(date='2026-10-19',timezone='UTC test JVMs; Asia/Shanghai build logs',java='Microsoft OpenJDK 17.0.14',container='pekko-cdc-stage-a-20261019',image=image['Image'],containerArguments=image['Config']['Cmd'],formalRuns=records,formalJvms=24,verification='8 observations passed; 7 converged, C2 FAIL_TERMINAL preserved',unchangedMaterials='252 protected files match pre-Stage-A SHA256; see preservation-manifest.json')
(root/'run-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for name in ('source-manifest.json','validation.json','preservation-manifest.json','run-manifest.json'):files[name]=(root/name).read_bytes()
# Same independent verifier and five negative tests as prior run, exact bytes preserved.
for name in ('verify.py','verify_tests.py'):shutil.copyfile(repo/'docs/experiments/2026-10-19-recovery-windows'/name,root/name)
for name,data in files.items():assert settings['CDC_WINDOW_MYSQL_PASSWORD'].encode() not in data,name
inner=json.dumps({'files':{name:hashof(data) for name,data in files.items()}},ensure_ascii=False,indent=2).encode()
with tarfile.open(root/'evidence.tar.gz','w:gz') as a:
 for name,data in list(files.items())+[('manifest.json',inner)]:
  t=tarfile.TarInfo(name);t.size=len(data);t.mode=0o644;a.addfile(t,io.BytesIO(data))
print('Files archived',len(files)+1,'bytes',(root/'evidence.tar.gz').stat().st_size)
