from pathlib import Path
import os,socket,subprocess,time,urllib.request,json,signal
root=Path('/tmp/pekko-stage-a-20261019'); repo=Path.cwd()
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
mode=os.environ.get('SMOKE_MODE','stage')
remote,http=port(),port(); config=root/('alias-startup.conf' if mode=='alias' else 'startup.conf')
config.write_text('include "application.conf"\n'+f'''pekko.remote.artery.canonical.port = {remote}
pekko.cluster.seed-nodes = ["pekko://pekko-cluster-system@127.0.0.1:{remote}"]
http.host = "127.0.0.1"
http.port = {http}
pekko-persistence-jdbc.shared-databases.slick.db.url = "jdbc:h2:file:{root}/{mode}-journal;MODE=MySQL;INIT=RUNSCRIPT FROM 'classpath:db/h2/pekko-persistence-schema.sql'"
''')
env=os.environ.copy();env['JAVA_HOME']='/Users/xujiawei/Library/Java/JavaVirtualMachines/ms-17.0.14/Contents/Home'
mode=os.environ.get('SMOKE_MODE','stage')
if mode=='alias':
 cmd=['sbt','-java-home',env['JAVA_HOME'],'-J-Xmx2G',f'set LocalProject("pekko-server") / Compile / run / javaOptions += "-Dconfig.file={config}"','runServer']
else:cmd=[str(repo/'pekko-server/target/universal/stage/bin/pekko-reference'),f'-Dconfig.file={config}']
results={}; start=time.monotonic()
with (root/f'{mode}-startup.log').open('w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 try:
  while time.monotonic()-start<90 and p.poll() is None:
   for route in ('/health/live','/health/ready','/api/v1/workflows','/api/v1/schedules'):
    if route in results:continue
    try:
     with urllib.request.urlopen(f'http://127.0.0.1:{http}'+route,timeout=2) as r:
      body=r.read().decode();results[route]={'status':r.status,'body':body}
    except Exception:pass
   if len(results)==4:break
   time.sleep(.5)
 finally:
  if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(20)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
result={'mode':mode,'remotePort':remote,'httpPort':http,'responses':results,'elapsedSeconds':round(time.monotonic()-start,2),'controlledStop':True}
(root/('startup-result.json' if mode=='stage' else 'alias-startup-result.json')).write_text(json.dumps(result,indent=2))
print(json.dumps(result))
assert len(results)==4 and all(v['status']==200 for v in results.values())
