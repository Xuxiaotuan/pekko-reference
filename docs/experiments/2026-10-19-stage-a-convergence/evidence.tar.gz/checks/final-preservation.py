from pathlib import Path
import re,json,hashlib,zipfile,tarfile,io
repo=Path.cwd();tmp=Path('/tmp/pekko-stage-a-20261019');root=repo/'docs/experiments/2026-10-19-stage-a-convergence';b=json.load(open(tmp/'baseline.json'));defs=[]
assert all((repo/f).is_file() and hashlib.sha256((repo/f).read_bytes()).hexdigest()==h for f,h in b['protected'].items())
for f,h in b['migrated'].items():
 moved=repo/f.replace('src/main/scala/','src/test/scala/examples/legacy/');data=moved.read_bytes();assert not (repo/f).exists() and hashlib.sha256(data).hexdigest()==h
 s=data.decode();pkg=re.search(r'^package (\S+)',s,re.M).group(1).replace('.','/')
 names=re.findall(r'^(?:(?:private(?:\[[^\]]+\])?|protected(?:\[[^\]]+\])?|sealed|final|abstract|case)\s+)*(?:object|class|trait)\s+(\w+)',s,re.M)
 assert names,f
 for name in names:
  prefix=pkg+'/'+name;assert Path('pekko-server/target/scala-2.13/test-classes',prefix+'.class').exists(),prefix
  defs.append(prefix)
with zipfile.ZipFile('pekko-server/target/scala-2.13/pekko-reference_2.13-0.1.jar') as z:
 names=z.namelist();assert not any(n==p+'.class' or n.startswith(p+'$') for p in defs for n in names)
print('252 protected files unchanged; 12 files migrated exactly;',len(defs),'declared top-level types in Test, all absent from production JAR')
v=json.load(open(root/'validation.json'));v['productionJar']['migratedTypePrefixes']=defs
(root/'validation.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
# Retain captured raw database evidence; refresh only the corrected class-check receipt and its hash.
with tarfile.open(root/'evidence.tar.gz','r:gz') as a:files={m.name:a.extractfile(m).read() for m in a if m.isfile() and m.name!='manifest.json'}
files['validation.json']=(root/'validation.json').read_bytes();files['checks/final-preservation.py']=Path(__file__).read_bytes()
manifest=json.dumps({'files':{n:hashlib.sha256(d).hexdigest() for n,d in files.items()}},ensure_ascii=False,indent=2).encode()
with tarfile.open(root/'evidence.tar.gz','w:gz') as a:
 for n,d in list(files.items())+[('manifest.json',manifest)]:
  info=tarfile.TarInfo(n);info.size=len(d);info.mode=0o644;a.addfile(info,io.BytesIO(d))
print('Archive members',len(files)+1)
