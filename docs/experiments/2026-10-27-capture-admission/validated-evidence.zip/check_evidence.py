import json,hashlib,re,sys,zipfile
from pathlib import Path
base=Path(sys.argv[1]);results={}
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def equal_rows(state):
 left,right=state['source'],state['target']
 a={r['id']:r for r in left};b={r['id']:r for r in right}
 assert len(a)==len(left) and len(b)==len(right)
 diffs=[{'id':k,'field':f,'source':a[k].get(f),'target':b[k].get(f)} for k in a.keys() & b.keys() for f in a[k].keys()|b[k].keys() if f not in a[k] or f not in b[k] or a[k][f]!=b[k][f]]
 return dict(equal=not diffs and a.keys()==b.keys(),source_rows=len(a),target_rows=len(b),fields=sum(len(r) for r in a.values()),missing=sorted(a.keys()-b.keys()),extra=sorted(b.keys()-a.keys()),different_fields=diffs)
def chain(evidence):
 frames={int(f['seq']):f for f in evidence['log']};acks=0
 for seq,f in frames.items():
  d=hashlib.sha256(canonical([f['kind'],f['table_name'],f['subscription_id'],f['schema_id'],f['payload'],f.get('point_json') or '']).encode()).hexdigest()
  assert d==f['digest'],('frame-digest',seq)
  if f['kind']=='ACK':
   acks+=1;p=json.loads(f['payload'])
   for r in p['references']+([p['parent']] if p['parent'] else []):
    assert int(r['sequence'])<seq and frames[int(r['sequence'])]['digest']==r['digest']
 return dict(frames=len(frames),acks=acks)
for suite in sorted(base.glob('*/receipt.json')):
 receipt=json.loads(suite.read_text());d=suite.parent
 item={'exit_code':receipt['exit_code'],'after_idle':receipt.get('after_idle'),'source_sha256':receipt['source_sha256'],'cases':[]}
 for result in sorted(d.glob('cases/*/result.json')):
  v=json.loads(result.read_text());case={'id':result.parent.name,'status':v['status']}
  if v['status']=='SAFE_PAUSED' and 'bound' in v:
   assert v['engineCreations']==0
   before=json.loads((result.parent/'before-crash.json').read_text())
   after=json.loads((result.parent/'original-guard.json').read_text())
   assert after['engineCreations']==0
   assert all(after['state'][k]==before[k] for k in ['source','target','controls','T','J'])
   old={int(f['seq']):f for f in before['L']['log']}
   new={int(f['seq']):f for f in after['state']['L']['log']}
   assert all(new.get(n)==f for n,f in old.items())
   assert after['startup']['phase']=='PAUSED_UNPROVEN'
   assert any(json.loads(r['offset_val']).get('snapshot')=='INITIAL' for r in before['D'])
   case.update(reason=after['startup']['reason'],business_state_preserved=True,crash_interval_appended_frames=len(new)-len(old),comparison=equal_rows(before),proof=chain(after['state']['L']))
  elif 'failureStage' in v:
   assert v['failureStage']=='source-marker:MARKER_COMMIT_UNKNOWN' and v['releaseConfirmed'] is False
   held=json.loads((result.parent/'actual-commit-reply-held.json').read_text())
   assert len(held['controls'])==1 and held['controls']==v['state']['controls']
   assert not v['state']['T'] and not v['state']['J']
   begins=[e['id'] for e in v['events'] if e['kind']=='RAW_ACK_BEGIN']
   returned=[e['id'] for e in v['events'] if e['kind']=='RAW_ACK_RETURNED']
   assert begins==sorted(set(begins)) and returned==begins[:len(returned)]
   case.update(comparison=equal_rows(v['state']),proof=chain(v['state']['L']),ack_begin=begins,ack_returned=returned,source_marker_rows=len(held['controls']))
  else:
   assert v['startup']['phase']=='STOPPING'
   assert not any(r['request_id']=='after-stop' for r in v['state']['L']['subscriptions'])
   case.update(comparison=equal_rows(v['state']),proof=chain(v['state']['L']))
  item['cases'].append(case)
 results[d.name]=item
print(json.dumps(results,ensure_ascii=False,indent=2))
