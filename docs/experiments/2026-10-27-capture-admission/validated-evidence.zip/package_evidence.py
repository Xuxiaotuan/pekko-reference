import json,hashlib,zipfile,shutil,re,sys,time
from pathlib import Path
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference')
base=Path('/private/tmp/capture-admission-implementation-20261027')
out=repo/'docs/experiments/2026-10-27-capture-admission'
final=json.loads((base/'candidate-7/candidate.json').read_text())
labels=['final7-admission','final7-bootstrap-I01','final7-bootstrap-I11','final-bootstrap-I16','final-bootstrap-I21','final7-runner-reader']
checks=json.loads((base/'independent-admission-check.json').read_text())
boot=json.loads((base/'offline-final-bootstrap/verification.json').read_text())
assert not boot['completeMatrix'] and len(boot['cases'])==5 and all(c['status']=='PASS' and not c['errors'] for c in boot['cases'])
receipts={}
for label in labels:
 r=json.loads((base/label/'receipt.json').read_text())
 assert r['exit_code']==0 and r['after_idle'] and r['source_sha256']==final['source_sha256']
 receipts[label]=r
assert checks['final7-admission']['exit_code']==0 and checks['final7-admission']['after_idle']
backend=(base/'candidate-7-backend-regression.log').read_bytes().replace(b'\0',b'').decode(errors='replace')
assert 'Tests: succeeded 603, failed 0' in backend
summary=dict(scope='A1-A2 startup/admission only',source_sha256=final['source_sha256'],production_sha256=final['production_sha256'],
 receipts=receipts,admission=checks['final7-admission'],bootstrap=boot,
 bootstrap_complete_matrix=False,regular_backend=dict(succeeded=603,failed=0,excluded=['ExternalIntegration','cn.xuyinyin.magic.actor.ActorSpec']),
 verifier_unit_tests=19,runner_isolation_tests=5,
 limitations=['B1/AB not implemented','no historical gap repair','no retrospective persistent startup proof','no full A/B or I01-I24 matrix rerun','no new HA/GC/DDL/700k actual-table test'])
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
for name in ['candidate.json','source.zip']:
 src,dest=base/'candidate-7'/name,out/name
 if dest.exists():assert src.read_bytes()==dest.read_bytes()
 else:shutil.copy2(src,dest)
shutil.copy2(base/'final-cleanup.json',out/'final-cleanup.json')
validated_files=[]
for name in labels:
 validated_files.extend((p,str(p.relative_to(base))) for p in (base/name).rglob('*') if p.is_file())
for name in ['candidate-7-backend-regression.log','store-release-final.log','evidence-verifier-tests.log','runner-isolation-tests.log','independent-admission-check.json','check_evidence.py','final-cleanup.json','freeze-7.log','offline-final-bootstrap/result.json','offline-final-bootstrap/verification.json','candidate-7-build/build.log']:
 p=base/name
 if p.exists():validated_files.append((p,name))
validated_files.append((Path(__file__),'package_evidence.py'))
# Old receipts retain their own source digests. Never relabel them as the final candidate.
exploratory=[]
for folder in base.iterdir():
 if folder.is_dir() and folder.name not in labels and not folder.name.startswith(('candidate-','offline-final-bootstrap')):
  exploratory.extend((p,str(p.relative_to(base))) for p in folder.rglob('*') if p.is_file())
for p in base.iterdir():
 if p.is_file() and p.suffix in ['.log','.py','.txt','.json'] and not p.name.startswith('lease-') and p.name not in {Path(name).name for name in ['candidate-7-backend-regression.log','store-release-final.log','evidence-verifier-tests.log','runner-isolation-tests.log','independent-admission-check.json','check_evidence.py','final-cleanup.json','freeze-7.log','package_evidence.py']}:
  exploratory.append((p,p.name))
for i in range(1,7):
 for name in ['source.zip','candidate.json']:
  p=base/f'candidate-{i}'/name
  if p.exists():exploratory.append((p,str(p.relative_to(base))))
 for p in (base/f'candidate-{i}-build').glob('*.log'):exploratory.append((p,str(p.relative_to(base))))
indexes={}
for name,files in [('validated-evidence.zip',validated_files),('exploratory-evidence.zip',exploratory)]:
 members={}
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,n in sorted(files,key=lambda pair:pair[1]):
   assert n not in members,n
   data=p.read_bytes();members[n]=dict(size=len(data),sha256=hashlib.sha256(data).hexdigest());z.writestr(n,data)
 indexes[name]=dict(sha256=hashlib.sha256((out/name).read_bytes()).hexdigest(),size=(out/name).stat().st_size,members=members)
indexes['source.zip']=dict(sha256=hashlib.sha256((out/'source.zip').read_bytes()).hexdigest(),members={})
with zipfile.ZipFile(out/'source.zip') as z:
 for n in z.namelist():
  data=z.read(n);assert hashlib.sha256(data).hexdigest()==final['source_manifest'][n]
  indexes['source.zip']['members'][n]=dict(size=len(data),sha256=hashlib.sha256(data).hexdigest())
(out/'archive-index.json').write_text(json.dumps(indexes,indent=2)+'\n')
# Compare actual private secrets, without printing or archiving their values.
sys.path.insert(0,str(repo/'scripts/experiments/cdc-lab-pool'))
from pool import Pool
pool=Pool(repo/'docs/experiments/2026-10-25-cdc-lab-pool/pool-attempt-2.json')
secrets=[pool.credentials(slot)['password'].encode() for slot in ['a','b']]
for slot in ['a','b']:secrets.append(json.loads((base/('lease-'+slot+'.json')).read_text())['token'].encode())
found=[];count=0
from io import BytesIO
def scan(data,name):
 global count
 count+=1
 if any(secret and secret in data for secret in secrets):found.append(name)
 if data.startswith(b'PK\x03\x04'):
  with zipfile.ZipFile(BytesIO(data)) as z:
   for member in z.namelist():scan(z.read(member),name+'!'+member)
for p in out.iterdir():
 if p.is_file() and p.name!='credential-scan.json':scan(p.read_bytes(),p.name)
assert not found,found
(out/'credential-scan.json').write_text(json.dumps(dict(files_and_nested_members_checked=count,actual_secret_matches=0,scope='slot a/b passwords and lease tokens; no values included'),indent=2)+'\n')
print(json.dumps(dict(archives={n:dict(size=v['size'],members=len(v['members'])) for n,v in indexes.items() if 'size' in v},credential_matches=len(found))))
