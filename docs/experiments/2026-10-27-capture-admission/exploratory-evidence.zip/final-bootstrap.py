import subprocess,sys
from pathlib import Path
base=Path('/private/tmp/capture-admission-implementation-20261027')
for case in ['I01','I11','I16','I21']:
 with (base/('final-bootstrap-'+case+'-runner.log')).open('x') as log:
  code=subprocess.run([sys.executable,str(base/'run_suite.py'),'b','final-bootstrap-'+case,'cn.xuyinyin.magic.workflow.integration.BootstrapMatrixSpec','-z','for '+case],stdout=log,stderr=subprocess.STDOUT).returncode
 print(case,code,flush=True)
 if code:raise SystemExit(code)
