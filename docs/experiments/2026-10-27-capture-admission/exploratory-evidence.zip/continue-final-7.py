import json,subprocess,sys,time
from pathlib import Path
base=Path('/private/tmp/capture-admission-implementation-20261027')
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference')
slot=sys.argv[1]
previous=base/('final-admission' if slot=='a' else 'final-bootstrap-I21')/'receipt.json'
deadline=time.monotonic()+1200
while not previous.exists():
 if time.monotonic()>deadline:raise SystemExit('previous run has not completed; no new JVM')
 time.sleep(1)
r=json.loads(previous.read_text());assert r['exit_code']==0 and r['after_idle']
jobs=[('final7-admission',['admission','marker','reader'],None)] if slot=='a' else [('final7-bootstrap-I01',['bootstrap'],'for I01'),('final7-bootstrap-I11',['bootstrap'],'for I11')]
for label,suites,case in jobs:
 args=[sys.executable,str(repo/'scripts/experiments/capture-admission/run.py'),'--config',str(repo/'docs/experiments/2026-10-25-cdc-lab-pool/pool-attempt-2.json'),'--lease',str(base/('lease-'+slot+'.json')),'--candidate',str(base/'candidate-7/candidate.json'),'--legacy-candidate','/private/tmp/capture-admission-release-20261026/candidate-validated/candidate.json','--java','/Users/xujiawei/Library/Java/JavaVirtualMachines/ms-17.0.14/Contents/Home/bin/java','--output',str(base/label)]
 for suite in suites:args+=['--suite',suite]
 if case:args+=['--case',case]
 with (base/(label+'-runner.log')).open('x') as log:code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
 print(label,code,flush=True)
 if code:raise SystemExit(code)
