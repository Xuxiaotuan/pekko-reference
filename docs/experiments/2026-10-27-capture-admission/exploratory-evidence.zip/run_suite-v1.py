from pathlib import Path
import sys,json,os,subprocess,time
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference')
sys.path.insert(0,str(repo/'scripts/experiments/cdc-lab-pool'))
from pool import Pool,verify_candidate,write_json,terminate_group
base=Path('/private/tmp/capture-admission-implementation-20261027')
slot,label,suite,*filters=sys.argv[1:]
pool=Pool(repo/'docs/experiments/2026-10-25-cdc-lab-pool/pool-attempt-2.json');lease=json.loads((base/('lease-'+slot+'.json')).read_text());token=lease['token']
candidate=verify_candidate(base/'candidate-2/candidate.json');old=verify_candidate(Path('/private/tmp/capture-admission-release-20261026/candidate-validated/candidate.json'))
out=base/label;out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(pool.environment(slot));env.update(RUN_CAPTURE_ADMISSION_MATRIX='1',CDC_LAB_EXCLUSIVE_LEASE='exclusive-capture-admission-test',CAPTURE_LEGACY_CLASSPATH=os.pathsep.join(old['classpath']),CAPTURE_ADMISSION_EVIDENCE=str(out/'cases'),BOOTSTRAP_SOURCE_MANIFEST_SHA256=candidate['source_sha256'],CAPTURE_EXPECT_SOURCE_UUID=pool.slots[slot]['source']['uuid'],CAPTURE_EXPECT_STATE_UUID=pool.slots[slot]['state']['uuid'])
args=['/Users/xujiawei/Library/Java/JavaVirtualMachines/ms-17.0.14/Contents/Home/bin/java','-Xmx768m','-Duser.timezone=UTC','-cp',os.pathsep.join(candidate['classpath']),'org.scalatest.tools.Runner','-o','-s',suite]+filters
receipt={'admission':pool.verify_slot(slot,token),'source_sha256':candidate['source_sha256'],'legacy_source_sha256':old['source_sha256'],'slot':slot,'suite':suite,'started_ns':time.time_ns()};assert receipt['admission']['admitted']
private=pool.root/('guard-'+label+'.log');process=None
try:
 with open(private,'x',opener=lambda p,f:os.open(p,f,0o600)) as raw:
  process=subprocess.Popen(args,stdout=raw,stderr=subprocess.STDOUT,env=env,cwd=out,start_new_session=True);receipt['pid']=process.pid
  try:receipt['exit_code']=process.wait(timeout=1000)
  except subprocess.TimeoutExpired:receipt['cleanup']=terminate_group(process.pid);raise
finally:
 if process and process.poll() is None:receipt['cleanup']=terminate_group(process.pid)
 receipt['finished_ns']=time.time_ns();write_json(out/'receipt.json',receipt)
 if private.exists():(out/'suite.log').write_text(private.read_text(errors='replace').replace(env['CDC_WINDOW_MYSQL_PASSWORD'],'[REDACTED]'))
print(json.dumps(receipt));raise SystemExit(receipt.get('exit_code',125))
