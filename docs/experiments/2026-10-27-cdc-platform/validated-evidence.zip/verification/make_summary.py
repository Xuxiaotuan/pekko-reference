from pathlib import Path
import json,subprocess,re
p=Path(__file__).parent;repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference')
load=lambda f:json.loads(Path(f).read_text());code=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
validated=['bootstrap-final4','release-final4','step-view-final4','recovery-windows-attempt1','automatic-recovery-attempt1','session-release-attempt1','l-ownership-final7','shared-final7-a','shared-final7-b','shared-final8-binlog','metadata-pilot50000-attempt1','metadata-700000-final8']+['platform-final7-P0'+str(i) for i in range(1,9)]
all_runs=[]
for d in sorted(p.iterdir()):
 if not d.is_dir() or not ((d/'before.json').exists() or (d/'receipt.json').exists()):continue
 receipt=load(d/'receipt.json') if (d/'receipt.json').exists() else None
 all_runs.append(dict(name=d.name,receipt=receipt,acceptedInFinalSelection=d.name in validated,missingFinalReceipt=receipt is None or 'exit_code' not in receipt))
for name in validated:
 r=load(p/name/'receipt.json');assert r['exit_code']==0 and r['after_idle'],name
shared=[]
for name in ['shared-final7-a','shared-final7-b','shared-final8-binlog']:
 for f in (p/name).glob('target/shared-capture-matrix/*/result.json'):
  v=load(f);assert v['status']=='passed';shared.append(v|dict(path=str(f.parent.relative_to(p))))
assert len(shared)==31 and len({v['variant'] for v in shared})==31
platform=load(p/'platform-independent-verification-final7.json');assert platform['allEightPlatformCases'] and not platform['failures']
bootstrap=load(p/'bootstrap-final4-verification/result-verification.json');assert bootstrap['pass'] and bootstrap['completeMatrix']
h=load(next((p/'metadata-700000-final8').rglob('result.json')))
assert h['exactDatabaseRows']==700000 and h['pages']==7000 and h['quietObservationMillis']>=60000 and not h['actorSystemCreated'] and not h['readerCreated'] and not h['sourceTablesCreated']
summary=dict(codeCommit=code,finalCandidate='candidate-8',productionSha256=load(p/'candidate-8/candidate.json')['production_sha256'],sourceSha256=load(p/'candidate-8/candidate.json')['source_sha256'],allRuns=all_runs,validatedRuns=validated,
 backend=dict(tests=650,passed=650,log='backend-regression-final7.log',excluded=['cn.xuyinyin.magic.tags.ExternalIntegration','cn.xuyinyin.magic.actor.ActorSpec']),
 console=dict(tests=13,passed=13,productionBuild=True,browserVisualEndToEnd=False),tools=dict(artifactVerifier=9,runnerIsolation=9,earlierEvidenceVerifier=19),
 bootstrap=dict(checks=61,safePausedMarkerUnknown=13,otherPositiveAndNegativeChecks=48,requiredEqualFields=sum(x['fieldsCompared'] for c in bootstrap['cases'] for x in c['comparisons'] if x['requiredEqual']),savedArtifactRecomputation=True,sourceSha256=bootstrap['sourceManifestSha256']),
 shared=dict(checks=31,startupSafePaused=sum(x.get('startupOutcome')=='SAFE_PAUSED' for x in shared),cases=shared,allChecksPassed=True,allCasesConverged=False),
 platform=dict(checks=8,requiredEqualFields=sum(c['requiredEqualFields'] for c in platform['cases']),actualJournalEvents=len(load(p/'platform-decoded-journal-final7.json')),cases=[{k:c[k] for k in ['case','resultKind','requiredEqualFields','matchedJournalTasks']} for c in platform['cases']]),
 metadata=dict(rows=h['exactDatabaseRows'],pages=h['pages'],insertMillis=h['insertMillis'],pageScanMillis=h['pageScanMillis'],quietObservationMillis=h['quietObservationMillis'],lastSample=h['samples'][-1],actorSystemCreated=False,readerCreated=False,sourceTablesCreated=False),
 originalRecoveryWindows=dict(checks=27,passed=27,sameFinalProduction=False,scope='original non-shared T/J/D execution classes; per-run manifest retained'),
 limitations=['evidence_incomplete: not 700000 real source tables or sustained CDC capacity','new shared chain HA, DDL, GC and generic Resume excluded','normal Reader release != arbitrary uncertain L release; Kernel ownership probe separately scoped','private raw binlogs excluded from public payload','artifact checks != database rerun','earlier isolated RED binaries do not have a complete source freeze'],
 cleanup=load(p/'final-cleanup.json'))
(p/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
ind=dict(scope='saved evidence only; not a database rerun',platform=platform,bootstrap={k:v for k,v in bootstrap.items() if k!='cases'},supplement=load(p/'supplement-independent-verification.json'))
(p/'independent-verification.json').write_text(json.dumps(ind,ensure_ascii=False,indent=2)+'\n')
exploratory=[x['name'] for x in all_runs if x['name'] not in validated]
inputs=dict(candidate='candidate-8',validated_runs=validated,exploratory_runs=exploratory,candidate_history=['candidate-'+str(i) for i in range(1,9)],verification_files=['platform-decoded-journal-final7.json','platform-independent-verification-final7.json','bootstrap-final4-verification/result-verification.json','supplement-independent-verification.json','backend-regression-final7.log','console-final-tests-2.log','console-final-build-2.log','runner-unit-final.log','platform-verifier-unit-final.log','layout-check.log','verify_supplement.py','capture_l_ownership_probe.py','cleanup_and_secrets.py','make_summary.py','package_evidence.py'],public_json={'summary.json':'summary.json','independent-verification.json':'independent-verification.json','final-cleanup.json':'final-cleanup.json'})
(p/'publication-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print(json.dumps(dict(code=code,bootstrap=61,shared=31,startupSafePaused=summary['shared']['startupSafePaused'],P=8,fields=summary['platform']['requiredEqualFields'],H=summary['metadata'],exploratoryRuns=len(exploratory)),ensure_ascii=False))
