from pathlib import Path
import json,zipfile,hashlib,shutil,sys,re
base=Path(__file__).parent;repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference');out=repo/'docs/experiments/2026-10-27-cdc-platform'
final=json.loads((base/'publication-inputs.json').read_text());candidate=base/final['candidate']
# Exact files are selected by the execution ledger, not by 'all files' staging.
selected=final['validated_runs']; assert all((base/n/'receipt.json').exists() for n in selected)
for name in selected:
 r=json.loads((base/name/'receipt.json').read_text());assert r['exit_code']==0 and r['after_idle'],name

def sha(data):return hashlib.sha256(data).hexdigest()
def entries(root):return sorted(p for p in root.rglob('*') if p.is_file())
def archive(target, pairs):
 seen=set()
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for source,name in pairs:
   assert name not in seen,name;seen.add(name);z.writestr(name,source.read_bytes())
 for name in seen:
  assert not any(x in name for x in ['lease-a.json','lease-b.json','credentials.json']),name

pairs=[]
for name in selected:
 for p in entries(base/name):pairs.append((p,'runs/'+name+'/'+str(p.relative_to(base/name))))
for name in final['verification_files']:
 p=base/name;assert p.is_file(),name;pairs.append((p,'verification/'+name))
archive(out/'validated-evidence.zip',pairs)
old=[]
for name in final['exploratory_runs']:
 d=base/name;assert d.is_dir(),name
 for p in entries(d):old.append((p,'runs/'+name+'/'+str(p.relative_to(d))))
for p in sorted(base.glob('*.log')):old.append((p,'logs/'+p.name))
for p in sorted(base.glob('*.json')):
 if p.name.startswith(('poll-admission-', 'platform-independent-verification')) or p.name=='before-stop-classpath.json':old.append((p,'diagnostics/'+p.name))
for name in final['candidate_history']:
 for f in ['candidate.json','source.zip']:
  p=base/name/f;old.append((p,'candidates/'+name+'/'+f))
for name in ['before-stop-0.jar','before-stop-1.jar']:
 p=base/name
 if p.exists():old.append((p,'isolated-binary-baselines/'+name))
archive(out/'exploratory-evidence.zip',old)
for n in ['candidate.json','source.zip']:shutil.copy2(candidate/n,out/n)
for name,target in final['public_json'].items():shutil.copy2(base/name,out/target)
index={}
for p in entries(out):
 if p.name in ['archive-index.json','credential-scan.json']:continue
 b=p.read_bytes();item=dict(bytes=len(b),sha256=sha(b))
 if p.suffix=='.zip':
  with zipfile.ZipFile(p) as z:item['entries']={i.filename:dict(bytes=i.file_size,sha256=sha(z.read(i.filename))) for i in z.infolist()}
 index[str(p.relative_to(out))]=item
(out/'archive-index.json').write_text(json.dumps(dict(files=index,scope='bytes, not runtime evidence',excluded=['private leases and plaintext credentials','dependency JARs','private raw binlogs containing authentication material']),ensure_ascii=False,indent=2)+'\n')
print(json.dumps({p.name:p.stat().st_size for p in out.iterdir() if p.is_file()}))
