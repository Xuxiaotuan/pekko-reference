from pathlib import Path
import argparse,json,os,subprocess,sys,time,uuid,hashlib,fcntl
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference')
base=Path('/private/tmp/cdc-platform-completion-20261027')
sys.path.insert(0,str(repo/'scripts/experiments/cdc-lab-pool'))
from pool import Pool,verify_candidate,write_json,terminate_group
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--candidate',type=Path,default=base/'candidate-5/candidate.json');p.add_argument('--slot',default='a');p.add_argument('--run',action='store_true');a=p.parse_args()
m=verify_candidate(a.candidate);out=base/a.label;out.mkdir(exist_ok=False);classes=out/'classes';classes.mkdir()
java='/Users/xujiawei/Library/Java/JavaVirtualMachines/ms-17.0.14/Contents/Home/bin/java'
root=Path('/Users/xujiawei/Library/Caches/Coursier/v1/https/repo1.maven.org/maven2/org/scala-lang')
compiler=[str(root/x/'2.13.12'/(x+'-2.13.12.jar')) for x in ['scala-compiler','scala-reflect','scala-library']]
source=repo/'server/src/test/scala/cn/xuyinyin/magic/workflow/integration/CaptureLogResourceOwnershipSpec.scala'
receipt={'source_sha256':m['source_sha256'],'production_sha256':m['production_sha256'],'test_overlay_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'real Kernel Reader/L transaction ownership; no Sink or Actor Journal execution'}
(out/'test-source.scala').write_bytes(source.read_bytes())
with (out/'compile.log').open('x') as log:r=subprocess.run([java,'-cp',os.pathsep.join(compiler),'scala.tools.nsc.Main','-classpath',os.pathsep.join(m['classpath']),'-d',str(classes),str(source)],stdout=log,stderr=subprocess.STDOUT)
receipt['compile_exit_code']=r.returncode;write_json(out/'receipt.json',receipt)
if r.returncode:raise SystemExit(r.returncode)
cp=[str(classes)]+m['classpath'];write_json(out/'classpath.json',cp)
if not a.run:print(json.dumps({'compiled':True,'output':str(out)}));raise SystemExit(0)
pool=Pool(repo/'docs/experiments/2026-10-25-cdc-lab-pool/pool-attempt-2.json');lease=json.loads((base/('lease-'+a.slot+'.json')).read_text());token=lease['token'];pool.require(a.slot,token,lease['owner'])
slot_lock=(pool.root/a.slot/'capture-admission-runner.lock').open('a')
fcntl.flock(slot_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def sample():
 v={'at_ns':time.time_ns(),'idle':True,'instances':{}}
 for role in ['source','state']:
  sessions=pool.sql(a.slot,role,"SELECT ID,USER,HOST,DB,COMMAND FROM information_schema.PROCESSLIST WHERE ID<>CONNECTION_ID() AND USER NOT IN ('event_scheduler','system user')",token)
  tx=pool.sql(a.slot,role,'SELECT trx_id,trx_state,trx_mysql_thread_id FROM information_schema.INNODB_TRX',token)
  v['instances'][role]={'sessions':sessions,'transactions':tx};v['idle']=v['idle'] and not sessions.strip() and not tx.strip()
 return v
receipt['admission']=pool.verify_slot(a.slot,token);assert receipt['admission']['admitted'];before=sample();write_json(out/'before.json',before);assert before['idle']
env=os.environ.copy();env.update(pool.environment(a.slot));env.update(RUN_CAPTURE_ADMISSION_MATRIX='1',CDC_LAB_EXCLUSIVE_LEASE='exclusive-l-ownership-probe',CAPTURE_EXPECT_SOURCE_UUID=pool.slots[a.slot]['source']['uuid'],CAPTURE_EXPECT_STATE_UUID=pool.slots[a.slot]['state']['uuid'],CAPTURE_ADMISSION_EVIDENCE=str(out/'cases'),BOOTSTRAP_SOURCE_MANIFEST_SHA256=m['source_sha256'])
private=pool.root/('l-owner-'+uuid.uuid4().hex+'.log');child=None
try:
 with open(private,'x',opener=lambda x,f:os.open(x,f,0o600)) as log:
  child=subprocess.Popen([java,'-Xmx768m','-Duser.timezone=UTC','-cp',os.pathsep.join(cp),'org.scalatest.tools.Runner','-o','-s','cn.xuyinyin.magic.workflow.integration.CaptureLogResourceOwnershipSpec'],env=env,cwd=out,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  receipt.update(pid=child.pid,started_ns=time.time_ns())
  try:receipt['exit_code']=child.wait(timeout=650)
  except subprocess.TimeoutExpired:receipt['cleanup']=terminate_group(child.pid);receipt['exit_code']=124
finally:
 if child and child.poll() is None:receipt['cleanup']=terminate_group(child.pid)
 receipt['finished_ns']=time.time_ns();samples=[];deadline=time.monotonic()+180
 while True:
  observation=sample();samples.append(observation)
  if observation['idle'] or time.monotonic()>deadline:break
  time.sleep(.5)
 receipt['after_idle']=samples[-1]['idle']
 if not receipt['after_idle']:receipt['exit_code']=125
 write_json(out/'release.json',samples)
 write_json(out/'receipt.json',receipt)
 if private.exists():(out/'suite.log').write_text(private.read_text(errors='replace').replace(env['CDC_WINDOW_MYSQL_PASSWORD'],'[REDACTED]'))
print(json.dumps(receipt));raise SystemExit(receipt.get('exit_code',125))
