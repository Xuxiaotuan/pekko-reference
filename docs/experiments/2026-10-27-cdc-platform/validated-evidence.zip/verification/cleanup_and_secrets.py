from pathlib import Path
import json,sys,time,os,subprocess,re,hashlib
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference');base=Path(__file__).parent
sys.path.insert(0,str(repo/'scripts/experiments/capture-admission'));from run import Pool,observe_resources
pool=Pool(repo/'docs/experiments/2026-10-25-cdc-lab-pool/pool-attempt-2.json');result=dict(at_ns=time.time_ns(),slots={},privateBinlogs=[],applicationUnknownsPreserved=[]);secrets=[]
for name in ['a','b']:
 lease=json.loads((base/('lease-'+name+'.json')).read_text());pool.require(name,lease['token'],lease['owner']);secrets+=[lease['token'],pool.credentials(name)['password']]
 observed=observe_resources(pool,name,lease['token']);assert observed['idle'],(name,observed)
 locks={}
 for role in ['source','state']:
  locks[role]=pool.sql(name,role,"SELECT OBJECT_NAME,OWNER_THREAD_ID FROM performance_schema.metadata_locks WHERE OBJECT_TYPE='USER LEVEL LOCK'",lease['token']);assert not locks[role].strip(),(name,role,locks[role])
  values=pool.sql(name,role,"SELECT HEX(authentication_string) FROM mysql.user WHERE authentication_string<>''",lease['token'])
  secrets += ['HEXAUTH:'+v for v in values.splitlines() if v]
 result['slots'][name]=dict(identity=pool.verify_slot(name,lease['token']),resources=observed,userLevelLocks=locks)
for file in base.glob('platform-final7-P07/cases/*/environment.json'):
 env=json.loads(file.read_text());schema=env['schema'];assert re.fullmatch('[A-Za-z_][A-Za-z0-9_]*',schema)
 lease=json.loads((base/'lease-b.json').read_text())
 result['applicationUnknownsPreserved'].append(dict(schema=schema,owners=pool.sql('b','state',f'SELECT platform_id,owner_attempt,status FROM `{schema}`.pekko_cdc_owner_v1',lease['token']),grants=pool.sql('b','state',f'SELECT grant_id,task_id,status FROM `{schema}`.pekko_cdc_grants_v1',lease['token'])))
for d in (pool.root/'b/private-binlog-archives').glob('*'):
 if not d.is_dir():continue
 manifest=json.loads((d/'manifest.json').read_text());assert (d.stat().st_mode&0o777)==0o700
 for name,digest in manifest['files'].items():assert hashlib.sha256((d/name).read_bytes()).hexdigest()==digest
 result['privateBinlogs'].append(dict(directory=str(d),mode='0700',manifest=manifest,publicPayload=False))
ps=subprocess.run(['ps','-ax','-o','pid=,comm=,args='],capture_output=True,text=True,errors='replace',check=True).stdout
owned=[]
for line in ps.splitlines():
 fields=line.strip().split(None,2)
 if len(fields)==3 and fields[1].endswith('/java') and str(base) in fields[2]:owned.append(dict(pid=int(fields[0]),command='owned experiment JVM'))
assert not owned,owned;result['ownedLiveWorkers']=owned
# Scanner input is private; no secret value/hash is printed or published.
p=base/'.credential-scan-inputs.json'
with open(p,'x',opener=lambda p,f:os.open(p,f,0o600)) as f:json.dump(secrets,f)
for name in ['a','b']:
 lease=json.loads((base/('lease-'+name+'.json')).read_text());pool.release(name,lease['token'],lease['owner']);result['slots'][name]['labLeaseReleased']=True
(base/'final-cleanup.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(slotsIdle=True,userLevelLocks=0,ownedWorkers=0,labLeasesReleased=True,privateBinlogArchives=len(result['privateBinlogs']))))
