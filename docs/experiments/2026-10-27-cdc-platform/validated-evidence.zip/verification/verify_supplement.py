from pathlib import Path
import json,sys
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference');base=Path(__file__).parent
sys.path.insert(0,str(repo/'scripts/experiments/cdc-platform'));import verify
comparisons=[];unchanged=[];ack_files=0
runs=['bootstrap-final4','shared-final7-a','shared-final7-b','shared-final8-binlog','recovery-windows-attempt1','automatic-recovery-attempt1','session-release-attempt1','step-view-final4']
def visit(value,file,path='$'):
 if isinstance(value,dict):
  if isinstance(value.get('source'),list) and isinstance(value.get('target'),list) and isinstance(value.get('equal'),bool):
   r=verify.reconcile(value['source'],value['target']);assert r['equal']==value['equal'],(file,path)
   comparisons.append(dict(file=str(file.relative_to(base)),path=path,**r))
  for k,v in value.items():visit(v,file,path+'.'+k)
 elif isinstance(value,list):
  for i,v in enumerate(value):visit(v,file,path+'['+str(i)+']')
for run in runs:
 for f in sorted((base/run).rglob('*.json')):visit(json.loads(f.read_text()),f)
 if run in ['bootstrap-final4','shared-final7-a','shared-final7-b','shared-final8-binlog','step-view-final4']:
  for f in (base/run).rglob('*.log'):
   verify.verify_ack_file(f);ack_files+=1
 for f in (base/run).rglob('before-startup-independent-sql.json'):
  after=f.with_name('after-rejection-independent-sql.json')
  if after.exists():
   assert json.loads(f.read_text())==json.loads(after.read_text());unchanged.append(str(f.parent.relative_to(base)))
f=next((base/'step-view-final4').rglob('final.json'));v=json.loads(f.read_text());step=verify.reconcile(v['source'],v['target']);assert step['equal'] and step['rows']==63 and step['fields']==378
step['L']=verify.verify_log(v['L']);step['completion']=verify.verify_spool(v['spool'])
release=[]
for f in (base/'release-final4').rglob('result.json'):
 v=json.loads(f.read_text());r=v['release'];assert r['local']=='CONFIRMED' and r['server']=='CONFIRMED' and r['ownerReleased'] and r['reusable'] and v['otherAccountStillAlive']
 assert all(s['operation']==r['operation'] and s['attempt']==r['attempt'] for s in v['samples']);release.append(dict(file=str(f.relative_to(base)),samples=len(v['samples']),sameOperation=True,actualReusable=True))
f=next((base/'l-ownership-final7').rglob('result.json'));v=json.loads(f.read_text());assert v['status']=='PASS' and v['actualLAccount']==v['expectedLAccount'] and not v['reusableBeforeResolve'] and not v['ownerReleasedBeforeResolve']
f=next((base/'l-ownership-red-2').rglob('result.json'));old=json.loads(f.read_text());assert old['status']=='FAIL' and old['reusableBeforeResolve'] and old['ownerReleasedBeforeResolve']
out=dict(scope='saved artifact recomputation; no database rerun',comparisonSnapshots=len(comparisons),checksReportedEqualityOnly=True,independentDatabaseRerun=False,comparisons=comparisons,rawAckLogFiles=ack_files,strictStartupSqlUnchanged=unchanged,stepView=step,managedReaderRelease=release,oldLOwnershipCounterexample=True,newLOwnershipRemainsUnknownUntilRollback=True)
(base/'supplement-independent-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print({k:out[k] for k in ['comparisonSnapshots','rawAckLogFiles','strictStartupSqlUnchanged']})
