USE pekko_test_ack_345d7327149c; START TRANSACTION;
UPDATE source_rows SET id=101,label='moved-1',revision=1 WHERE id=1;
COMMIT;
