USE pekko_test_ack_da9f3eb32358; START TRANSACTION;
UPDATE source_rows SET label='prefix',revision=2 WHERE id=8;
UPDATE source_rows SET id=101,label='moved-1',revision=1 WHERE id=1;
UPDATE source_rows SET id=102,label='moved-2',revision=1 WHERE id=2;
UPDATE source_rows SET id=103,label='moved-3',revision=1 WHERE id=3;
UPDATE source_rows SET label='sentinel',revision=999 WHERE id=7;
COMMIT;
