package cn.xuyinyin.magic.compatibility
import cn.xuyinyin.magic.workflow.actors.EventSourcedWorkflowActor._
import cn.xuyinyin.magic.workflow.events.WorkflowEvents._
import cn.xuyinyin.magic.workflow.engine.ExecutionFailure
import cn.xuyinyin.magic.workflow.checkpoint._
import cn.xuyinyin.magic.workflow.scheduler.{ScheduleCalculator, SchedulerCoordinator}
import com.typesafe.config.ConfigFactory
import org.apache.pekko.actor.testkit.typed.scaladsl.ActorTestKit
import org.apache.pekko.serialization.{SerializationExtension, Serializers}
import spray.json._
import java.nio.file.{Files, Path}
import java.util.Base64
import scala.concurrent.duration._
object CaptureLegacyTypes {
 def main(args: Array[String]): Unit = {
  val kit=ActorTestKit("legacy-layout-capture",ConfigFactory.parseString("pekko.actor.provider=local").withFallback(ConfigFactory.load()))
  try {
   val cursor=SourceCursor("mysql.binlog.groups.v1","{\"offset\":{\"file\":\"mysql-bin.000001\",\"pos\":4,\"row\":0},\"version\":1}","{\"version\":2}")
   val boundary=SnapshotBoundary("source-1","mysql-cdc:compat",Some("{\"version\":2}"))
   val checkpoint=BatchCheckpoint("source-1","mysql-cdc:compat",3,"fixture-batch",cursor,64,64)
   val failure=ExecutionFailure(ExecutionFailure.CommitUnknown,"commit",Some("fixture-batch"))
   val recovery=ExecutionRecoveryState(1,2,"waiting",12345L,failure.code,"commit",Some(failure))
   val trigger=ExecutionTrigger("manual",Some("fixture-request"))
   val execution=ExecutionState("fixture-execution",trigger,1000L,7L,true,Some(boundary),Vector(checkpoint),Some(recovery))
   val state=WorkflowState(Some("{\"id\":\"fixture\"}"),7L,Running,Some(execution),manualRequests=Vector(ManualRequestRecord("fixture-request","fixture-execution")),workflowSourceProgress=Some(WorkflowSourceProgress(7L,"source-1","mysql.cdc",checkpoint)))
   val schedule=SchedulerCoordinator.Schedule("fixture-schedule","fixture",ScheduleCalculator.FixedRate(2.seconds))
   val pending=SchedulerCoordinator.PendingTrigger("fixture-trigger",schedule.id,"fixture",12000L,2)
   val samples: Vector[AnyRef]=Vector(state,execution,cursor,boundary,checkpoint,failure,recovery,
    WorkflowDefined("{\"id\":\"fixture\"}",7L,1000L),ResumableExecutionStarted("fixture-execution",trigger,7L,1000L),
    ExecutionSnapshotInitialized("fixture-execution",boundary,1001L),ExecutionCheckpointAdvanced("fixture-execution",checkpoint,1002L),
    ExecutionRecoveryScheduled("fixture-execution",2,12345L,failure.code,"commit",1003L,Some(failure)),
    ExecutionRecoveryAttemptStarted("fixture-execution",1,1004L),ExecutionRecoveryBlocked("fixture-execution",failure.code,"commit",1005L,Some(failure)),
    SchedulerCoordinator.State(Vector(schedule),Vector(pending)),SchedulerCoordinator.ScheduleUpserted(schedule),SchedulerCoordinator.TriggerPrepared(pending),
    ScheduleCalculator.CronSchedule("0 0 * * *"))
   val ser=SerializationExtension(kit.system.classicSystem)
   val rows=samples.map { value => val serializer=ser.findSerializerFor(value)
    JsObject("className"->JsString(value.getClass.getName),"serializerId"->JsNumber(serializer.identifier),"manifest"->JsString(Serializers.manifestFor(serializer,value)),"payloadBase64"->JsString(Base64.getEncoder.encodeToString(ser.serialize(value).get))) }
   Files.writeString(Path.of(args(0)),JsObject("baselineCommit"->JsString("bf249b1823040abc056b65c0c16e462d914c1d73"),"samples"->JsArray(rows)).prettyPrint+"\n")
  } finally kit.shutdownTestKit()
 }
}
