from pathlib import Path
import json,re,subprocess,os,hashlib,tarfile,io,shutil
repo=Path.cwd();tmp=Path('/tmp/pekko-structure-20261020');root=repo/'docs/experiments/2026-10-20-code-structure'
sha=lambda b:hashlib.sha256(b).hexdigest()
settings=json.loads((tmp/'settings.json').read_text())
assert json.loads((tmp/'real-run.json').read_text())['exitCode']==0
frozen=json.loads((tmp/'run-source-manifest.json').read_text());assert all(sha((repo/p).read_bytes())==h for p,h in frozen.items())
protected=json.loads((tmp/'protected-experiments.json').read_text());assert all(sha((repo/p).read_bytes())==h for p,h in protected.items())
log=(tmp/'real-ten.log').read_text()
runs=dict(re.findall(r'CDC_RECOVERY_WINDOW_OBSERVED scenario=(\w+) evidence=(\S+)',log));assert len(runs)==8
sessions=dict(re.findall(r'CDC_SESSION_RELEASE_OBSERVED fault=([\w-]+) evidence=(\S+)',log));assert set(sessions)=={'none','cancel-T'}
files={};records=[]
for case,folder in list(runs.items())+[("sessions/"+k,v) for k,v in sessions.items()]:
 p=Path(folder)
 schema=json.loads((p/('outcome.json' if case.startswith('sessions/') else 'environment.json')).read_text())['schema']
 env=os.environ.copy();env['MYSQL_PWD']=settings['CDC_WINDOW_MYSQL_PASSWORD']
 if not (p/'database-final.sql').exists():
  dump=subprocess.run(['docker','exec','-e','MYSQL_PWD','pekko-cdc-stage-c-20261019','mysqldump','-uroot','--single-transaction','--hex-blob','--set-gtid-purged=OFF','--skip-comments',schema],env=env,capture_output=True)
  assert dump.returncode==0,'dump failed: '+schema
  (p/'database-final.sql').write_bytes(dump.stdout)
 for f in p.iterdir():
  if f.is_file():files[case+'/'+f.name]=f.read_bytes()
 records.append(dict(scenario=case,runDirectory=p.name,schema=schema))
# Only early completed cases are preserved as exploratory observations, never counted as formal coverage.
for folder in re.findall(r'(?:CDC_RECOVERY_WINDOW_OBSERVED scenario=\w+|CDC_SESSION_RELEASE_OBSERVED fault=[\w-]+) evidence=(\S+)',(tmp/'exploratory-before-dispatch-fix.log').read_text()):
 p=Path(folder)
 for f in p.iterdir():
  if f.is_file():files['exploratory/'+p.name+'/'+f.name]=f.read_bytes()
for name in ['baseline.log','focused-after.log','focused-final.log','full-module.log','full-final.log','real-ten.log','exploratory-before-dispatch-fix.log','real-run.json','package-final.log','ui-test.log','ui-build.log','example-moves.json','structural-check.json','structure-result.json','structure-only.diff','exploratory-structure.diff','protected-experiments.json','secret-scan.json','real-run-source-manifest.json','eof-normalization.json','tested-production-classes.json','eof-check.log','collect.py']:
 files['checks/'+name]=(tmp/name).read_bytes()
for name in ['WorkflowExecutionEngine.scala','BatchSourceSession.scala']:files['before/'+name]=(tmp/name).read_bytes()
for p in (tmp/'before-eof').rglob('*'):
 if p.is_file():files['real-run-source/'+str(p.relative_to(tmp/'before-eof'))]=p.read_bytes()
sourcehash=dict(frozen)
for rootpath in ['xxt-ui/src','xxt-ui/tests']:
 for p in (repo/rootpath).rglob('*'):
  if p.is_file():sourcehash[str(p.relative_to(repo))]=sha(p.read_bytes())
for rel in ['build.sbt','quick-test.sh','xxt-ui/package.json','xxt-ui/vite.config.ts']:sourcehash[rel]=sha((repo/rel).read_bytes())
for rel,h in sourcehash.items():files['source/'+rel]=(repo/rel).read_bytes()
for rel in ['docs/CODE_STRUCTURE.md','README.md']:files['source/'+rel]=(repo/rel).read_bytes()
source=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),scope='Existing A/B/C convergence plus local structural extraction; source hashes identify actual run code',sourceSha256=sourcehash,realRunSourceSha256=json.loads((tmp/'real-run-source-manifest.json').read_text()),finalEOFNormalization=json.loads((tmp/'eof-normalization.json').read_text()),productionDataProtocolUnchangedFromPreRefactor=True)
(root/'source-manifest.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
meta=json.loads(subprocess.check_output(['docker','inspect','pekko-cdc-stage-c-20261019']))[0]
run=dict(date='2026-10-20',container='pekko-cdc-stage-c-20261019',image=meta['Image'],arguments=meta['Config']['Cmd'],java='Microsoft OpenJDK 17.0.14',pekko='1.1.3',debezium='3.6.1.Final',formalRuns=records,executionResult=json.loads((tmp/'real-run.json').read_text()),exploratory='Interrupted early run and two failing recovery tests before preserving virtual cancel dispatch; not counted as formal coverage')
(root/'run-manifest.json').write_text(json.dumps(run,ensure_ascii=False,indent=2)+'\n')
checks=(tmp/'full-final.log').read_text(errors='replace');summary=re.findall(r'Tests: succeeded (\d+), failed (\d+), canceled (\d+)',checks)
assert summary==[('440','0','0')],summary
validation=dict(baselineFocusedTests=44,finalFocusedTests=59,fullModule=dict(passed=440,failed=0,abortedSuites=['MysqlSqlParserSpec','ComprehensiveCalciteTest'],exitCode=1,gate='evidence_incomplete'),ui=dict(contractTests=5,build='PASS',boundary='No new browser E2E run'),formalRealCases=10,realConvergedWindows=7,knownRecoveryFailure='C2 FAIL_TERMINAL',realReleaseCases=2,protectedExperimentFiles=len(protected),protectedMismatches=[],archivedExamples=13,package=json.loads((tmp/'package-result.json').read_text()),structure=json.loads((tmp/'structure-result.json').read_text()))
(root/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
for n in ['source-manifest.json','run-manifest.json','validation.json']:files[n]=(root/n).read_bytes()
for name,data in files.items():assert settings['CDC_WINDOW_MYSQL_PASSWORD'].encode() not in data,name
inner=json.dumps(dict(files={name:sha(data) for name,data in files.items()}),ensure_ascii=False,indent=2).encode()
with tarfile.open(root/'evidence.tar.gz','w:gz') as archive:
 for name,data in list(files.items())+[('manifest.json',inner)]:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
shutil.copyfile(tmp/'structure-only.diff',root/'structure-only.diff')
print(json.dumps(dict(archiveMembers=len(files)+1,archiveBytes=(root/'evidence.tar.gz').stat().st_size,protectedFiles=len(protected))))
