
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_00e0a4868c64` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_00e0a4868c64`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'232baee1-b5e8-43af-8121-7bac9f5132dd',1792740826046,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_00e0a4868c64\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_00e0a4868c64\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'232baee1-b5e8-43af-8121-7bac9f5132dd',1792740826046,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'232baee1-b5e8-43af-8121-7bac9f5132dd',1792740826046,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$ec77d773-03a4-42b4-8642-756122364f4citimestamp\0\0�g���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'232baee1-b5e8-43af-8121-7bac9f5132dd',1792740826251,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6flsourceNodeIdfsourcekfingerprintx@414cfcb487f7862c82a2e17d9d2df7aa8cd9cc2f89d7fa41dd75c7324797cf83eupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'232baee1-b5e8-43af-8121-7bac9f5132dd',1792740826361,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:0eindex\0elower\�euppera3��itimestamp\0\0�g���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'232baee1-b5e8-43af-8121-7bac9f5132dd',1792740826422,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:1eindexelowera3euppera7��itimestamp\0\0�g�5�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'232baee1-b5e8-43af-8121-7bac9f5132dd',1792740826469,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g�e�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'232baee1-b5e8-43af-8121-7bac9f5132dd',1792740826483,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:0�itimestamp\0\0�g�s�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(9,0,'workflow-table-00',9,'a2494f17-412c-4760-8c27-65023033deeb',1792740829686,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$57e0492e-cc8b-4649-b01b-71396cee1799itimestamp\0\0�g�)\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(10,0,'workflow-table-00',10,'a2494f17-412c-4760-8c27-65023033deeb',1792740829792,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.RetrySnapshotSplitbidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:0gattempt�itimestamp\0\0�g�*`�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(11,0,'workflow-table-00',11,'a2494f17-412c-4760-8c27-65023033deeb',1792740829973,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:0mbatchSequence\0gbatchIdx@e0dc3da589d2aef089b7dec31db118a4423547cb3a94aad6372ea5805f5cc253fcursor�dkindwmysql.snapshot-split.v1evaluea1jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�+�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(12,0,'workflow-table-00',12,'a2494f17-412c-4760-8c27-65023033deeb',1792740830042,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:0mbatchSequencegbatchIdx@da8f07fe387417bddd4e49f9bfc20508d42949307ca4577abc895bc518b5c30afcursor�dkindwmysql.snapshot-split.v1evaluea3jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�+Y�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(13,0,'workflow-table-00',13,'a2494f17-412c-4760-8c27-65023033deeb',1792740830049,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:0gattempt�itimestamp\0\0�g�+`�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(14,0,'workflow-table-00',14,'a2494f17-412c-4760-8c27-65023033deeb',1792740830056,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:1�itimestamp\0\0�g�+h�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(15,0,'workflow-table-00',15,'a2494f17-412c-4760-8c27-65023033deeb',1792740830151,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:1mbatchSequence\0gbatchIdx@79c0d5da36e9eac4b2ea24d2b08859fbf36084a47558971cdf352ba433952092fcursor�dkindwmysql.snapshot-split.v1evaluea5jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�+\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(16,0,'workflow-table-00',16,'a2494f17-412c-4760-8c27-65023033deeb',1792740830200,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:1mbatchSequencegbatchIdx@9009ad9bff0f48ed93802f5414c9285e337f72bf65b71814416d48c1b1d2769afcursor�dkindwmysql.snapshot-split.v1evaluea7jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�+\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(17,0,'workflow-table-00',17,'a2494f17-412c-4760-8c27-65023033deeb',1792740830204,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:1gattempt\0�itimestamp\0\0�g�+��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(18,0,'workflow-table-00',18,'a2494f17-412c-4760-8c27-65023033deeb',1792740830209,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:2�itimestamp\0\0�g�,�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(19,0,'workflow-table-00',19,'a2494f17-412c-4760-8c27-65023033deeb',1792740830280,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:2mbatchSequence\0gbatchIdx@0cbd21bb92d396c48e763f2173025d33ca42225a7d88131e016574572c1e2a40fcursor�dkindwmysql.snapshot-split.v1evaluep9007199254740993jupperBoundp9007199254740993�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�,H�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(20,0,'workflow-table-00',20,'a2494f17-412c-4760-8c27-65023033deeb',1792740830286,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:2gattempt\0�itimestamp\0\0�g�,N�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(21,0,'workflow-table-00',21,'a2494f17-412c-4760-8c27-65023033deeb',1792740830291,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RetireSnapshotWindow$�itimestamp\0\0�g�,S�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(22,0,'workflow-table-00',22,'a2494f17-412c-4760-8c27-65023033deeb',1792740830299,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex>cn.xuyinyin.magic.workflow.snapshot.FinishSnapshotEnumeration$�itimestamp\0\0�g�,[�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(23,0,'workflow-table-00',23,'a2494f17-412c-4760-8c27-65023033deeb',1792740830311,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfresult�fstatusicompletedgsuccess\�gmessagex\'Workflow executed successfully in 573msmrowsProcessed\nphasRowsProcessed\�hduration=khasDuration\�knodeResults��fnodeIdfsourcehnodeTypenmysql.snapshotfstatusicompletedgmessage`jhasMessage\�hduration=khasDuration\���fnodeIdftargethnodeTypekmysql.writefstatusicompletedgmessage`jhasMessage\�hduration=khasDuration\����itimestamp\0\0�g�,g�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-00e0a4868c64',90);
            DO RELEASE_LOCK('owner-probe-00e0a4868c64');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'ad2b6cc0-749b-4d52-b2cb-9f45e6d71f95','ce7a251e-b9b0-4822-b03f-92aee880a34a');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'161003a1-d235-42ba-9cc7-7a6b7950b80e','1d67d3be-f800-4a01-9466-d09309964a00',1,10),(2,'161003a1-d235-42ba-9cc7-7a6b7950b80e','1d67d3be-f800-4a01-9466-d09309964a00',1,10),(3,'161003a1-d235-42ba-9cc7-7a6b7950b80e','1d67d3be-f800-4a01-9466-d09309964a00',1,10),(4,'161003a1-d235-42ba-9cc7-7a6b7950b80e','1d67d3be-f800-4a01-9466-d09309964a00',1,15),(5,'161003a1-d235-42ba-9cc7-7a6b7950b80e','1d67d3be-f800-4a01-9466-d09309964a00',1,17),(6,'161003a1-d235-42ba-9cc7-7a6b7950b80e','1d67d3be-f800-4a01-9466-d09309964a00',1,19),(7,'161003a1-d235-42ba-9cc7-7a6b7950b80e','1d67d3be-f800-4a01-9466-d09309964a00',1,21),(8,'161003a1-d235-42ba-9cc7-7a6b7950b80e','1d67d3be-f800-4a01-9466-d09309964a00',1,21),(9,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,37),(10,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,40),(11,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,44),(12,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,46),(13,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,46),(14,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,46),(15,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,50),(16,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,52),(17,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,52),(18,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,52),(19,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,56),(20,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,56),(21,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,56),(22,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,56),(23,'22ba2f26-ac57-4980-a47b-7535314e254a','a4ee8ac7-a2ff-4376-a70a-bebe692f07c9',2,56);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('161003a1-d235-42ba-9cc7-7a6b7950b80e',1,'ce7a251e-b9b0-4822-b03f-92aee880a34a','retired'),('22ba2f26-ac57-4980-a47b-7535314e254a',2,'ce7a251e-b9b0-4822-b03f-92aee880a34a','launched');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_batch_evidence` VALUES ('0cbd21bb92d396c48e763f2173025d33ca42225a7d88131e016574572c1e2a40','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79'),('79c0d5da36e9eac4b2ea24d2b08859fbf36084a47558971cdf352ba433952092','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316'),('9009ad9bff0f48ed93802f5414c9285e337f72bf65b71814416d48c1b1d2769a','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c'),('da8f07fe387417bddd4e49f9bfc20508d42949307ca4577abc895bc518b5c30a','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab'),('e0dc3da589d2aef089b7dec31db118a4423547cb3a94aad6372ea5805f5cc253','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62');
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369623,'[\"root\"]',1792740827365,2,1,'{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[841,842,843,844,845,846,847,848,849,850,851,852,853,854,855,856,857],\"observedAt\":1792740827511,\"owner\":\"161003a1-d235-42ba-9cc7-7a6b7950b80e\",\"serverStarted\":1792740369525,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]}'),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369236,'[\"root\"]',NULL,0,0,NULL);
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',841,'control',1792740824655),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',842,'control',1792740824697),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',843,'control',1792740824723),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',844,'control',1792740825539),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',845,'journal',1792740825994),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',846,'target',1792740826153),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',847,'target',1792740826173),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',848,'source',1792740826210),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',849,'source',1792740826229),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',850,'source',1792740826315),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',851,'source',1792740826339),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',852,'source',1792740826384),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',853,'source',1792740826403),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',854,'source',1792740826439),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',855,'source',1792740826454),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',856,'source',1792740826512),('161003a1-d235-42ba-9cc7-7a6b7950b80e','127.0.0.1:32816',857,'source',1792740826529),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',911,'control',1792740828267),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',912,'control',1792740828307),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',913,'control',1792740828335),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',914,'control',1792740829145),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',915,'journal',1792740829556),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',916,'target',1792740829750),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',917,'target',1792740829768),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',918,'source',1792740829818),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',919,'source',1792740829833),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',920,'target',1792740829934),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',921,'target',1792740829953),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',922,'target',1792740830000),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',923,'target',1792740830019),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',924,'source',1792740830073),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',925,'source',1792740830091),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',926,'target',1792740830116),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',927,'target',1792740830133),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',928,'target',1792740830170),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',929,'target',1792740830183),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',930,'source',1792740830221),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',931,'source',1792740830233),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',932,'target',1792740830248),('22ba2f26-ac57-4980-a47b-7535314e254a','127.0.0.1:32816',933,'target',1792740830263);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('161003a1-d235-42ba-9cc7-7a6b7950b80e','takeover-experiment',96972,'2026-10-23T07:33:44.046Z','db_drained','1896397d-3fcb-4afa-b4e4-30a57b9a3df2',1,1,'{\"confirmedAt\":1792740827292,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"1896397d-3fcb-4afa-b4e4-30a57b9a3df2\",\"owner\":\"161003a1-d235-42ba-9cc7-7a6b7950b80e\",\"pid\":96972,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:33:44.046Z\"}','pekko://snapshot-takeover@127.0.0.1:49515|-3697998780271338084',1792740827549),('22ba2f26-ac57-4980-a47b-7535314e254a','takeover-experiment',97004,'2026-10-23T07:33:47.703Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:49622|-2972868306809097293',1792740828226);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('01e92c57-35e6-449f-8464-4124827f5da2','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740828258,31),('02022079-17c9-4427-86a6-7121c3d2d479','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":920,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740829935,43),('0c43ed47-9005-463b-9bca-f470f5acd75a','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":924,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740830073,47),('21557721-a85c-47ef-af03-90d11756ac13','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":857,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826529,23),('22dfa867-a952-458e-91bb-6377867de991','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":847,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740826174,13),('2fa1a00c-1acc-42dc-b1c8-32cd000823e0','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'owner_registered','{}',1792740828232,30),('323ddeb6-a3fb-42e6-a4e5-b7af13f6fc3b','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":854,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826439,20),('34b7788a-0849-498c-9950-94f0d93c0fef','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'owner_registered','{}',1792740824618,3),('36641c0b-15f3-40a0-bc3c-045051a44fcb','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":849,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826229,15),('37bd608e-d8ea-4fe9-88bd-c27fe8a02cdf','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":851,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826339,17),('38c2d549-c2d5-45d1-8695-1a69dc52231d','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'revoking','{\"operation\":\"1896397d-3fcb-4afa-b4e4-30a57b9a3df2\"}',1792740827266,24),('39632332-0061-4c0a-87d7-bdd0b5f79f4d','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":916,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740829750,39),('3cf205b1-48e5-4897-922e-17d6fbf77694','22ba2f26-ac57-4980-a47b-7535314e254a','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":2,\"grant\":\"57e0492e-cc8b-4649-b01b-71396cee1799\",\"permit\":\"a4ee8ac7-a2ff-4376-a70a-bebe692f07c9\"}',1792740829400,36),('460171c5-3af8-44ab-992d-920f7e4af385','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":843,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740824724,7),('4b76f2f3-4ba9-4dad-bbd3-6b6f27834ce2','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":914,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740829146,35),('51c1cda4-208f-4de1-a89e-d88b7ee12b19','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":850,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826316,16),('5538e61c-7454-44b5-bd03-91340c5e7136','161003a1-d235-42ba-9cc7-7a6b7950b80e','table-00','writer_active','{\"grant\":\"ec77d773-03a4-42b4-8642-756122364f4c\",\"permit\":\"1d67d3be-f800-4a01-9466-d09309964a00\"}',1792740826128,11),('5a45bfa7-3c2d-45bf-8e5d-72eb591fd0d0','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'db_drained','{\"complete\":true,\"emptyRounds\":2,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[841,842,843,844,845,846,847,848,849,850,851,852,853,854,855,856,857],\"observedAt\":1792740827511,\"owner\":\"161003a1-d235-42ba-9cc7-7a6b7950b80e\",\"serverStarted\":1792740369525,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740827550,27),('5ff9af5e-e159-40ea-8b3c-496b40e016a7','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":933,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740830263,56),('6326594c-eeb1-46cc-8621-920e792183d9','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":853,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826404,19),('696ee64e-1764-4e92-ab6e-4a7a2e96d5a4','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":918,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740829818,41),('69aa77d9-146e-45de-9cb2-67e8760654ac','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'database_observed','{\"complete\":true,\"emptyRounds\":1,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[841,842,843,844,845,846,847,848,849,850,851,852,853,854,855,856,857],\"observedAt\":1792740827365,\"owner\":\"161003a1-d235-42ba-9cc7-7a6b7950b80e\",\"serverStarted\":1792740369371,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740827392,26),('722eae2d-02a6-46d6-b5a2-be364c0da9af','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":926,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740830116,49),('7828455e-8891-474d-a0c1-41402868c0b9','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":923,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740830019,46),('7e03c51c-8525-4420-8363-1822db7d97ac','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":922,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740830000,45),('85152c0a-3abd-436e-9570-bea75021753d','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":927,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740830133,50),('92ab55ec-76c5-498a-8508-3c21dba21ecc','22ba2f26-ac57-4980-a47b-7535314e254a','table-00','writer_active','{\"grant\":\"57e0492e-cc8b-4649-b01b-71396cee1799\",\"permit\":\"a4ee8ac7-a2ff-4376-a70a-bebe692f07c9\"}',1792740829723,38),('93591c21-aa21-43ac-8bed-9ec76030985b','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":929,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740830183,52),('963f5c53-2579-4075-b0fa-490fad82adc7','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":931,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740830234,54),('96d92a76-5ac6-490f-8663-861787147a19','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":919,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740829833,42),('9753536e-8541-4881-83cd-da59d19278f4','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":913,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740828336,34),('a2b50ea0-82e8-4a0c-a293-de0062cf8971','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":842,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740824698,6),('a58c30f6-ae23-4742-8179-cd24500000c2','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":925,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740830091,48),('a6d0a5c7-a237-4479-98f0-ddf483329615','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":928,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740830171,51),('b0030b55-4b0e-4f8a-9a37-090b48139273','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":930,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740830221,53),('b023f302-50fa-4741-91e7-c13028e14d05','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":917,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740829768,40),('bac98e52-f647-4cc8-8998-8c27656d1d3f','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":841,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740824658,5),('bb98a30f-bd83-4ca1-9c23-a41591a82353','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'fenced','{\"confirmedAt\":1792740827292,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"1896397d-3fcb-4afa-b4e4-30a57b9a3df2\",\"owner\":\"161003a1-d235-42ba-9cc7-7a6b7950b80e\",\"pid\":96972,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:33:44.046Z\"}',1792740827305,25),('beb3dc4c-a106-4c88-8fb9-72a8d09b111b','161003a1-d235-42ba-9cc7-7a6b7950b80e','table-00','old_quota_released','{\"grant\":\"ec77d773-03a4-42b4-8642-756122364f4c\"}',1792740827606,29),('bf3284a0-1540-4739-b0cf-c6ca8894ebe5','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":911,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740828269,32),('c14f3e21-ee94-468f-be2f-85cc83d37f7f','161003a1-d235-42ba-9cc7-7a6b7950b80e','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"ec77d773-03a4-42b4-8642-756122364f4c\",\"permit\":\"1d67d3be-f800-4a01-9466-d09309964a00\"}',1792740825821,9),('c3bd5dba-914c-4a62-8291-c8b263d72f12','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":855,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826454,21),('d3388b41-7481-4976-96e2-ef52a63afa46','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":921,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740829953,44),('d890825b-8507-48a0-9d5f-facf4bdd730e','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":932,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740830249,55),('d8bce353-1ff3-47b5-8394-c52bf6ae53c3','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":915,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740829557,37),('d8c6d95b-540a-42ba-82ce-b90b74dd3271','22ba2f26-ac57-4980-a47b-7535314e254a',NULL,'session_registered','{\"connection\":912,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740828308,33),('e38d45d2-7eac-400c-bec6-4d79493c53da','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":852,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826384,18),('e46465f2-a9ec-455a-af6f-8befa9b085ca','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":848,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826210,14),('e91db42c-a173-4324-9d6d-b200623f7ea7','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740824645,4),('e9f87238-0f25-4f5d-b861-e220ee0da099','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":856,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740826513,22),('f03ccf58-4195-49a4-b872-11856a47dbc4','22ba2f26-ac57-4980-a47b-7535314e254a','table-00','quota_released','{\"disposition\":\"completed\",\"grant\":\"57e0492e-cc8b-4649-b01b-71396cee1799\"}',1792740830333,58),('f0cd2330-7ca4-47ea-b258-b71a09eff9ce','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":846,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740826153,12),('f848d9f5-d7ba-46f3-ba19-7c0516f7d30b','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":844,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740825540,8),('fe6a4bba-76cf-4c2e-afca-9de26f3689e2','161003a1-d235-42ba-9cc7-7a6b7950b80e',NULL,'session_registered','{\"connection\":845,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740825994,10);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','22ba2f26-ac57-4980-a47b-7535314e254a',2,'a4ee8ac7-a2ff-4376-a70a-bebe692f07c9','57e0492e-cc8b-4649-b01b-71396cee1799','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'f47507062ab494919607f66f01ae8a079323b8d10edea24dd768a4a56f3b2242','parked','161003a1-d235-42ba-9cc7-7a6b7950b80e');
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
INSERT INTO `pekko_sync_batch_ledger` VALUES ('0cbd21bb92d396c48e763f2173025d33ca42225a7d88131e016574572c1e2a40','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:2',0,'mysql.snapshot-split.v1','9007199254740993','9007199254740993',2,2,'2026-10-23 07:33:50.267752'),('79c0d5da36e9eac4b2ea24d2b08859fbf36084a47558971cdf352ba433952092','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:1',0,'mysql.snapshot-split.v1','5','7',2,2,'2026-10-23 07:33:50.140503'),('9009ad9bff0f48ed93802f5414c9285e337f72bf65b71814416d48c1b1d2769a','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:1',1,'mysql.snapshot-split.v1','7','7',2,2,'2026-10-23 07:33:50.187331'),('da8f07fe387417bddd4e49f9bfc20508d42949307ca4577abc895bc518b5c30a','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:0',1,'mysql.snapshot-split.v1','3','3',2,2,'2026-10-23 07:33:50.029073'),('e0dc3da589d2aef089b7dec31db118a4423547cb3a94aad6372ea5805f5cc253','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','58615ea09c091a47bc5e48ab909fa37b584b13a702a4e7fc454538e9d0e72c6f:0',0,'mysql.snapshot-split.v1','1','3',2,2,'2026-10-23 07:33:49.961758');
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,58,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_00e0a4868c64\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_00e0a4868c64\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'completed','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',57,0,NULL,NULL);
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
INSERT INTO `target_audit` VALUES (1,'I',-9,NULL,2,NULL,'负键🙂'),(2,'I',1,NULL,0,NULL,'初始-1'),(3,'I',2,NULL,0,NULL,'初始-2'),(4,'I',3,NULL,0,NULL,'初始-3'),(5,'I',4,NULL,0,NULL,'初始-4'),(6,'I',5,NULL,0,NULL,'初始-5'),(7,'I',6,NULL,0,NULL,'初始-6'),(8,'I',7,NULL,0,NULL,'初始-7'),(9,'I',8,NULL,0,NULL,'初始-8'),(10,'I',9007199254740993,NULL,3,NULL,'大键🙂');
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
INSERT INTO `target_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_1f6cf2326971` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_1f6cf2326971`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'abc2da21-14c5-427a-b68d-7cf9546c2d79',1792740777967,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_1f6cf2326971\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_1f6cf2326971\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g�_\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'abc2da21-14c5-427a-b68d-7cf9546c2d79',1792740777967,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g�_\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'abc2da21-14c5-427a-b68d-7cf9546c2d79',1792740777967,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$a25140d7-4e06-4584-b679-e316fc9468c0itimestamp\0\0�g�_\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'abc2da21-14c5-427a-b68d-7cf9546c2d79',1792740778144,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0lsourceNodeIdfsourcekfingerprintx@bdf03e75ff01525b32e8f8d9d18297fce2eca2d0a98033871b6e84c01e93f67deupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g�`��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'abc2da21-14c5-427a-b68d-7cf9546c2d79',1792740778214,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:0eindex\0elower\�euppera3��itimestamp\0\0�g�`\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'abc2da21-14c5-427a-b68d-7cf9546c2d79',1792740778267,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:1eindexelowera3euppera7��itimestamp\0\0�g�a�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'abc2da21-14c5-427a-b68d-7cf9546c2d79',1792740778329,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g�aX�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'abc2da21-14c5-427a-b68d-7cf9546c2d79',1792740778340,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:0�itimestamp\0\0�g�ad�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(9,0,'workflow-table-00',9,'da498482-deee-471a-89c8-5078c3b298af',1792740781759,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$d426a245-d9ee-4916-bda4-24ce203fbbbditimestamp\0\0�g�n��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(10,0,'workflow-table-00',10,'da498482-deee-471a-89c8-5078c3b298af',1792740781860,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.RetrySnapshotSplitbidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:0gattempt�itimestamp\0\0�g�o#�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(11,0,'workflow-table-00',11,'da498482-deee-471a-89c8-5078c3b298af',1792740781995,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:0mbatchSequence\0gbatchIdx@b0ea07f4efa804b7ccc46980d777d9bbb53bf64e7f7921bb46c33370c78c49cbfcursor�dkindwmysql.snapshot-split.v1evaluea1jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�o��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(12,0,'workflow-table-00',12,'da498482-deee-471a-89c8-5078c3b298af',1792740782053,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:0mbatchSequencegbatchIdx@9edf8f2c7b9dbe360c5608e197d3adec7b3dd9ca3f16e75ec476b3299522b56bfcursor�dkindwmysql.snapshot-split.v1evaluea3jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�o\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(13,0,'workflow-table-00',13,'da498482-deee-471a-89c8-5078c3b298af',1792740782059,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:0gattempt�itimestamp\0\0�g�o\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(14,0,'workflow-table-00',14,'da498482-deee-471a-89c8-5078c3b298af',1792740782066,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:1�itimestamp\0\0�g�o\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(15,0,'workflow-table-00',15,'da498482-deee-471a-89c8-5078c3b298af',1792740782147,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:1mbatchSequence\0gbatchIdx@37be3445090e0d3521b7a5b4b2bc63f879767adc5e17e00aa4636350543aac4efcursor�dkindwmysql.snapshot-split.v1evaluea5jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�pC�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(16,0,'workflow-table-00',16,'da498482-deee-471a-89c8-5078c3b298af',1792740782189,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:1mbatchSequencegbatchIdx@4402ca85506bc118dd6f0660488823b5b5555713c487ee84ea5e6fe514a2055cfcursor�dkindwmysql.snapshot-split.v1evaluea7jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�pm�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(17,0,'workflow-table-00',17,'da498482-deee-471a-89c8-5078c3b298af',1792740782193,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:1gattempt\0�itimestamp\0\0�g�pp�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(18,0,'workflow-table-00',18,'da498482-deee-471a-89c8-5078c3b298af',1792740782196,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:2�itimestamp\0\0�g�pt�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(19,0,'workflow-table-00',19,'da498482-deee-471a-89c8-5078c3b298af',1792740782259,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:2mbatchSequence\0gbatchIdx@a3c3a31f53565622ee38df4a3b94ebf06202294c6048109305696e36e7f3d32afcursor�dkindwmysql.snapshot-split.v1evaluep9007199254740993jupperBoundp9007199254740993�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�p��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(20,0,'workflow-table-00',20,'da498482-deee-471a-89c8-5078c3b298af',1792740782263,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:2gattempt\0�itimestamp\0\0�g�p��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(21,0,'workflow-table-00',21,'da498482-deee-471a-89c8-5078c3b298af',1792740782267,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RetireSnapshotWindow$�itimestamp\0\0�g�p��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(22,0,'workflow-table-00',22,'da498482-deee-471a-89c8-5078c3b298af',1792740782273,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex>cn.xuyinyin.magic.workflow.snapshot.FinishSnapshotEnumeration$�itimestamp\0\0�g�p��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(23,0,'workflow-table-00',23,'da498482-deee-471a-89c8-5078c3b298af',1792740782280,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfresult�fstatusicompletedgsuccess\�gmessagex\'Workflow executed successfully in 476msmrowsProcessed\nphasRowsProcessed\�hduration\�khasDuration\�knodeResults��fnodeIdfsourcehnodeTypenmysql.snapshotfstatusicompletedgmessage`jhasMessage\�hduration\�khasDuration\���fnodeIdftargethnodeTypekmysql.writefstatusicompletedgmessage`jhasMessage\�hduration\�khasDuration\����itimestamp\0\0�g�p\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-1f6cf2326971',90);
            DO RELEASE_LOCK('owner-probe-1f6cf2326971');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'d817f510-8517-4960-a9c8-f15ab6e432ec','d7629134-2fb7-4aa7-a7f1-0232da40641a');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'5d28c0de-850c-4af5-a202-7a297bfd2995','fdea0df0-0fc9-42b7-894f-e1ee7e3108b6',1,10),(2,'5d28c0de-850c-4af5-a202-7a297bfd2995','fdea0df0-0fc9-42b7-894f-e1ee7e3108b6',1,10),(3,'5d28c0de-850c-4af5-a202-7a297bfd2995','fdea0df0-0fc9-42b7-894f-e1ee7e3108b6',1,10),(4,'5d28c0de-850c-4af5-a202-7a297bfd2995','fdea0df0-0fc9-42b7-894f-e1ee7e3108b6',1,15),(5,'5d28c0de-850c-4af5-a202-7a297bfd2995','fdea0df0-0fc9-42b7-894f-e1ee7e3108b6',1,18),(6,'5d28c0de-850c-4af5-a202-7a297bfd2995','fdea0df0-0fc9-42b7-894f-e1ee7e3108b6',1,20),(7,'5d28c0de-850c-4af5-a202-7a297bfd2995','fdea0df0-0fc9-42b7-894f-e1ee7e3108b6',1,22),(8,'5d28c0de-850c-4af5-a202-7a297bfd2995','fdea0df0-0fc9-42b7-894f-e1ee7e3108b6',1,22),(9,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,38),(10,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,41),(11,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,45),(12,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,47),(13,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,47),(14,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,47),(15,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,51),(16,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,53),(17,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,53),(18,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,53),(19,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,57),(20,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,57),(21,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,57),(22,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,57),(23,'48089f02-bb41-42d5-961e-3e65e4ee9bb6','fcb704bb-b03f-4970-8421-8a7ce5f36693',2,57);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('48089f02-bb41-42d5-961e-3e65e4ee9bb6',2,'d7629134-2fb7-4aa7-a7f1-0232da40641a','launched'),('5d28c0de-850c-4af5-a202-7a297bfd2995',1,'d7629134-2fb7-4aa7-a7f1-0232da40641a','retired');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_batch_evidence` VALUES ('37be3445090e0d3521b7a5b4b2bc63f879767adc5e17e00aa4636350543aac4e','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316'),('4402ca85506bc118dd6f0660488823b5b5555713c487ee84ea5e6fe514a2055c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c'),('9edf8f2c7b9dbe360c5608e197d3adec7b3dd9ca3f16e75ec476b3299522b56b','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab'),('a3c3a31f53565622ee38df4a3b94ebf06202294c6048109305696e36e7f3d32a','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79'),('b0ea07f4efa804b7ccc46980d777d9bbb53bf64e7f7921bb46c33370c78c49cb','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62');
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369147,'[\"root\"]',NULL,0,0,NULL),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369562,'[\"root\"]',1792740779115,2,1,'{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319],\"observedAt\":1792740779262,\"owner\":\"5d28c0de-850c-4af5-a202-7a297bfd2995\",\"serverStarted\":1792740369272,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]}');
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',355,'control',1792740780172),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',356,'control',1792740780213),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',357,'control',1792740780247),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',358,'control',1792740781162),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',359,'journal',1792740781626),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',360,'target',1792740781815),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',361,'target',1792740781831),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',362,'source',1792740781887),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',363,'source',1792740781909),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',364,'target',1792740781959),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',365,'target',1792740781976),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',366,'target',1792740782020),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',367,'target',1792740782034),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',368,'source',1792740782082),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',369,'source',1792740782095),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',370,'target',1792740782113),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',371,'target',1792740782131),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',372,'target',1792740782160),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',373,'target',1792740782172),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',374,'source',1792740782207),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',375,'source',1792740782217),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',376,'target',1792740782232),('48089f02-bb41-42d5-961e-3e65e4ee9bb6','127.0.0.1:32816',377,'target',1792740782243),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',302,'control',1792740776593),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',303,'control',1792740776627),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',304,'control',1792740776654),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',305,'control',1792740777458),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',306,'journal',1792740777923),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',307,'target',1792740778058),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',308,'target',1792740778075),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',309,'source',1792740778109),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',310,'source',1792740778126),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',311,'source',1792740778176),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',312,'source',1792740778193),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',313,'control',1792740778208),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',314,'source',1792740778235),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',315,'source',1792740778250),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',316,'source',1792740778296),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',317,'source',1792740778312),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',318,'source',1792740778364),('5d28c0de-850c-4af5-a202-7a297bfd2995','127.0.0.1:32816',319,'source',1792740778385);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('48089f02-bb41-42d5-961e-3e65e4ee9bb6','takeover-experiment',95799,'2026-10-23T07:32:59.506Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:65155|3676706276803872471',1792740780137),('5d28c0de-850c-4af5-a202-7a297bfd2995','takeover-experiment',95761,'2026-10-23T07:32:56.007Z','db_drained','9c869ce3-ccf0-4b6f-bb93-df79d9ab53dd',1,1,'{\"confirmedAt\":1792740779046,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"9c869ce3-ccf0-4b6f-bb93-df79d9ab53dd\",\"owner\":\"5d28c0de-850c-4af5-a202-7a297bfd2995\",\"pid\":95761,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:32:56.007Z\"}','pekko://snapshot-takeover@127.0.0.1:65071|6840326272883996820',1792740779284);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('002f4dfe-69d2-4ada-b42f-e67c4f760145','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":317,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778312,22),('07672b78-c0cd-4d7e-b1a4-49f3d8111e52','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'fenced','{\"confirmedAt\":1792740779046,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"9c869ce3-ccf0-4b6f-bb93-df79d9ab53dd\",\"owner\":\"5d28c0de-850c-4af5-a202-7a297bfd2995\",\"pid\":95761,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:32:56.007Z\"}',1792740779056,26),('0d4518fe-68a4-4857-92c6-8ce78c5f2337','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":316,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778296,21),('0d4c0b93-5991-461d-85a7-86448cf8e913','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":358,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740781162,36),('1035b2ea-e39c-4783-a400-7e9975c9d84a','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'owner_registered','{}',1792740780142,31),('1c198e8a-dea8-430d-b7e5-07904a3e1665','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'db_drained','{\"complete\":true,\"emptyRounds\":2,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319],\"observedAt\":1792740779262,\"owner\":\"5d28c0de-850c-4af5-a202-7a297bfd2995\",\"serverStarted\":1792740369272,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740779285,28),('1d155c52-c6d8-4ac1-b58e-fc68a33c9233','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":304,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740776654,7),('2926dc1a-4d12-4524-95bc-7cf2520308b3','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":360,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740781815,40),('294d3e44-9038-479f-9e32-4af1828dbdd1','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":309,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778109,14),('2cc2ea81-b461-4f2b-a40b-1d98e711210e','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":318,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778364,23),('2f5f5a40-e0e7-4fb3-9095-aebce4cb866a','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740776582,4),('300b4662-8273-4255-a14a-a00bc8202499','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":371,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740782131,51),('3b1ffc8a-7d7e-4dfa-9b7f-e72fcc0d1e6a','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":355,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740780173,33),('3bc1a722-922d-40d2-949a-aebb6f66af33','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":367,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740782034,47),('3e6e88ac-fbc0-4960-834a-c886900e17af','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":369,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740782096,49),('4009d531-d698-487d-ac0f-58e17e6bbdf9','5d28c0de-850c-4af5-a202-7a297bfd2995','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"a25140d7-4e06-4584-b679-e316fc9468c0\",\"permit\":\"fdea0df0-0fc9-42b7-894f-e1ee7e3108b6\"}',1792740777743,9),('4878bc18-b1d5-42c8-82f4-3a2fa8b90f1c','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":319,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778385,24),('48e4b5cf-9bf9-4b53-959a-8571529d56c0','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":363,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740781909,43),('4da55a96-4282-46d1-9d3f-a6fc84a96e7a','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":356,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740780214,34),('5379b9db-ed39-4b12-b27a-21cff10deff7','48089f02-bb41-42d5-961e-3e65e4ee9bb6','table-00','writer_active','{\"grant\":\"d426a245-d9ee-4916-bda4-24ce203fbbbd\",\"permit\":\"fcb704bb-b03f-4970-8421-8a7ce5f36693\"}',1792740781794,39),('5c65f6e5-c4f3-42e3-96ff-6db6633802f1','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":313,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740778209,18),('5eddb3bd-2767-44fc-8fe2-99dd417b541a','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":314,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778235,19),('61bdc58b-d033-412f-b314-30c86cf41779','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":308,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740778075,13),('65793b32-5412-4796-b4cb-c1fe79f8854f','48089f02-bb41-42d5-961e-3e65e4ee9bb6','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":2,\"grant\":\"d426a245-d9ee-4916-bda4-24ce203fbbbd\",\"permit\":\"fcb704bb-b03f-4970-8421-8a7ce5f36693\"}',1792740781443,37),('6d604420-c5ff-456a-928a-393662cfd1be','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":375,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740782217,55),('775636d6-b5db-475d-8671-ec318aa9524f','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":364,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740781959,44),('7850d6b6-4336-48cb-bb5b-c7eb51071794','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740780163,32),('78e20c41-894f-48b9-9af2-4c880ac75580','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":374,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740782207,54),('7a7be323-b8d9-458a-aee7-0baf85933108','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'owner_registered','{}',1792740776556,3),('8ba19c2a-4808-44e8-84c1-151e02641f0e','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":366,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740782021,46),('8be76fee-32f9-409d-ae5f-6c0abab0d965','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":373,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740782172,53),('8c68eb86-a30f-406a-a23b-e86df6c57364','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":372,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740782161,52),('965ba96b-43c0-4be6-8db7-271a4ba7a115','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":365,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740781977,45),('9abc5b0f-840f-483e-9e72-b8b38ced720b','5d28c0de-850c-4af5-a202-7a297bfd2995','table-00','writer_active','{\"grant\":\"a25140d7-4e06-4584-b679-e316fc9468c0\",\"permit\":\"fdea0df0-0fc9-42b7-894f-e1ee7e3108b6\"}',1792740778036,11),('9e6a2f09-7a81-4089-b875-25f3ec1cc3d4','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":357,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740780247,35),('a081bd54-9031-4fac-8777-0c0b5813896c','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":315,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778251,20),('a72e03d1-c3d4-447a-afd7-3f45ea3b19a5','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'database_observed','{\"complete\":true,\"emptyRounds\":1,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319],\"observedAt\":1792740779115,\"owner\":\"5d28c0de-850c-4af5-a202-7a297bfd2995\",\"serverStarted\":1792740369123,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740779141,27),('aa3a1e9e-4e45-4b5d-94ee-f1f63ce4c7e4','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":368,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740782082,48),('ac7981c7-4399-4026-ac75-788b7e8f59e3','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":376,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740782232,56),('ad69b527-1cbd-42dc-a368-bd59c214ce75','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":362,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740781888,42),('adff32fa-2e76-4c36-8d84-9e4b4f7af1d7','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":307,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740778058,12),('b4a8edcf-bfa3-481f-aaa7-c3b47b6206da','5d28c0de-850c-4af5-a202-7a297bfd2995','table-00','old_quota_released','{\"grant\":\"a25140d7-4e06-4584-b679-e316fc9468c0\"}',1792740779355,30),('b53292ee-7541-432e-a293-69b5ced223fe','48089f02-bb41-42d5-961e-3e65e4ee9bb6','table-00','quota_released','{\"disposition\":\"completed\",\"grant\":\"d426a245-d9ee-4916-bda4-24ce203fbbbd\"}',1792740782321,59),('b5e9455a-7840-4721-8868-d97bcb151d78','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":302,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740776594,5),('b917e516-c068-45ed-83b3-5e740fd330a7','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":377,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740782243,57),('bb1f1299-aa2d-4255-be4c-1fe78e39385e','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":303,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740776628,6),('cde4693a-c691-484d-9e4b-48405516293e','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":312,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778193,17),('d4070efa-b4f2-4620-a491-e947067ef5df','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":359,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740781627,38),('dc6a4b6c-1f69-4494-9588-8445bbeb1be3','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'revoking','{\"operation\":\"9c869ce3-ccf0-4b6f-bb93-df79d9ab53dd\"}',1792740779024,25),('e65c77e8-49f2-49c8-a48b-f29887575f38','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":370,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740782114,50),('ea712293-78df-4871-891c-fd5baf1f3340','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":305,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740777459,8),('ec6af829-f22a-48be-a8e6-743a4521a8fa','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":310,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778126,15),('ecdfce5a-1ca6-415a-aa62-61a762e52ab6','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":311,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740778176,16),('f13cd8a3-c8ad-4936-9af6-5bc55b55ba73','48089f02-bb41-42d5-961e-3e65e4ee9bb6',NULL,'session_registered','{\"connection\":361,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740781832,41),('f77d82da-ba58-409a-b5a3-f07076c1603e','5d28c0de-850c-4af5-a202-7a297bfd2995',NULL,'session_registered','{\"connection\":306,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740777924,10);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','48089f02-bb41-42d5-961e-3e65e4ee9bb6',2,'fcb704bb-b03f-4970-8421-8a7ce5f36693','d426a245-d9ee-4916-bda4-24ce203fbbbd','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'afebd997f7864b599ac152819e2e90f565be854a53dbada3c785e372484bc190','parked','5d28c0de-850c-4af5-a202-7a297bfd2995');
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
INSERT INTO `pekko_sync_batch_ledger` VALUES ('37be3445090e0d3521b7a5b4b2bc63f879767adc5e17e00aa4636350543aac4e','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:1',0,'mysql.snapshot-split.v1','5','7',2,2,'2026-10-23 07:33:02.136054'),('4402ca85506bc118dd6f0660488823b5b5555713c487ee84ea5e6fe514a2055c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:1',1,'mysql.snapshot-split.v1','7','7',2,2,'2026-10-23 07:33:02.178334'),('9edf8f2c7b9dbe360c5608e197d3adec7b3dd9ca3f16e75ec476b3299522b56b','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:0',1,'mysql.snapshot-split.v1','3','3',2,2,'2026-10-23 07:33:02.042096'),('a3c3a31f53565622ee38df4a3b94ebf06202294c6048109305696e36e7f3d32a','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:2',0,'mysql.snapshot-split.v1','9007199254740993','9007199254740993',2,2,'2026-10-23 07:33:02.248569'),('b0ea07f4efa804b7ccc46980d777d9bbb53bf64e7f7921bb46c33370c78c49cb','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','0b28cb70c90af668c9344db3f3ec58c16111d7c66fd476df8aa8c07a660189d0:0',0,'mysql.snapshot-split.v1','1','3',2,2,'2026-10-23 07:33:01.984705');
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,59,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_1f6cf2326971\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_1f6cf2326971\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'completed','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',58,0,NULL,NULL);
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
INSERT INTO `target_audit` VALUES (1,'I',-9,NULL,2,NULL,'负键🙂'),(2,'I',1,NULL,0,NULL,'初始-1'),(3,'I',2,NULL,0,NULL,'初始-2'),(4,'I',3,NULL,0,NULL,'初始-3'),(5,'I',4,NULL,0,NULL,'初始-4'),(6,'I',5,NULL,0,NULL,'初始-5'),(7,'I',6,NULL,0,NULL,'初始-6'),(8,'I',7,NULL,0,NULL,'初始-7'),(9,'I',8,NULL,0,NULL,'初始-8'),(10,'I',9007199254740993,NULL,3,NULL,'大键🙂');
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
INSERT INTO `target_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_2822ae813f68` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_2822ae813f68`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'146d5801-d14e-4233-afae-d83d0684d0e3',1792740786642,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_2822ae813f68\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_2822ae813f68\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'146d5801-d14e-4233-afae-d83d0684d0e3',1792740786642,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'146d5801-d14e-4233-afae-d83d0684d0e3',1792740786642,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$78c713f3-1b43-4c72-aabf-15e30f4706f4itimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'146d5801-d14e-4233-afae-d83d0684d0e3',1792740786821,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@cb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ecelsourceNodeIdfsourcekfingerprintx@3472195ed52a6541d215b3d28ce99a65a537503648149a8fb34c2425db42acc8eupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'146d5801-d14e-4233-afae-d83d0684d0e3',1792740786888,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:0eindex\0elower\�euppera3��itimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'146d5801-d14e-4233-afae-d83d0684d0e3',1792740786942,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:1eindexelowera3euppera7��itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'146d5801-d14e-4233-afae-d83d0684d0e3',1792740786988,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g��,�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'146d5801-d14e-4233-afae-d83d0684d0e3',1792740786999,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:0�itimestamp\0\0�g��7�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(9,0,'workflow-table-00',9,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740789759,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$54ce392a-1290-4702-b58e-b51fab6e4340itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(10,0,'workflow-table-00',10,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740789861,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.RetrySnapshotSplitbidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:0gattempt�itimestamp\0\0�g��e�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(11,0,'workflow-table-00',11,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790059,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:0mbatchSequence\0gbatchIdx@c200c238ee61950965976c5b6c42a3a28dbc48a1452832df3a386c16f12ab9c5fcursor�dkindwmysql.snapshot-split.v1evaluea1jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g��+�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(12,0,'workflow-table-00',12,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790117,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:0mbatchSequencegbatchIdx@2673300d82954eb45414f4f25e512e07a80c0291cafe1f16d6fb6f2db92f95c8fcursor�dkindwmysql.snapshot-split.v1evaluea3jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g��e�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(13,0,'workflow-table-00',13,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790126,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:0gattempt�itimestamp\0\0�g��n�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(14,0,'workflow-table-00',14,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790135,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:1�itimestamp\0\0�g��w�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(15,0,'workflow-table-00',15,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790216,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:1mbatchSequence\0gbatchIdx@43bfc5fe85f6d8f9dae9af2f9b13c6e1f774799585df389e682a6afc319f8142fcursor�dkindwmysql.snapshot-split.v1evaluea5jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(16,0,'workflow-table-00',16,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790264,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:1mbatchSequencegbatchIdx@fba34ec29ec404e9fbd19aebcd2cdd34651ed8a2d9c856823c51963691f91acdfcursor�dkindwmysql.snapshot-split.v1evaluea7jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(17,0,'workflow-table-00',17,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790270,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:1gattempt\0�itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(18,0,'workflow-table-00',18,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790275,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:2�itimestamp\0\0�g���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(19,0,'workflow-table-00',19,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790368,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:2mbatchSequence\0gbatchIdx@a56affbd677dd032c8ccdf7edad97d1efa1d00b01d832c4ed3567ac5fffff89efcursor�dkindwmysql.snapshot-split.v1evaluep9007199254740993jupperBoundp9007199254740993�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g��`�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(20,0,'workflow-table-00',20,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790375,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBcb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:2gattempt\0�itimestamp\0\0�g��g�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(21,0,'workflow-table-00',21,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790383,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RetireSnapshotWindow$�itimestamp\0\0�g��o�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(22,0,'workflow-table-00',22,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790392,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex>cn.xuyinyin.magic.workflow.snapshot.FinishSnapshotEnumeration$�itimestamp\0\0�g��x�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(23,0,'workflow-table-00',23,'71eb7b9d-cbf7-410a-bdf4-b9feb40548fc',1792740790403,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfresult�fstatusicompletedgsuccess\�gmessagex\'Workflow executed successfully in 598msmrowsProcessed\nphasRowsProcessed\�hdurationVkhasDuration\�knodeResults��fnodeIdfsourcehnodeTypenmysql.snapshotfstatusicompletedgmessage`jhasMessage\�hdurationVkhasDuration\���fnodeIdftargethnodeTypekmysql.writefstatusicompletedgmessage`jhasMessage\�hdurationVkhasDuration\����itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-2822ae813f68',90);
            DO RELEASE_LOCK('owner-probe-2822ae813f68');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'93fd07e7-5635-4fc3-98d7-ab4bed8c6f8d','9c519948-751e-496d-a8e9-27a14e4d24b2');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'9a6945e3-e1e7-4240-b350-05d5722ed371','cd307b38-c137-410e-8ff6-c120003b0512',1,10),(2,'9a6945e3-e1e7-4240-b350-05d5722ed371','cd307b38-c137-410e-8ff6-c120003b0512',1,10),(3,'9a6945e3-e1e7-4240-b350-05d5722ed371','cd307b38-c137-410e-8ff6-c120003b0512',1,10),(4,'9a6945e3-e1e7-4240-b350-05d5722ed371','cd307b38-c137-410e-8ff6-c120003b0512',1,15),(5,'9a6945e3-e1e7-4240-b350-05d5722ed371','cd307b38-c137-410e-8ff6-c120003b0512',1,17),(6,'9a6945e3-e1e7-4240-b350-05d5722ed371','cd307b38-c137-410e-8ff6-c120003b0512',1,19),(7,'9a6945e3-e1e7-4240-b350-05d5722ed371','cd307b38-c137-410e-8ff6-c120003b0512',1,21),(8,'9a6945e3-e1e7-4240-b350-05d5722ed371','cd307b38-c137-410e-8ff6-c120003b0512',1,21),(9,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,37),(10,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,40),(11,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,44),(12,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,46),(13,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,46),(14,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,46),(15,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,50),(16,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,52),(17,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,52),(18,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,52),(19,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,56),(20,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,56),(21,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,56),(22,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,56),(23,'052d0b6b-2a26-491a-876a-a23a55ab61b3','5124f1af-b7c5-47c8-ac4c-993da336d518',2,56);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('052d0b6b-2a26-491a-876a-a23a55ab61b3',2,'9c519948-751e-496d-a8e9-27a14e4d24b2','launched'),('9a6945e3-e1e7-4240-b350-05d5722ed371',1,'9c519948-751e-496d-a8e9-27a14e4d24b2','retired');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_batch_evidence` VALUES ('2673300d82954eb45414f4f25e512e07a80c0291cafe1f16d6fb6f2db92f95c8','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab'),('43bfc5fe85f6d8f9dae9af2f9b13c6e1f774799585df389e682a6afc319f8142','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316'),('a56affbd677dd032c8ccdf7edad97d1efa1d00b01d832c4ed3567ac5fffff89e','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79'),('c200c238ee61950965976c5b6c42a3a28dbc48a1452832df3a386c16f12ab9c5','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62'),('fba34ec29ec404e9fbd19aebcd2cdd34651ed8a2d9c856823c51963691f91acd','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c');
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369436,'[\"root\"]',NULL,0,0,NULL),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369392,'[\"root\"]',1792740787704,2,1,'{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420],\"observedAt\":1792740787842,\"owner\":\"9a6945e3-e1e7-4240-b350-05d5722ed371\",\"serverStarted\":1792740369851,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]}');
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',462,'control',1792740788458),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',463,'control',1792740788496),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',464,'control',1792740788516),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',465,'control',1792740789180),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',466,'journal',1792740789637),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',467,'target',1792740789820),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',468,'target',1792740789836),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',469,'source',1792740789887),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',470,'source',1792740789901),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',471,'target',1792740790021),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',472,'target',1792740790038),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',473,'target',1792740790083),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',474,'target',1792740790100),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',475,'source',1792740790152),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',476,'source',1792740790167),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',477,'target',1792740790186),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',478,'target',1792740790199),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',479,'target',1792740790231),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',480,'target',1792740790246),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',481,'source',1792740790292),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',482,'source',1792740790309),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',483,'target',1792740790336),('052d0b6b-2a26-491a-876a-a23a55ab61b3','127.0.0.1:32816',484,'target',1792740790350),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',404,'control',1792740785421),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',405,'control',1792740785450),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',406,'control',1792740785474),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',407,'control',1792740786174),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',408,'journal',1792740786606),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',409,'target',1792740786728),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',410,'target',1792740786745),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',411,'source',1792740786782),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',412,'source',1792740786798),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',413,'source',1792740786851),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',414,'source',1792740786867),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',415,'source',1792740786909),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',416,'source',1792740786926),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',417,'source',1792740786957),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',418,'source',1792740786970),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',419,'source',1792740787024),('9a6945e3-e1e7-4240-b350-05d5722ed371','127.0.0.1:32816',420,'source',1792740787038);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('052d0b6b-2a26-491a-876a-a23a55ab61b3','takeover-experiment',95831,'2026-10-23T07:33:08.008Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:65317|-837168742626143096',1792740788426),('9a6945e3-e1e7-4240-b350-05d5722ed371','takeover-experiment',95823,'2026-10-23T07:33:04.938Z','db_drained','3fa6faba-06e9-42b8-8e32-1d10ed4e666e',1,1,'{\"confirmedAt\":1792740787626,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"3fa6faba-06e9-42b8-8e32-1d10ed4e666e\",\"owner\":\"9a6945e3-e1e7-4240-b350-05d5722ed371\",\"pid\":95823,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:33:04.938Z\"}','pekko://snapshot-takeover@127.0.0.1:65248|-8290171260338825606',1792740787863);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('01f03083-c7e1-4b8e-bacf-db65d0a2d348','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":480,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790246,52),('022aa398-c432-4ab4-aee6-27c81abf90f1','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":469,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740789888,41),('02db6ec2-70ad-4e7c-95d6-04117c204d6b','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740788450,31),('0ca7ae6b-729f-468a-af6e-d382ef3ac44d','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":412,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740786799,15),('12501c14-eb0b-4b68-b9c9-47e1995a9352','9a6945e3-e1e7-4240-b350-05d5722ed371','table-00','writer_active','{\"grant\":\"78c713f3-1b43-4c72-aabf-15e30f4706f4\",\"permit\":\"cd307b38-c137-410e-8ff6-c120003b0512\"}',1792740786706,11),('134f2548-941d-4ecc-8fda-e256f145a72a','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":478,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790199,50),('14c582f1-2eae-4b21-9785-8ad7e919c4a7','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":484,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790351,56),('168d852f-dce9-4e36-a955-dff027cd7c1d','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":476,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740790167,48),('203661da-4d83-4af8-8bdc-3805304af6c0','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":479,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790231,51),('20847287-e6a2-45b3-aa1f-6fd6f668a2c9','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":463,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740788496,33),('26a4bff9-8ebe-427a-96c6-f092e2f60e38','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":475,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740790152,47),('27e8cc4b-06f9-4fb5-b058-453244a6881e','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":462,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740788460,32),('2f1c3222-5e7d-41a0-b6b6-1d84b6836628','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":417,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740786958,20),('329e2415-839f-43f2-99d4-85971e4cc227','052d0b6b-2a26-491a-876a-a23a55ab61b3','table-00','quota_released','{\"disposition\":\"completed\",\"grant\":\"54ce392a-1290-4702-b58e-b51fab6e4340\"}',1792740790428,58),('384913f7-1ca6-481a-b588-e8ac983bdc8d','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":468,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740789836,40),('3e4d3259-0f4a-43e8-a0e6-e9f67f3d6110','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'fenced','{\"confirmedAt\":1792740787626,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"3fa6faba-06e9-42b8-8e32-1d10ed4e666e\",\"owner\":\"9a6945e3-e1e7-4240-b350-05d5722ed371\",\"pid\":95823,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:33:04.938Z\"}',1792740787640,25),('4445203c-12da-4479-9bb1-2a693c6c343e','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":408,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740786606,10),('4e6823b0-85c3-4d28-bc7a-35cab86ed3aa','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740785410,4),('51d46400-4172-4ff7-b1a1-c895e2b97375','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":404,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740785422,5),('55293bda-4e9f-418b-a7ec-43532bf39c9e','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":483,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790336,55),('5e054e84-7ce8-4325-b545-437a70df9f60','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'db_drained','{\"complete\":true,\"emptyRounds\":2,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420],\"observedAt\":1792740787842,\"owner\":\"9a6945e3-e1e7-4240-b350-05d5722ed371\",\"serverStarted\":1792740369851,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740787864,27),('681311b5-b271-4f7c-b4a3-7d831d9161cf','052d0b6b-2a26-491a-876a-a23a55ab61b3','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":2,\"grant\":\"54ce392a-1290-4702-b58e-b51fab6e4340\",\"permit\":\"5124f1af-b7c5-47c8-ac4c-993da336d518\"}',1792740789459,36),('6941a4ce-7efc-417c-ab1e-26c8973d5277','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":411,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740786782,14),('6b58eda5-0dd1-41d7-96aa-7ffd058b238b','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":481,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740790292,53),('6c7ff0ff-6ada-4ede-b2ae-ee21abd08809','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":470,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740789902,42),('6eedfa4f-0a06-4299-bfe7-e3ff9c6f3141','052d0b6b-2a26-491a-876a-a23a55ab61b3','table-00','writer_active','{\"grant\":\"54ce392a-1290-4702-b58e-b51fab6e4340\",\"permit\":\"5124f1af-b7c5-47c8-ac4c-993da336d518\"}',1792740789792,38),('6f6ab291-17a2-4e07-96c7-692c6c6361b8','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":471,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790021,43),('739f8d3c-5523-47b6-942d-d2a2408b3fe3','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":482,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740790309,54),('75ac1938-cd96-4de3-9f74-e1728695d770','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'database_observed','{\"complete\":true,\"emptyRounds\":1,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420],\"observedAt\":1792740787704,\"owner\":\"9a6945e3-e1e7-4240-b350-05d5722ed371\",\"serverStarted\":1792740369710,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740787727,26),('76965d3a-a76d-4595-bbea-9e62695d2b9f','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":410,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740786746,13),('77d20492-1428-46ce-b2ec-1a47a000d77c','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'revoking','{\"operation\":\"3fa6faba-06e9-42b8-8e32-1d10ed4e666e\"}',1792740787605,24),('7d3d1030-1ba2-4c5d-8bfa-13a04f34ef38','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":473,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790084,45),('7d64ef35-fdc3-4d7d-9338-44044ec59369','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":405,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740785451,6),('7dbbe244-b942-4443-a558-b7d0983c3e5f','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":415,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740786909,18),('805d362c-26df-461c-8727-ba3ed33f00de','9a6945e3-e1e7-4240-b350-05d5722ed371','table-00','old_quota_released','{\"grant\":\"78c713f3-1b43-4c72-aabf-15e30f4706f4\"}',1792740787920,29),('84efc0e8-e293-488c-a361-f81532ea786c','9a6945e3-e1e7-4240-b350-05d5722ed371','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"78c713f3-1b43-4c72-aabf-15e30f4706f4\",\"permit\":\"cd307b38-c137-410e-8ff6-c120003b0512\"}',1792740786459,9),('88404af8-5a86-47c0-94e6-97fa28888a58','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":419,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740787024,22),('8ef9288d-9461-4d16-b0cf-d361b44c1a4c','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":420,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740787039,23),('92a9a818-1529-4531-a3ff-205c7de0170c','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":418,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740786970,21),('9534d0a5-849b-4bdb-8744-2a465a7f2045','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":414,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740786867,17),('99f2493a-4865-43d8-b4cf-ec9f7d2b9d45','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":465,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740789180,35),('a3cf1569-8c9c-4491-a664-249cc471ed46','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'owner_registered','{}',1792740785387,3),('b5071e22-416e-4e24-b169-bee83f80eda7','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":416,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740786926,19),('b5441a07-bbb3-4da7-932e-0e6a5f1dcd24','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":406,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740785475,7),('b7db686d-8247-40fa-ab07-4dfb6967bf69','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":464,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740788517,34),('bb0a5c63-685f-477c-8feb-fad263cec8d8','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":472,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790038,44),('c170fdb6-94ab-48e3-81a5-f839f857724e','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":466,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740789637,37),('c3e19b25-6651-4ea8-a85b-376bc949ab77','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":407,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740786174,8),('cc99bbc9-30d9-492e-93d7-9f434f8f2b42','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":474,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790100,46),('d40d3abd-9361-4550-b649-ec42900662ac','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":413,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740786851,16),('e89d7480-d8fe-469d-a334-b2860d2f5ae7','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":467,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740789820,39),('e9b8e7c8-c534-439f-a4fe-602abdf7c837','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'owner_registered','{}',1792740788432,30),('eeadc437-e14e-461f-8b9d-33330f706bc8','9a6945e3-e1e7-4240-b350-05d5722ed371',NULL,'session_registered','{\"connection\":409,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740786728,12),('fa2a0b14-6b7f-43e4-aec7-3ece7bf3d684','052d0b6b-2a26-491a-876a-a23a55ab61b3',NULL,'session_registered','{\"connection\":477,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740790186,49);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','052d0b6b-2a26-491a-876a-a23a55ab61b3',2,'5124f1af-b7c5-47c8-ac4c-993da336d518','54ce392a-1290-4702-b58e-b51fab6e4340','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'db4f50f4e51506a898f51805a90c992656b278d661b11ab206a00fff99aa8526','parked','9a6945e3-e1e7-4240-b350-05d5722ed371');
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
INSERT INTO `pekko_sync_batch_ledger` VALUES ('2673300d82954eb45414f4f25e512e07a80c0291cafe1f16d6fb6f2db92f95c8','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','cb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:0',1,'mysql.snapshot-split.v1','3','3',2,2,'2026-10-23 07:33:10.107963'),('43bfc5fe85f6d8f9dae9af2f9b13c6e1f774799585df389e682a6afc319f8142','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','cb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:1',0,'mysql.snapshot-split.v1','5','7',2,2,'2026-10-23 07:33:10.205437'),('a56affbd677dd032c8ccdf7edad97d1efa1d00b01d832c4ed3567ac5fffff89e','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','cb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:2',0,'mysql.snapshot-split.v1','9007199254740993','9007199254740993',2,2,'2026-10-23 07:33:10.358058'),('c200c238ee61950965976c5b6c42a3a28dbc48a1452832df3a386c16f12ab9c5','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','cb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:0',0,'mysql.snapshot-split.v1','1','3',2,2,'2026-10-23 07:33:10.047988'),('fba34ec29ec404e9fbd19aebcd2cdd34651ed8a2d9c856823c51963691f91acd','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','cb8d47b2898e2e671142d18d22f051597a6b82a88682a6685ee9e0f879114ece:1',1,'mysql.snapshot-split.v1','7','7',2,2,'2026-10-23 07:33:10.254973');
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,58,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_2822ae813f68\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_2822ae813f68\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'completed','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',57,0,NULL,NULL);
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
INSERT INTO `target_audit` VALUES (1,'I',-9,NULL,2,NULL,'负键🙂'),(2,'I',1,NULL,0,NULL,'初始-1'),(3,'I',2,NULL,0,NULL,'初始-2'),(4,'I',3,NULL,0,NULL,'初始-3'),(5,'I',4,NULL,0,NULL,'初始-4'),(6,'I',5,NULL,0,NULL,'初始-5'),(7,'I',6,NULL,0,NULL,'初始-6'),(8,'I',7,NULL,0,NULL,'初始-7'),(9,'I',8,NULL,0,NULL,'初始-8'),(10,'I',9007199254740993,NULL,3,NULL,'大键🙂');
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
INSERT INTO `target_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_309841ba48a7` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_309841ba48a7`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'ba8d957c-532a-4327-a5a8-01cef082cb33',1792740815686,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_309841ba48a7\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_309841ba48a7\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g�\�@�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'ba8d957c-532a-4327-a5a8-01cef082cb33',1792740815686,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g�\�@�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'ba8d957c-532a-4327-a5a8-01cef082cb33',1792740815686,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$7166726d-1a1f-442f-b8d2-d1e7dafbe7a2itimestamp\0\0�g�\�A�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'ba8d957c-532a-4327-a5a8-01cef082cb33',1792740815974,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838ddlsourceNodeIdfsourcekfingerprintx@a2d898ec1956942b31c83794a878d65b4c4381ced35a50f2f9f51400a565bc5ceupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g�\�d�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'ba8d957c-532a-4327-a5a8-01cef082cb33',1792740816144,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:0eindex\0elower\�euppera3��itimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'ba8d957c-532a-4327-a5a8-01cef082cb33',1792740816211,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:1eindexelowera3euppera7��itimestamp\0\0�g�\�S�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'ba8d957c-532a-4327-a5a8-01cef082cb33',1792740816276,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g�\���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'ba8d957c-532a-4327-a5a8-01cef082cb33',1792740816287,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:0�itimestamp\0\0�g�\���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(9,0,'workflow-table-00',9,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820470,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$7730dbd6-0c76-4ada-a0f8-1e6166c92b22itimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(10,0,'workflow-table-00',10,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820572,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.RetrySnapshotSplitbidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:0gattempt�itimestamp\0\0�g�[�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(11,0,'workflow-table-00',11,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820735,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:0mbatchSequence\0gbatchIdx@6d689c0efc8927926cf286e083c5b5059ece01f90e8f141f86abb42d02dfd515fcursor�dkindwmysql.snapshot-split.v1evaluea1jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(12,0,'workflow-table-00',12,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820806,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:0mbatchSequencegbatchIdx@a1614e8a156ea1536df1c515bb6f50f3804eb6d0ac24bb31d3a981ccb8d90a35fcursor�dkindwmysql.snapshot-split.v1evaluea3jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�F�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(13,0,'workflow-table-00',13,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820827,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:0gattempt�itimestamp\0\0�g�[�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(14,0,'workflow-table-00',14,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820845,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:1�itimestamp\0\0�g�m�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(15,0,'workflow-table-00',15,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820935,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:1mbatchSequence\0gbatchIdx@7d58d4d8958d1af12cd6ceb5d0b7d9f400345ded7cd4d765142b39715b0a6552fcursor�dkindwmysql.snapshot-split.v1evaluea5jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(16,0,'workflow-table-00',16,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820977,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:1mbatchSequencegbatchIdx@31488fad31586ac830127ea9de51e8c6ffadab078cd76f38c43eba5328bcbfe8fcursor�dkindwmysql.snapshot-split.v1evaluea7jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(17,0,'workflow-table-00',17,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820984,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:1gattempt\0�itimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(18,0,'workflow-table-00',18,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740820993,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:2�itimestamp\0\0�g�\0�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(19,0,'workflow-table-00',19,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740821093,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:2mbatchSequence\0gbatchIdx@f3a2a930e59d881c885684057ae8c7888d1085889ca8b8030b3756ded0c7a4cefcursor�dkindwmysql.snapshot-split.v1evaluep9007199254740993jupperBoundp9007199254740993�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�e�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(20,0,'workflow-table-00',20,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740821100,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:2gattempt\0�itimestamp\0\0�g�l�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(21,0,'workflow-table-00',21,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740821108,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RetireSnapshotWindow$�itimestamp\0\0�g�s�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(22,0,'workflow-table-00',22,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740821116,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex>cn.xuyinyin.magic.workflow.snapshot.FinishSnapshotEnumeration$�itimestamp\0\0�g�|�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(23,0,'workflow-table-00',23,'afe43933-0488-4ef5-b10c-820e1cb6a1c4',1792740821130,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfresult�fstatusicompletedgsuccess\�gmessagex\'Workflow executed successfully in 613msmrowsProcessed\nphasRowsProcessed\�hdurationekhasDuration\�knodeResults��fnodeIdfsourcehnodeTypenmysql.snapshotfstatusicompletedgmessage`jhasMessage\�hdurationekhasDuration\���fnodeIdftargethnodeTypekmysql.writefstatusicompletedgmessage`jhasMessage\�hdurationekhasDuration\����itimestamp\0\0�g���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-309841ba48a7',90);
            DO RELEASE_LOCK('owner-probe-309841ba48a7');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'2e355774-7a1e-40e7-bafd-b62462c47744','319ce6a6-f249-4eef-88e5-f8ef946df0a0');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'9900cbe5-e4f5-4fe3-b56c-1f581115728d','203b066f-ad72-48bd-90ed-c1b98d2febb2',1,10),(2,'9900cbe5-e4f5-4fe3-b56c-1f581115728d','203b066f-ad72-48bd-90ed-c1b98d2febb2',1,10),(3,'9900cbe5-e4f5-4fe3-b56c-1f581115728d','203b066f-ad72-48bd-90ed-c1b98d2febb2',1,10),(4,'9900cbe5-e4f5-4fe3-b56c-1f581115728d','203b066f-ad72-48bd-90ed-c1b98d2febb2',1,16),(5,'9900cbe5-e4f5-4fe3-b56c-1f581115728d','203b066f-ad72-48bd-90ed-c1b98d2febb2',1,18),(6,'9900cbe5-e4f5-4fe3-b56c-1f581115728d','203b066f-ad72-48bd-90ed-c1b98d2febb2',1,20),(7,'9900cbe5-e4f5-4fe3-b56c-1f581115728d','203b066f-ad72-48bd-90ed-c1b98d2febb2',1,22),(8,'9900cbe5-e4f5-4fe3-b56c-1f581115728d','203b066f-ad72-48bd-90ed-c1b98d2febb2',1,22),(9,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,39),(10,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,42),(11,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,46),(12,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,48),(13,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,48),(14,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,48),(15,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,52),(16,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,54),(17,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,54),(18,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,54),(19,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,58),(20,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,58),(21,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,58),(22,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,58),(23,'634f542d-ab5c-4287-9a49-2c12101e432b','1254cdf0-f95c-45ed-90b5-ac12d78c0e4a',2,58);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('634f542d-ab5c-4287-9a49-2c12101e432b',2,'319ce6a6-f249-4eef-88e5-f8ef946df0a0','launched'),('9900cbe5-e4f5-4fe3-b56c-1f581115728d',1,'319ce6a6-f249-4eef-88e5-f8ef946df0a0','retired');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_batch_evidence` VALUES ('31488fad31586ac830127ea9de51e8c6ffadab078cd76f38c43eba5328bcbfe8','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c'),('6d689c0efc8927926cf286e083c5b5059ece01f90e8f141f86abb42d02dfd515','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62'),('7d58d4d8958d1af12cd6ceb5d0b7d9f400345ded7cd4d765142b39715b0a6552','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316'),('a1614e8a156ea1536df1c515bb6f50f3804eb6d0ac24bb31d3a981ccb8d90a35','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab'),('f3a2a930e59d881c885684057ae8c7888d1085889ca8b8030b3756ded0c7a4ce','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79');
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369731,'[\"root\"]',NULL,0,0,NULL),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369304,'[\"root\"]',1792740817914,2,1,'{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,730],\"observedAt\":1792740818055,\"owner\":\"9900cbe5-e4f5-4fe3-b56c-1f581115728d\",\"serverStarted\":1792740369067,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]}');
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',790,'control',1792740818765),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',791,'control',1792740818807),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',792,'control',1792740818839),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',793,'control',1792740819620),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',794,'journal',1792740820048),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',795,'journal',1792740820352),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',797,'target',1792740820527),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',798,'target',1792740820543),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',799,'source',1792740820602),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',800,'source',1792740820620),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',801,'target',1792740820696),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',802,'target',1792740820717),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',803,'target',1792740820761),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',804,'target',1792740820786),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',805,'source',1792740820872),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',806,'source',1792740820887),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',807,'target',1792740820904),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',808,'target',1792740820917),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',809,'target',1792740820947),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',810,'target',1792740820962),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',811,'source',1792740821031),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',812,'source',1792740821044),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',813,'target',1792740821062),('634f542d-ab5c-4287-9a49-2c12101e432b','127.0.0.1:32816',814,'target',1792740821078),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',713,'control',1792740814334),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',714,'control',1792740814367),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',715,'control',1792740814397),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',716,'control',1792740815188),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',717,'journal',1792740815643),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',718,'target',1792740815782),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',719,'target',1792740815800),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',720,'source',1792740815849),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',721,'source',1792740815927),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',722,'control',1792740815951),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',723,'source',1792740816031),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',724,'source',1792740816098),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',725,'source',1792740816173),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',726,'source',1792740816191),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',727,'source',1792740816237),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',728,'source',1792740816259),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',729,'source',1792740816312),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','127.0.0.1:32816',730,'source',1792740816324);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('634f542d-ab5c-4287-9a49-2c12101e432b','takeover-experiment',96902,'2026-10-23T07:33:38.232Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:49429|1832644647403844018',1792740818721),('9900cbe5-e4f5-4fe3-b56c-1f581115728d','takeover-experiment',96866,'2026-10-23T07:33:33.815Z','db_drained','c9a65414-4d77-430c-b906-9c75159442f5',1,1,'{\"confirmedAt\":1792740817846,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"c9a65414-4d77-430c-b906-9c75159442f5\",\"owner\":\"9900cbe5-e4f5-4fe3-b56c-1f581115728d\",\"pid\":96866,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:33:33.815Z\"}','pekko://snapshot-takeover@127.0.0.1:49334|3640044535557896547',1792740818085);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('0282c46c-fb65-4628-93e9-934dae55d6f2','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":728,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740816260,22),('104ac3f8-809f-475a-8772-130e4298e90e','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":723,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740816032,17),('10635a3a-3fd0-486a-92d1-756c366cab4b','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":800,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740820620,44),('11132666-dac5-4d3d-9d2c-379dd84b0abb','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'revoking','{\"operation\":\"c9a65414-4d77-430c-b906-9c75159442f5\"}',1792740817824,25),('128fbac6-863c-43f1-807c-c9a9c55379ed','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":798,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820543,42),('28dcf0bf-e847-4cbf-af95-73c99211f3c6','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'db_drained','{\"complete\":true,\"emptyRounds\":2,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,730],\"observedAt\":1792740818055,\"owner\":\"9900cbe5-e4f5-4fe3-b56c-1f581115728d\",\"serverStarted\":1792740369067,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740818085,28),('29a30c92-6fae-4e75-95d5-e200d1dd3a2c','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":813,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740821062,57),('307813c9-4cf1-47ba-99d4-a7086393a7e8','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":803,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820762,47),('3cb69123-d771-4b64-9dca-ff836ca9111d','634f542d-ab5c-4287-9a49-2c12101e432b','table-00','quota_released','{\"disposition\":\"completed\",\"grant\":\"7730dbd6-0c76-4ada-a0f8-1e6166c92b22\"}',1792740821153,60),('40707276-55ad-4d22-86de-4a31a24a8019','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'database_observed','{\"complete\":true,\"emptyRounds\":1,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,730],\"observedAt\":1792740817914,\"owner\":\"9900cbe5-e4f5-4fe3-b56c-1f581115728d\",\"serverStarted\":1792740369919,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740817942,27),('43fb175c-b432-4e09-8648-e56bb013f487','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":716,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740815188,8),('4b0ec992-913c-4fee-b211-7e5d5afefdee','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740818752,32),('562ee3f0-26c9-40ee-b790-2b5496bb4e5e','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":722,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740815951,16),('5b9e1782-f819-4970-904c-0b3fbf2928ac','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":812,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740821044,56),('5d94409e-003b-4f5f-8bd7-092c64758c21','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":792,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740818841,35),('676e2ad9-2ded-4409-b795-d609fee46fd7','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":714,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740814368,6),('6877ffaf-3ff8-4921-ba75-c8b1529132b4','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":809,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820948,53),('698f7568-5f4f-4d91-b2ce-37fca236fe73','9900cbe5-e4f5-4fe3-b56c-1f581115728d','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"7166726d-1a1f-442f-b8d2-d1e7dafbe7a2\",\"permit\":\"203b066f-ad72-48bd-90ed-c1b98d2febb2\"}',1792740815470,9),('6fd0dacf-9b1f-45e4-a181-adc310e4c869','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":725,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740816174,19),('7dc4df56-d753-40f5-8b63-9817e47fc6ef','634f542d-ab5c-4287-9a49-2c12101e432b','table-00','writer_active','{\"grant\":\"7730dbd6-0c76-4ada-a0f8-1e6166c92b22\",\"permit\":\"1254cdf0-f95c-45ed-90b5-ac12d78c0e4a\"}',1792740820504,40),('801a1219-9970-4cc3-8c03-263530efcbb1','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":807,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820905,51),('885088b2-3c12-47d4-a2a0-40db2dff09ce','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":727,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740816237,21),('88c909ac-2141-4609-bee6-25b4d12d70fc','9900cbe5-e4f5-4fe3-b56c-1f581115728d','table-00','writer_active','{\"grant\":\"7166726d-1a1f-442f-b8d2-d1e7dafbe7a2\",\"permit\":\"203b066f-ad72-48bd-90ed-c1b98d2febb2\"}',1792740815759,11),('8c95897a-918a-420f-84d0-87cbacf29c3b','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":794,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740820049,38),('8fcd2881-301d-4ee6-a0e4-590656a37796','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":729,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740816312,23),('900d9320-c6bd-4aff-86a0-f2b9ae3172d4','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":730,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740816325,24),('92b2ce35-e01e-4e21-8809-57f8d5f5cf7e','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740814324,4),('941a5b73-7ed8-47b7-9c59-d197a22f946a','634f542d-ab5c-4287-9a49-2c12101e432b','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":2,\"grant\":\"7730dbd6-0c76-4ada-a0f8-1e6166c92b22\",\"permit\":\"1254cdf0-f95c-45ed-90b5-ac12d78c0e4a\"}',1792740819878,37),('987460d5-da52-4c09-bc35-b2705a113997','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":811,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740821031,55),('9a336cd2-70cb-41c5-90d7-078481c34498','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":810,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820962,54),('9ac1fdf0-2ed4-409d-b03b-16a61437bc74','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'fenced','{\"confirmedAt\":1792740817846,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"c9a65414-4d77-430c-b906-9c75159442f5\",\"owner\":\"9900cbe5-e4f5-4fe3-b56c-1f581115728d\",\"pid\":96866,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:33:33.815Z\"}',1792740817857,26),('9c17a952-b806-4d82-b95f-1f14e482b7aa','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":726,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740816192,20),('a241b996-a6cd-4028-9687-9f3ea337786b','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":721,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740815929,15),('a39f34ec-2377-4cea-b168-f72ead0437ad','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":718,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740815782,12),('b273c56e-8df9-4922-baf2-076bba565892','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":804,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820786,48),('b283a6ba-18d2-4c54-abc5-11ec49a28545','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":724,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740816099,18),('ba9b37fa-b4d6-48eb-9e07-946acdf1ba56','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":790,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740818766,33),('bb1e5a01-0c9e-4dfa-8903-ca86d90479b8','9900cbe5-e4f5-4fe3-b56c-1f581115728d','table-00','old_quota_released','{\"grant\":\"7166726d-1a1f-442f-b8d2-d1e7dafbe7a2\"}',1792740818146,30),('c89cc12e-4fb9-4dd8-805d-32788c174bc9','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":808,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820918,52),('ca1bb8be-5848-444e-b216-6e6d30b0e19c','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":799,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740820603,43),('ca2aee7c-7f1f-4401-b8b9-c1a6a58fdfcb','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":814,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740821078,58),('d06fde55-98f8-4121-a1e3-86f184072a1a','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":720,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740815850,14),('d88f8079-91bb-47ee-b915-e491ef338f87','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":805,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740820873,49),('d9a2b842-e50c-4c70-9dc9-7ddd7b2400d1','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":791,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740818809,34),('daac9ec9-3129-4488-bf10-8bc5740aa2b5','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'owner_registered','{}',1792740818727,31),('dae3f64a-cf5c-477f-bbb8-7d80288364ed','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":719,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740815800,13),('e384e1e2-0d65-4e4a-9ca6-1724a69e48cc','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":802,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820717,46),('e4a207a9-3bd7-441d-a93c-898e16695af3','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":797,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820527,41),('e539fe39-2d3b-411f-9e19-48d264435f40','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":806,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740820887,50),('e6da6a28-99af-488c-af52-84c84824c319','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":717,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740815644,10),('e94a3b55-e504-4217-aa51-31c27440429e','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":801,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740820696,45),('f54c4cdd-aac3-4b12-ab5c-5cb32ef2ce92','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":793,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740819620,36),('f6e8d33f-145a-4b0b-873d-8fe273577471','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":713,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740814335,5),('f7fb427d-f5d3-4db2-90fa-bef12e801263','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'session_registered','{\"connection\":715,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740814398,7),('fe2d6b63-cd90-4448-8aae-76b7a0b85939','9900cbe5-e4f5-4fe3-b56c-1f581115728d',NULL,'owner_registered','{}',1792740814300,3),('ffc5bcac-089d-481d-bb47-3b6b0ec7c103','634f542d-ab5c-4287-9a49-2c12101e432b',NULL,'session_registered','{\"connection\":795,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740820353,39);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','634f542d-ab5c-4287-9a49-2c12101e432b',2,'1254cdf0-f95c-45ed-90b5-ac12d78c0e4a','7730dbd6-0c76-4ada-a0f8-1e6166c92b22','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'b638e5ef63dd56572674b4d38a350ee720371210c2207b01ea8365c7186a3486','parked','9900cbe5-e4f5-4fe3-b56c-1f581115728d');
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
INSERT INTO `pekko_sync_batch_ledger` VALUES ('31488fad31586ac830127ea9de51e8c6ffadab078cd76f38c43eba5328bcbfe8','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:1',1,'mysql.snapshot-split.v1','7','7',2,2,'2026-10-23 07:33:40.966221'),('6d689c0efc8927926cf286e083c5b5059ece01f90e8f141f86abb42d02dfd515','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:0',0,'mysql.snapshot-split.v1','1','3',2,2,'2026-10-23 07:33:40.725279'),('7d58d4d8958d1af12cd6ceb5d0b7d9f400345ded7cd4d765142b39715b0a6552','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:1',0,'mysql.snapshot-split.v1','5','7',2,2,'2026-10-23 07:33:40.923108'),('a1614e8a156ea1536df1c515bb6f50f3804eb6d0ac24bb31d3a981ccb8d90a35','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:0',1,'mysql.snapshot-split.v1','3','3',2,2,'2026-10-23 07:33:40.794959'),('f3a2a930e59d881c885684057ae8c7888d1085889ca8b8030b3756ded0c7a4ce','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','415340ba73797be73f5f1a253a13fe2cdf18884e3fe6812d0bf676bc4a1838dd:2',0,'mysql.snapshot-split.v1','9007199254740993','9007199254740993',2,2,'2026-10-23 07:33:41.083088');
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,60,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_309841ba48a7\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_309841ba48a7\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'completed','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',59,0,NULL,NULL);
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
INSERT INTO `target_audit` VALUES (1,'I',-9,NULL,2,NULL,'负键🙂'),(2,'I',1,NULL,0,NULL,'初始-1'),(3,'I',2,NULL,0,NULL,'初始-2'),(4,'I',3,NULL,0,NULL,'初始-3'),(5,'I',4,NULL,0,NULL,'初始-4'),(6,'I',5,NULL,0,NULL,'初始-5'),(7,'I',6,NULL,0,NULL,'初始-6'),(8,'I',7,NULL,0,NULL,'初始-7'),(9,'I',8,NULL,0,NULL,'初始-8'),(10,'I',9007199254740993,NULL,3,NULL,'大键🙂');
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
INSERT INTO `target_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_522e86b9fb75` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_522e86b9fb75`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'b5575841-32a3-4d5e-96d9-8a5e30030570',1792740804739,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_522e86b9fb75\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_522e86b9fb75\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g�\�~�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'b5575841-32a3-4d5e-96d9-8a5e30030570',1792740804739,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g�\�~�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'b5575841-32a3-4d5e-96d9-8a5e30030570',1792740804739,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$1008aefa-49b0-48fb-898b-10b01b789c3eitimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'b5575841-32a3-4d5e-96d9-8a5e30030570',1792740804972,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952elsourceNodeIdfsourcekfingerprintx@1c04b1cc618c74248d42aaddad3dda4e9581f159007d9096d6ac9d45b3fad6b9eupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g�\�k�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'b5575841-32a3-4d5e-96d9-8a5e30030570',1792740805061,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:0eindex\0elower\�euppera3��itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'b5575841-32a3-4d5e-96d9-8a5e30030570',1792740805131,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:1eindexelowera3euppera7��itimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'b5575841-32a3-4d5e-96d9-8a5e30030570',1792740805191,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g�\�F�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'b5575841-32a3-4d5e-96d9-8a5e30030570',1792740805203,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:0�itimestamp\0\0�g�\�S�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(9,0,'workflow-table-00',9,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740810694,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$57a91a51-6403-4a39-a30b-ee77da8ddf58itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(10,0,'workflow-table-00',10,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740810803,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.RetrySnapshotSplitbidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:0gattempt�itimestamp\0\0�g�\�3�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(11,0,'workflow-table-00',11,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811011,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:0mbatchSequence\0gbatchIdx@dd3a33db4a63f20979f22dbfd2f05f793fd83667d37760e4822ce7f36b5628dcfcursor�dkindwmysql.snapshot-split.v1evaluea1jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(12,0,'workflow-table-00',12,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811072,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:0mbatchSequencegbatchIdx@ba1c4d150b78eb5a77440ac6df87ba5a6f86f05467918b11f8c4ad0fcfcb4568fcursor�dkindwmysql.snapshot-split.v1evaluea3jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�\�@�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(13,0,'workflow-table-00',13,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811082,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:0gattempt�itimestamp\0\0�g�\�J�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(14,0,'workflow-table-00',14,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811092,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:1�itimestamp\0\0�g�\�T�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(15,0,'workflow-table-00',15,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811185,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:1mbatchSequence\0gbatchIdx@5323e3b272503ee04ebf55570094c382bd881aa49f476c3d36b99efe7f65143ffcursor�dkindwmysql.snapshot-split.v1evaluea5jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(16,0,'workflow-table-00',16,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811231,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:1mbatchSequencegbatchIdx@b11b3d3320bf59223e55150f98d423aaee11f996c84922fc420930a9054b51cafcursor�dkindwmysql.snapshot-split.v1evaluea7jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(17,0,'workflow-table-00',17,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811236,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:1gattempt\0�itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(18,0,'workflow-table-00',18,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811241,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:2�itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(19,0,'workflow-table-00',19,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811314,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:2mbatchSequence\0gbatchIdx@253f1a1810377af69981df35bde33a309708851eaad5719b6b0c3fab6b336d6efcursor�dkindwmysql.snapshot-split.v1evaluep9007199254740993jupperBoundp9007199254740993�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�\�2�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(20,0,'workflow-table-00',20,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811319,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:2gattempt\0�itimestamp\0\0�g�\�7�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(21,0,'workflow-table-00',21,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811326,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RetireSnapshotWindow$�itimestamp\0\0�g�\�>�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(22,0,'workflow-table-00',22,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811334,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex>cn.xuyinyin.magic.workflow.snapshot.FinishSnapshotEnumeration$�itimestamp\0\0�g�\�F�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(23,0,'workflow-table-00',23,'ee8a64ff-3b82-4850-ab3d-2a8a7ab5428e',1792740811345,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfresult�fstatusicompletedgsuccess\�gmessagex\'Workflow executed successfully in 598msmrowsProcessed\nphasRowsProcessed\�hdurationVkhasDuration\�knodeResults��fnodeIdfsourcehnodeTypenmysql.snapshotfstatusicompletedgmessage`jhasMessage\�hdurationVkhasDuration\���fnodeIdftargethnodeTypekmysql.writefstatusicompletedgmessage`jhasMessage\�hdurationVkhasDuration\����itimestamp\0\0�g�\�Q�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-522e86b9fb75',90);
            DO RELEASE_LOCK('owner-probe-522e86b9fb75');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'3b5d169e-3a88-480c-bcf3-a3a90d626017','329f100a-f545-4375-8797-e70c97157ab4');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'66453733-360a-4b04-b66a-84bc938013b7','44d6f9a3-cd8c-407f-af98-1c96cb3111b3',1,10),(2,'66453733-360a-4b04-b66a-84bc938013b7','44d6f9a3-cd8c-407f-af98-1c96cb3111b3',1,10),(3,'66453733-360a-4b04-b66a-84bc938013b7','44d6f9a3-cd8c-407f-af98-1c96cb3111b3',1,10),(4,'66453733-360a-4b04-b66a-84bc938013b7','44d6f9a3-cd8c-407f-af98-1c96cb3111b3',1,15),(5,'66453733-360a-4b04-b66a-84bc938013b7','44d6f9a3-cd8c-407f-af98-1c96cb3111b3',1,17),(6,'66453733-360a-4b04-b66a-84bc938013b7','44d6f9a3-cd8c-407f-af98-1c96cb3111b3',1,19),(7,'66453733-360a-4b04-b66a-84bc938013b7','44d6f9a3-cd8c-407f-af98-1c96cb3111b3',1,21),(8,'66453733-360a-4b04-b66a-84bc938013b7','44d6f9a3-cd8c-407f-af98-1c96cb3111b3',1,21),(9,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,37),(10,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,40),(11,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,44),(12,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,46),(13,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,46),(14,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,46),(15,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,50),(16,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,52),(17,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,52),(18,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,52),(19,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,56),(20,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,56),(21,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,56),(22,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,56),(23,'78c929a3-7d9e-4509-a070-795c51609bea','0a2fca94-756a-4950-bda9-20f15d046429',2,56);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('66453733-360a-4b04-b66a-84bc938013b7',1,'329f100a-f545-4375-8797-e70c97157ab4','retired'),('78c929a3-7d9e-4509-a070-795c51609bea',2,'329f100a-f545-4375-8797-e70c97157ab4','launched');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_batch_evidence` VALUES ('253f1a1810377af69981df35bde33a309708851eaad5719b6b0c3fab6b336d6e','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79'),('5323e3b272503ee04ebf55570094c382bd881aa49f476c3d36b99efe7f65143f','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316'),('b11b3d3320bf59223e55150f98d423aaee11f996c84922fc420930a9054b51ca','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c'),('ba1c4d150b78eb5a77440ac6df87ba5a6f86f05467918b11f8c4ad0fcfcb4568','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab'),('dd3a33db4a63f20979f22dbfd2f05f793fd83667d37760e4822ce7f36b5628dc','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62');
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369118,'[\"root\"]',1792740807492,2,1,'{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,604],\"observedAt\":1792740807679,\"owner\":\"66453733-360a-4b04-b66a-84bc938013b7\",\"serverStarted\":1792740369699,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]}'),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369054,'[\"root\"]',NULL,0,0,NULL);
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',588,'control',1792740803166),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',589,'control',1792740803222),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',590,'control',1792740803255),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',591,'control',1792740804201),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',592,'journal',1792740804698),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',593,'target',1792740804860),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',594,'target',1792740804884),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',595,'source',1792740804922),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',596,'source',1792740804944),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',597,'source',1792740805019),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',598,'source',1792740805039),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',599,'source',1792740805096),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',600,'source',1792740805114),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',601,'source',1792740805152),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',602,'source',1792740805170),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',603,'source',1792740805236),('66453733-360a-4b04-b66a-84bc938013b7','127.0.0.1:32816',604,'source',1792740805256),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',664,'control',1792740809085),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',665,'control',1792740809206),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',666,'control',1792740809234),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',667,'control',1792740810089),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',668,'journal',1792740810558),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',669,'target',1792740810759),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',670,'target',1792740810777),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',671,'source',1792740810832),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',672,'source',1792740810849),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',673,'target',1792740810973),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',674,'target',1792740810992),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',675,'target',1792740811034),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',676,'target',1792740811051),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',677,'source',1792740811111),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',678,'source',1792740811129),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',679,'target',1792740811151),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',680,'target',1792740811168),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',681,'target',1792740811201),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',682,'target',1792740811217),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',683,'source',1792740811254),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',684,'source',1792740811266),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',685,'target',1792740811282),('78c929a3-7d9e-4509-a070-795c51609bea','127.0.0.1:32816',686,'target',1792740811297);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('66453733-360a-4b04-b66a-84bc938013b7','takeover-experiment',96390,'2026-10-23T07:33:22.347Z','db_drained','478a38c4-8ad6-4dea-b9b8-385eabd9c1d9',1,1,'{\"confirmedAt\":1792740807360,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"478a38c4-8ad6-4dea-b9b8-385eabd9c1d9\",\"owner\":\"66453733-360a-4b04-b66a-84bc938013b7\",\"pid\":96390,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:33:22.347Z\"}','pekko://snapshot-takeover@127.0.0.1:65516|1332985018306324776',1792740807751),('78c929a3-7d9e-4509-a070-795c51609bea','takeover-experiment',96524,'2026-10-23T07:33:28.228Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:49239|303332687511002693',1792740809044);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('01ac3e1f-0fdb-4e57-b85d-b59b5334a639','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740809074,31),('0358f7d8-404c-43a4-b082-fd4d35f6b151','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":679,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740811151,49),('057f336d-081e-491a-b6f9-e8dd4055847f','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":676,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740811052,46),('05fc09cb-46e0-4209-b274-922248c17a29','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":598,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740805039,17),('06e6f46b-154d-41b8-87f1-eb0ddc813af3','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":665,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740809207,33),('16fa6b3e-fbff-42fa-bb00-956e10d35ddb','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":681,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740811201,51),('21ec2342-cc12-4680-acec-0502aba8690f','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":589,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740803222,6),('2473985d-78a4-4eb0-b0b1-0daf3395579d','78c929a3-7d9e-4509-a070-795c51609bea','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":2,\"grant\":\"57a91a51-6403-4a39-a30b-ee77da8ddf58\",\"permit\":\"0a2fca94-756a-4950-bda9-20f15d046429\"}',1792740810389,36),('25d48174-7ae5-485d-b708-4994752df643','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":674,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740810992,44),('2700640d-6f2d-4a05-a476-35ab03a01edd','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":670,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740810777,40),('277f812b-ea88-4920-8645-ca14bf81fa0b','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":596,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740804945,15),('2a8d3b1d-ea96-47a9-8f9c-e5f15797addd','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":685,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740811283,55),('2f06dc1a-ceed-4836-8838-99c7b0c507af','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":669,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740810759,39),('327bf42a-46c2-4ed4-84e1-4810a9657385','78c929a3-7d9e-4509-a070-795c51609bea','table-00','writer_active','{\"grant\":\"57a91a51-6403-4a39-a30b-ee77da8ddf58\",\"permit\":\"0a2fca94-756a-4950-bda9-20f15d046429\"}',1792740810735,38),('33b70503-1f90-4034-85ef-781f91cb3e77','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":683,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740811254,53),('3423ac43-4b7f-4c3f-9f65-71726b3d897f','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":602,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740805170,21),('362a1cb7-f998-4768-8a3b-d22804cc00f4','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":588,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740803170,5),('3808bf16-77f6-48cd-9496-66a5e286bf67','66453733-360a-4b04-b66a-84bc938013b7','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"1008aefa-49b0-48fb-898b-10b01b789c3e\",\"permit\":\"44d6f9a3-cd8c-407f-af98-1c96cb3111b3\"}',1792740804480,9),('38e0b752-ac90-4ec9-875e-6522731d45fa','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":604,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740805257,23),('3caff96e-7026-47ed-8e88-6d42833deb66','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":597,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740805019,16),('3cd74948-2291-4aab-a0fd-6ad403807b99','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":686,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740811297,56),('45926b20-ea88-4eae-8aed-1b732131e853','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'owner_registered','{}',1792740809050,30),('471ccab0-2336-411a-9596-789a11e4e7d2','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":601,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740805152,20),('49225271-fa10-437c-857b-d469300da836','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":671,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740810832,41),('55d041d0-6eb4-49f8-bdaa-b9a436d5dbb2','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":675,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740811035,45),('593e6a70-b139-415e-8f5e-66bb50feb798','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":590,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740803256,7),('69ee873b-b50f-4a12-ae16-bef5170453ca','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":591,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740804203,8),('6b30dd4b-2ee2-410a-86c5-04f4a25a0a44','66453733-360a-4b04-b66a-84bc938013b7','table-00','writer_active','{\"grant\":\"1008aefa-49b0-48fb-898b-10b01b789c3e\",\"permit\":\"44d6f9a3-cd8c-407f-af98-1c96cb3111b3\"}',1792740804831,11),('71071627-8713-451d-b81e-03a934ce0d45','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":603,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740805237,22),('72a3fc4a-1120-44f0-9e83-d03a7259c4f8','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":595,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740804922,14),('7f66b64e-a8b8-4992-adc4-395c68a54fc4','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":664,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740809087,32),('85467594-d893-4dc8-a863-bac2c517c10f','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":667,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740810090,35),('87956485-a487-468a-844f-cfd72c19c84f','78c929a3-7d9e-4509-a070-795c51609bea','table-00','quota_released','{\"disposition\":\"completed\",\"grant\":\"57a91a51-6403-4a39-a30b-ee77da8ddf58\"}',1792740811366,58),('8a0fb181-daae-4448-88fd-328e949403ef','66453733-360a-4b04-b66a-84bc938013b7',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740803147,4),('8df39863-1605-4f44-9bb9-ced897dfeab3','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":592,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740804699,10),('8eff2520-2dae-4dc9-8057-058db6cd4dd1','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":593,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740804860,12),('920becb8-8959-46b3-8a19-8b63707d72ac','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":672,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740810849,42),('97d54ba8-15ec-46e4-a1b8-563d944398d2','66453733-360a-4b04-b66a-84bc938013b7','table-00','old_quota_released','{\"grant\":\"1008aefa-49b0-48fb-898b-10b01b789c3e\"}',1792740808017,29),('9e905496-521b-4520-a59c-2e6cb1178550','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":684,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740811266,54),('9e9fcfdc-c6ac-48a6-bfda-0d649c6f141e','66453733-360a-4b04-b66a-84bc938013b7',NULL,'database_observed','{\"complete\":true,\"emptyRounds\":1,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,604],\"observedAt\":1792740807492,\"owner\":\"66453733-360a-4b04-b66a-84bc938013b7\",\"serverStarted\":1792740369502,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740807540,26),('a2354754-0c45-4d56-b820-9f87bec3ef4b','66453733-360a-4b04-b66a-84bc938013b7',NULL,'db_drained','{\"complete\":true,\"emptyRounds\":2,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,604],\"observedAt\":1792740807679,\"owner\":\"66453733-360a-4b04-b66a-84bc938013b7\",\"serverStarted\":1792740369699,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740807753,27),('a82d03c2-580b-4fbb-bbb9-9b0ce7ea0710','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":680,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740811168,50),('ab22d448-470b-4f7c-940a-ce947b884acd','66453733-360a-4b04-b66a-84bc938013b7',NULL,'revoking','{\"operation\":\"478a38c4-8ad6-4dea-b9b8-385eabd9c1d9\"}',1792740807318,24),('ad969a4a-82e4-4246-b59b-4f8d595c22e4','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":682,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740811217,52),('b12b6fa8-71d9-4cf6-8129-02b645f30384','66453733-360a-4b04-b66a-84bc938013b7',NULL,'owner_registered','{}',1792740803108,3),('c228ec8f-163e-49e3-900b-7163fe0549c5','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":677,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740811112,47),('c2f0fbc0-92ef-46a3-ad5a-ff40340d2fb9','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":673,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740810973,43),('cc74200e-9f32-423b-8608-532bc4122c33','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":666,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740809235,34),('d5b3bd4b-13af-40e2-85b9-6b37119211e7','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":599,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740805096,18),('d7b12005-10c3-4c74-8430-3eef3f798a6a','66453733-360a-4b04-b66a-84bc938013b7',NULL,'fenced','{\"confirmedAt\":1792740807360,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"478a38c4-8ad6-4dea-b9b8-385eabd9c1d9\",\"owner\":\"66453733-360a-4b04-b66a-84bc938013b7\",\"pid\":96390,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:33:22.347Z\"}',1792740807381,25),('db34bce2-971e-485a-94f4-5a79771bc874','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":668,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740810559,37),('e1c982ec-9588-4eb7-b7b8-af63c884dd4c','78c929a3-7d9e-4509-a070-795c51609bea',NULL,'session_registered','{\"connection\":678,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740811129,48),('e31fdbf1-4722-42e9-afd1-3cd61928c46a','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":594,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740804884,13),('ec65c8d7-4c8d-4cf2-9dc3-6f61db044c53','66453733-360a-4b04-b66a-84bc938013b7',NULL,'session_registered','{\"connection\":600,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740805115,19);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','78c929a3-7d9e-4509-a070-795c51609bea',2,'0a2fca94-756a-4950-bda9-20f15d046429','57a91a51-6403-4a39-a30b-ee77da8ddf58','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'3e43cfb21ac0be27da2c2aff177cf14f3b00d6e76d4e172487a54e4cc665ba1a','parked','66453733-360a-4b04-b66a-84bc938013b7');
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
INSERT INTO `pekko_sync_batch_ledger` VALUES ('253f1a1810377af69981df35bde33a309708851eaad5719b6b0c3fab6b336d6e','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:2',0,'mysql.snapshot-split.v1','9007199254740993','9007199254740993',2,2,'2026-10-23 07:33:31.303183'),('5323e3b272503ee04ebf55570094c382bd881aa49f476c3d36b99efe7f65143f','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:1',0,'mysql.snapshot-split.v1','5','7',2,2,'2026-10-23 07:33:31.174637'),('b11b3d3320bf59223e55150f98d423aaee11f996c84922fc420930a9054b51ca','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:1',1,'mysql.snapshot-split.v1','7','7',2,2,'2026-10-23 07:33:31.222071'),('ba1c4d150b78eb5a77440ac6df87ba5a6f86f05467918b11f8c4ad0fcfcb4568','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:0',1,'mysql.snapshot-split.v1','3','3',2,2,'2026-10-23 07:33:31.061844'),('dd3a33db4a63f20979f22dbfd2f05f793fd83667d37760e4822ce7f36b5628dc','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','4ec768fac46309c686d6148ddfa5e84b3bacbf28add7d6c326b63b7c004c952e:0',0,'mysql.snapshot-split.v1','1','3',2,2,'2026-10-23 07:33:31.000836');
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,58,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_522e86b9fb75\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_522e86b9fb75\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'completed','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',57,0,NULL,NULL);
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
INSERT INTO `target_audit` VALUES (1,'I',-9,NULL,2,NULL,'负键🙂'),(2,'I',1,NULL,0,NULL,'初始-1'),(3,'I',2,NULL,0,NULL,'初始-2'),(4,'I',3,NULL,0,NULL,'初始-3'),(5,'I',4,NULL,0,NULL,'初始-4'),(6,'I',5,NULL,0,NULL,'初始-5'),(7,'I',6,NULL,0,NULL,'初始-6'),(8,'I',7,NULL,0,NULL,'初始-7'),(9,'I',8,NULL,0,NULL,'初始-8'),(10,'I',9007199254740993,NULL,3,NULL,'大键🙂');
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
INSERT INTO `target_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_94c3efa1d150` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_94c3efa1d150`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740796539,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_94c3efa1d150\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_94c3efa1d150\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g��v�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740796539,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g��v�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740796539,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$5cf1b5d7-6dbf-4557-86bb-af4b30778b7eitimestamp\0\0�g��w�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740796731,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@c9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310lsourceNodeIdfsourcekfingerprintx@5bb047d9261d4e66009da51cf98bc62718e89364b7675624e0c871e76c655085eupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g��:�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740796796,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:0eindex\0elower\�euppera3��itimestamp\0\0�g��|�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740796860,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:1eindexelowera3euppera7��itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740796914,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740796922,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:0�itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(9,0,'workflow-table-00',9,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797055,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:0mbatchSequence\0gbatchIdx@86a92bbadd9e6ebe261d593619b24f2869130d234c6be56364b042c271cd7542fcursor�dkindwmysql.snapshot-split.v1evaluea1jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g��~�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(10,0,'workflow-table-00',10,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797106,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:0mbatchSequencegbatchIdx@b51bd0106eeb93fbe192d0b45f09079703e0f5df321e0e63265d87e4ac7c9f90fcursor�dkindwmysql.snapshot-split.v1evaluea3jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(11,0,'workflow-table-00',11,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797114,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:0gattempt\0�itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(12,0,'workflow-table-00',12,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797121,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:1�itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(13,0,'workflow-table-00',13,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797272,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:1mbatchSequence\0gbatchIdx@71ea7b2b7725230b0d6976928e78b0db18aab4751d2b8c0ff2425907a4892745fcursor�dkindwmysql.snapshot-split.v1evaluea5jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g��W�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(14,0,'workflow-table-00',14,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797318,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:1mbatchSequencegbatchIdx@b09a88da600b83ec58f5f68cce52c0a352b1a8dde3a970703628c7e42eb97bcdfcursor�dkindwmysql.snapshot-split.v1evaluea7jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(15,0,'workflow-table-00',15,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797323,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:1gattempt\0�itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(16,0,'workflow-table-00',16,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797327,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:2�itimestamp\0\0�g����',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(17,0,'workflow-table-00',17,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797393,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:2mbatchSequence\0gbatchIdx@07dddd6e94c49e3b043e5734e09a6ff9885051e1e2143104aaaffb59d2a3f1f3fcursor�dkindwmysql.snapshot-split.v1evaluep9007199254740993jupperBoundp9007199254740993�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(18,0,'workflow-table-00',18,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797398,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBc9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:2gattempt\0�itimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(19,0,'workflow-table-00',19,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797402,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RetireSnapshotWindow$�itimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(20,0,'workflow-table-00',20,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797408,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex>cn.xuyinyin.magic.workflow.snapshot.FinishSnapshotEnumeration$�itimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(21,0,'workflow-table-00',21,'78ae2574-766e-4fc3-9855-a999f7c541c8',1792740797419,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfresult�fstatusicompletedgsuccess\�gmessagex\'Workflow executed successfully in 797msmrowsProcessed\nphasRowsProcessed\�hdurationkhasDuration\�knodeResults��fnodeIdfsourcehnodeTypenmysql.snapshotfstatusicompletedgmessage`jhasMessage\�hdurationkhasDuration\���fnodeIdftargethnodeTypekmysql.writefstatusicompletedgmessage`jhasMessage\�hdurationkhasDuration\����itimestamp\0\0�g��\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-94c3efa1d150',90);
            DO RELEASE_LOCK('owner-probe-94c3efa1d150');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'fea12824-9c5b-4d9b-a49f-eb0440e27f49','4e184395-065d-4ddb-833b-07e2cf64cd0e');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,11),(2,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,11),(3,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,11),(4,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,16),(5,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,18),(6,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,20),(7,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,22),(8,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,22),(9,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,26),(10,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,28),(11,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,28),(12,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,28),(13,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,32),(14,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,34),(15,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,34),(16,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,34),(17,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,38),(18,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,38),(19,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,38),(20,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,38),(21,'f3564a35-32a7-4b5b-b5ee-257f6ca72442','8374dfd4-ae0f-4193-bc98-3abf31cbb9b2',1,38);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('770966d4-c680-4db0-97a7-6e88d1cae40e',1,'4e184395-065d-4ddb-833b-07e2cf64cd0e','retired'),('f3564a35-32a7-4b5b-b5ee-257f6ca72442',2,'4e184395-065d-4ddb-833b-07e2cf64cd0e','launched');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_batch_evidence` VALUES ('07dddd6e94c49e3b043e5734e09a6ff9885051e1e2143104aaaffb59d2a3f1f3','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79'),('71ea7b2b7725230b0d6976928e78b0db18aab4751d2b8c0ff2425907a4892745','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316'),('86a92bbadd9e6ebe261d593619b24f2869130d234c6be56364b042c271cd7542','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62'),('b09a88da600b83ec58f5f68cce52c0a352b1a8dde3a970703628c7e42eb97bcd','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c'),('b51bd0106eeb93fbe192d0b45f09079703e0f5df321e0e63265d87e4ac7c9f90','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab');
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369186,'[\"root\"]',NULL,0,0,NULL);
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',531,'control',1792740795218),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',532,'control',1792740795250),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',533,'control',1792740795277),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',534,'control',1792740796049),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',535,'journal',1792740796497),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',536,'target',1792740796635),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',537,'target',1792740796653),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',538,'source',1792740796693),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',539,'source',1792740796710),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',540,'source',1792740796762),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',541,'source',1792740796778),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',542,'source',1792740796819),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',543,'source',1792740796843),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',544,'source',1792740796877),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',545,'source',1792740796895),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',546,'source',1792740796944),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',547,'source',1792740796955),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',548,'target',1792740797021),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',549,'target',1792740797037),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',550,'target',1792740797075),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',551,'target',1792740797089),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',552,'source',1792740797138),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',553,'source',1792740797217),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',554,'target',1792740797237),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',555,'target',1792740797252),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',556,'target',1792740797286),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',557,'target',1792740797301),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',558,'source',1792740797342),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',559,'source',1792740797354),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',560,'target',1792740797368),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','127.0.0.1:32816',561,'target',1792740797379);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('770966d4-c680-4db0-97a7-6e88d1cae40e','takeover-experiment',95847,'2026-10-23T07:33:13.059Z','startup_failed','0e0dfdd1-f768-4231-851e-cec59c2fa42b',0,0,'{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137}',NULL,1792740794648),('f3564a35-32a7-4b5b-b5ee-257f6ca72442','takeover-experiment',95850,'2026-10-23T07:33:14.692Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:65409|1356542687575356443',1792740795173);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('1165c817-2429-4281-8b3a-76e5743089bc','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740795209,5),('1909df38-2190-4a0b-813f-35cc06cc27dd','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":553,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740797217,30),('1eb301da-2458-4765-955d-de6dadb81dea','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":537,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740796653,14),('2954437c-0d5e-415c-863f-df2e9eb421d6','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":549,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797037,26),('2e019be2-278e-49bf-a798-6471af3cde31','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":539,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796710,16),('312abb5d-7307-45be-80c3-ebd4cb4cda5e','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":552,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740797138,29),('37308574-6843-4ee6-a873-fe96b60635ba','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":542,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796819,19),('3aa394a0-ce95-4eb7-9521-8d5c5c076901','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":544,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796878,21),('3eb62b08-bb10-48a9-8e4e-40800e50481d','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":532,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740795251,7),('421ce679-9685-403a-b9be-edcc844c45b7','f3564a35-32a7-4b5b-b5ee-257f6ca72442','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"5cf1b5d7-6dbf-4557-86bb-af4b30778b7e\",\"permit\":\"8374dfd4-ae0f-4193-bc98-3abf31cbb9b2\"}',1792740796329,10),('46009453-88f7-4e99-bf45-8f1edf6a6bdf','770966d4-c680-4db0-97a7-6e88d1cae40e',NULL,'startup_failed','{\"pid\":95847,\"proof\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"startIdentity\":\"2026-10-23T07:33:13.059Z\"}',1792740794652,3),('521bd294-50da-4a25-ac58-6924c5c5d48c','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":546,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796944,23),('5ab7f23a-d33a-4e30-b595-f0fd50b2567e','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":557,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797301,34),('6ebedf09-68de-4d71-a858-f863c1cce098','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":536,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740796635,13),('6ee75ee0-e82e-4801-aa87-0b7d14cd86d9','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":545,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796896,22),('72843a2e-c044-4005-ac8b-c7de299f4c36','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":551,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797089,28),('821e5f0c-7830-41e1-b12a-63e1477101b7','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":538,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796693,15),('8a24d1b6-5d24-4932-9a4c-f4b1a2075417','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":559,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740797355,36),('8ae93b50-6fd2-4c70-9395-3350499c5540','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":555,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797253,32),('8bcd98f8-98c7-4d52-ae87-e448cbb43751','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":533,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740795278,8),('927667bf-7a59-4e99-bf24-8be387541385','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":540,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796763,17),('9a977c9d-b713-4fc0-a0ff-0cc242af360d','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":531,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740795219,6),('9dfefa3b-8b7f-4d86-b9b2-cbe9dc423d78','f3564a35-32a7-4b5b-b5ee-257f6ca72442','table-00','writer_active','{\"grant\":\"5cf1b5d7-6dbf-4557-86bb-af4b30778b7e\",\"permit\":\"8374dfd4-ae0f-4193-bc98-3abf31cbb9b2\"}',1792740796610,12),('a11e564c-1036-4eb1-8687-3c881d4f6f57','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'owner_registered','{}',1792740795179,4),('a317f8ef-d0d2-4448-ac9a-829305de1e65','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":543,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796843,20),('ab5b975c-a58e-41b6-9897-e20619df19f9','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":561,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797380,38),('b39b9abc-f84b-4869-9ad2-c5a54d5dee0f','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":535,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740796498,11),('b7a030e2-f800-4653-bc5a-c6634b3618c5','f3564a35-32a7-4b5b-b5ee-257f6ca72442','table-00','quota_released','{\"disposition\":\"completed\",\"grant\":\"5cf1b5d7-6dbf-4557-86bb-af4b30778b7e\"}',1792740797442,40),('b99a2ff8-d280-4997-9009-cee7dd5e8ad7','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":558,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740797343,35),('bd5866d5-ab78-4619-9c6c-483c7d3f7fe6','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":547,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796956,24),('d3c34ba2-2d61-46ec-874f-3fd156ecfa3e','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":560,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797368,37),('d7d8d004-47c2-412e-bc1c-a7d5c9a0872b','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":554,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797238,31),('e11735e8-29e7-4f1e-872c-21f7fff143e4','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":550,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797076,27),('e256ae1d-ab13-4dab-a203-769507b48fee','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":534,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740796050,9),('eae62be8-2956-4b2c-a151-2e21f8653d58','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":556,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797286,33),('ece6a0ae-00c9-4c17-8a9c-14a9ceef601f','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":548,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740797021,25),('ef825a8f-873d-4cad-904d-0e8f7c80ce56','f3564a35-32a7-4b5b-b5ee-257f6ca72442',NULL,'session_registered','{\"connection\":541,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740796778,18);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','f3564a35-32a7-4b5b-b5ee-257f6ca72442',1,'8374dfd4-ae0f-4193-bc98-3abf31cbb9b2','5cf1b5d7-6dbf-4557-86bb-af4b30778b7e','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'38fd33edd591b688925ed950cd74f890368cb1592c60a2891cb536dbb78e9d6b','parked',NULL);
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
INSERT INTO `pekko_sync_batch_ledger` VALUES ('07dddd6e94c49e3b043e5734e09a6ff9885051e1e2143104aaaffb59d2a3f1f3','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:2',0,'mysql.snapshot-split.v1','9007199254740993','9007199254740993',2,2,'2026-10-23 07:33:17.384677'),('71ea7b2b7725230b0d6976928e78b0db18aab4751d2b8c0ff2425907a4892745','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:1',0,'mysql.snapshot-split.v1','5','7',2,2,'2026-10-23 07:33:17.260979'),('86a92bbadd9e6ebe261d593619b24f2869130d234c6be56364b042c271cd7542','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:0',0,'mysql.snapshot-split.v1','1','3',2,2,'2026-10-23 07:33:17.045546'),('b09a88da600b83ec58f5f68cce52c0a352b1a8dde3a970703628c7e42eb97bcd','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:1',1,'mysql.snapshot-split.v1','7','7',2,2,'2026-10-23 07:33:17.308135'),('b51bd0106eeb93fbe192d0b45f09079703e0f5df321e0e63265d87e4ac7c9f90','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c9e0697870c191a1a165144257158aeb7cad7ff2e80524be07863b1c331df310:0',1,'mysql.snapshot-split.v1','3','3',2,2,'2026-10-23 07:33:17.096866');
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,40,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_94c3efa1d150\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_94c3efa1d150\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'completed','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',39,0,NULL,NULL);
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
INSERT INTO `target_audit` VALUES (1,'I',-9,NULL,2,NULL,'负键🙂'),(2,'I',1,NULL,0,NULL,'初始-1'),(3,'I',2,NULL,0,NULL,'初始-2'),(4,'I',3,NULL,0,NULL,'初始-3'),(5,'I',4,NULL,0,NULL,'初始-4'),(6,'I',5,NULL,0,NULL,'初始-5'),(7,'I',6,NULL,0,NULL,'初始-6'),(8,'I',7,NULL,0,NULL,'初始-7'),(9,'I',8,NULL,0,NULL,'初始-8'),(10,'I',9007199254740993,NULL,3,NULL,'大键🙂');
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
INSERT INTO `target_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_a9a5c11bb16f` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_a9a5c11bb16f`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'eb812869-227a-4e98-8bab-867d3534b164',1792740772485,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_a9a5c11bb16f\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_a9a5c11bb16f\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g�J�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'eb812869-227a-4e98-8bab-867d3534b164',1792740772485,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g�J�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'eb812869-227a-4e98-8bab-867d3534b164',1792740772485,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$c89d67ae-eb42-49dc-be9d-f995f1119e10itimestamp\0\0�g�J��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'eb812869-227a-4e98-8bab-867d3534b164',1792740772668,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@b9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3lsourceNodeIdfsourcekfingerprintx@ea5430e18754c7998af8a9a7fcee7405766c9844ef147eeec3c9b203d77fc978eupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g�K<�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'eb812869-227a-4e98-8bab-867d3534b164',1792740772742,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:0eindex\0elower\�euppera3��itimestamp\0\0�g�K��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'eb812869-227a-4e98-8bab-867d3534b164',1792740772792,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:1eindexelowera3euppera7��itimestamp\0\0�g�K��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'eb812869-227a-4e98-8bab-867d3534b164',1792740772843,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g�K\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'eb812869-227a-4e98-8bab-867d3534b164',1792740772853,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:0�itimestamp\0\0�g�K\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(9,0,'workflow-table-00',9,'eb812869-227a-4e98-8bab-867d3534b164',1792740773051,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:0mbatchSequence\0gbatchIdx@74709b5610089d66b331edfc1698d319987853a2587da6a6238f87e0ca3bbf37fcursor�dkindwmysql.snapshot-split.v1evaluea1jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�L��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(10,0,'workflow-table-00',10,'eb812869-227a-4e98-8bab-867d3534b164',1792740773110,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:0mbatchSequencegbatchIdx@cc8829acf48d12a5a744712c05f2dc722e02538ef7d6c545bcf3e801f9cc8b86fcursor�dkindwmysql.snapshot-split.v1evaluea3jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�L\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(11,0,'workflow-table-00',11,'eb812869-227a-4e98-8bab-867d3534b164',1792740773121,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:0gattempt\0�itimestamp\0\0�g�M�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(12,0,'workflow-table-00',12,'eb812869-227a-4e98-8bab-867d3534b164',1792740773131,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:1�itimestamp\0\0�g�M�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(13,0,'workflow-table-00',13,'eb812869-227a-4e98-8bab-867d3534b164',1792740773206,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:1mbatchSequence\0gbatchIdx@f6a732edefb5203342e876c382a36c701e2b923384b96c2cbd979c5cdbc5d8ecfcursor�dkindwmysql.snapshot-split.v1evaluea5jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�MU�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(14,0,'workflow-table-00',14,'eb812869-227a-4e98-8bab-867d3534b164',1792740773248,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:1mbatchSequencegbatchIdx@b0fd811364666758418e86508d4ecf5c0c2a63d973b6157b69861a9a2e0bc787fcursor�dkindwmysql.snapshot-split.v1evaluea7jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�M��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(15,0,'workflow-table-00',15,'eb812869-227a-4e98-8bab-867d3534b164',1792740773253,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:1gattempt\0�itimestamp\0\0�g�M��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(16,0,'workflow-table-00',16,'eb812869-227a-4e98-8bab-867d3534b164',1792740773257,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:2�itimestamp\0\0�g�M��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(17,0,'workflow-table-00',17,'eb812869-227a-4e98-8bab-867d3534b164',1792740773324,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:2mbatchSequence\0gbatchIdx@32a5ae3728cdd831c37e2ce2ce6b34cdcf2e7652097565d1af3ecef90c4b4c1dfcursor�dkindwmysql.snapshot-split.v1evaluep9007199254740993jupperBoundp9007199254740993�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�M\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(18,0,'workflow-table-00',18,'eb812869-227a-4e98-8bab-867d3534b164',1792740773330,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBb9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:2gattempt\0�itimestamp\0\0�g�M\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(19,0,'workflow-table-00',19,'eb812869-227a-4e98-8bab-867d3534b164',1792740773335,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RetireSnapshotWindow$�itimestamp\0\0�g�M\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(20,0,'workflow-table-00',20,'eb812869-227a-4e98-8bab-867d3534b164',1792740773344,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex>cn.xuyinyin.magic.workflow.snapshot.FinishSnapshotEnumeration$�itimestamp\0\0�g�M\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(21,0,'workflow-table-00',21,'eb812869-227a-4e98-8bab-867d3534b164',1792740773355,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfresult�fstatusicompletedgsuccess\�gmessagex\'Workflow executed successfully in 788msmrowsProcessed\nphasRowsProcessed\�hdurationkhasDuration\�knodeResults��fnodeIdfsourcehnodeTypenmysql.snapshotfstatusicompletedgmessage`jhasMessage\�hdurationkhasDuration\���fnodeIdftargethnodeTypekmysql.writefstatusicompletedgmessage`jhasMessage\�hdurationkhasDuration\����itimestamp\0\0�g�M\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-a9a5c11bb16f',90);
            DO RELEASE_LOCK('owner-probe-a9a5c11bb16f');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'2d49ed90-f35c-419a-b714-8e1e0eac7697','91c40cbd-d332-455a-b95c-a73e799f7e87');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,10),(2,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,10),(3,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,10),(4,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,15),(5,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,17),(6,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,19),(7,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,21),(8,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,21),(9,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,25),(10,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,27),(11,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,27),(12,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,27),(13,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,31),(14,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,33),(15,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,33),(16,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,33),(17,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,37),(18,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,37),(19,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,37),(20,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,37),(21,'06407b9a-8dfd-431a-b064-b058d78efaed','a2594b10-2341-4e78-9226-334d1fddfadb',1,37);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('06407b9a-8dfd-431a-b064-b058d78efaed',2,'91c40cbd-d332-455a-b95c-a73e799f7e87','launched'),('2a4649c3-fea3-4ff5-8392-5455bb25579b',1,'91c40cbd-d332-455a-b95c-a73e799f7e87','retired');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_batch_evidence` VALUES ('32a5ae3728cdd831c37e2ce2ce6b34cdcf2e7652097565d1af3ecef90c4b4c1d','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79'),('74709b5610089d66b331edfc1698d319987853a2587da6a6238f87e0ca3bbf37','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62'),('b0fd811364666758418e86508d4ecf5c0c2a63d973b6157b69861a9a2e0bc787','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c'),('cc8829acf48d12a5a744712c05f2dc722e02538ef7d6c545bcf3e801f9cc8b86','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab'),('f6a732edefb5203342e876c382a36c701e2b923384b96c2cbd979c5cdbc5d8ec','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316');
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369140,'[\"root\"]',NULL,0,0,NULL);
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',239,'control',1792740771164),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',240,'control',1792740771190),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',241,'control',1792740771216),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',242,'control',1792740771939),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',243,'journal',1792740772443),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',244,'target',1792740772579),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',245,'target',1792740772597),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',246,'source',1792740772633),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',247,'source',1792740772648),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',248,'source',1792740772707),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',249,'source',1792740772724),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',250,'source',1792740772760),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',251,'source',1792740772776),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',252,'source',1792740772811),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',253,'source',1792740772827),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',254,'source',1792740772882),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',255,'source',1792740772897),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',256,'target',1792740773017),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',257,'target',1792740773033),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',258,'target',1792740773074),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',259,'target',1792740773091),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',260,'source',1792740773145),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',261,'source',1792740773159),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',262,'target',1792740773175),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',263,'target',1792740773188),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',264,'target',1792740773217),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',265,'target',1792740773233),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',266,'source',1792740773269),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',267,'source',1792740773285),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',268,'target',1792740773298),('06407b9a-8dfd-431a-b064-b058d78efaed','127.0.0.1:32816',269,'target',1792740773308);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('06407b9a-8dfd-431a-b064-b058d78efaed','takeover-experiment',95714,'2026-10-23T07:32:50.696Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:64990|-8790970722452934963',1792740771131);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('12cb8e27-3ef3-4906-8b45-75113ce69df7','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":239,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740771165,5),('17c6d0e4-02ae-46fa-b877-3ab512a8eb05','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":255,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772897,23),('1adf1852-1ec9-4792-81f9-f073421829b2','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":267,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740773285,35),('3e2dc5b0-8f57-40ec-a2b9-fdaed47e6719','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":251,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772776,19),('427d75a4-3f2d-45e5-9d56-737aae088c9d','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":268,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773298,36),('43abf92a-db43-4fd5-9a65-cede165eab41','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":248,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772707,16),('4bec41cd-dcc4-466e-a245-505defda7e31','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":242,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740771939,8),('575b0308-1cb5-42c9-bd2c-a40e286ecde0','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":246,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772633,14),('595b007b-0bfe-41d7-aa27-b32ca2c73b51','06407b9a-8dfd-431a-b064-b058d78efaed','table-00','writer_active','{\"grant\":\"c89d67ae-eb42-49dc-be9d-f995f1119e10\",\"permit\":\"a2594b10-2341-4e78-9226-334d1fddfadb\"}',1792740772556,11),('685e8bcd-6fad-4402-99a7-49797281db58','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":252,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772811,20),('6af66430-6641-48b1-b4cb-94c1cd58a72d','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":247,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772648,15),('7033d72c-fc16-4000-a738-0737ba5b16ec','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":241,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740771216,7),('70f9ad81-0c0d-48bd-8998-320f99e1680f','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":250,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772760,18),('747e6021-a97e-469a-8ff5-197afec77fd3','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":253,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772827,21),('779510ce-1984-4cc8-b355-53135b83a34c','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":245,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740772597,13),('7c31e0b5-c490-4376-82ee-9c19ebff0bfc','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":260,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740773146,28),('81008354-b896-499b-b05e-26d3191f0399','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":265,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773233,33),('816ef586-041e-4bf2-af3a-dd9dca95696b','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":259,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773091,27),('96064f48-16b2-4861-a1c0-8456bd206a28','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":261,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740773159,29),('b0f56715-1f6d-44d6-87ce-d6189ba7da3a','06407b9a-8dfd-431a-b064-b058d78efaed','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"c89d67ae-eb42-49dc-be9d-f995f1119e10\",\"permit\":\"a2594b10-2341-4e78-9226-334d1fddfadb\"}',1792740772214,9),('b18e0612-2e45-4e1a-a9ef-16d8f7658e57','06407b9a-8dfd-431a-b064-b058d78efaed','table-00','quota_released','{\"disposition\":\"completed\",\"grant\":\"c89d67ae-eb42-49dc-be9d-f995f1119e10\"}',1792740773374,39),('b29387b5-8857-407e-a49b-543ab2e90c31','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":257,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773034,25),('bd4b2f0d-fe47-4372-9bb0-f4db0e17c2cb','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":244,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740772580,12),('c3a6b59a-3676-4c30-a6a0-6c49a7fc3365','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":262,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773175,30),('c599d87f-26ea-4155-88b0-4eff2d445692','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":263,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773189,31),('d4b665d8-a9ec-4ee5-aa1b-5d404ffe53b7','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":266,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740773270,34),('d57fd849-8d90-48ec-b88f-85c36e2b92e6','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":258,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773074,26),('d6dd9d62-3c6e-45fe-a38d-c01bae0fa66c','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":243,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740772443,10),('d88846a1-d82b-41c4-a789-81ca57c5985e','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":240,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740771191,6),('def7ed00-e64c-48e9-9c44-3acbb0a5ca7f','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":249,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772724,17),('e04462bd-7ad0-4d2f-827b-3894e4293416','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740771156,4),('e43561f1-3dda-4031-9b1a-179f23e4feaf','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":256,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773017,24),('edaa8e9f-2f44-4048-8410-1bfe4aaa8d3c','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'owner_registered','{}',1792740771135,3),('f0d08fe1-90b5-4150-8c47-584865b208dc','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":269,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773308,37),('f10898a3-6e74-44db-aae8-35d8083c8c4c','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":254,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740772882,22),('fadd7e91-cd17-45ff-b4b2-fbe871aed887','06407b9a-8dfd-431a-b064-b058d78efaed',NULL,'session_registered','{\"connection\":264,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740773217,32);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','06407b9a-8dfd-431a-b064-b058d78efaed',1,'a2594b10-2341-4e78-9226-334d1fddfadb','c89d67ae-eb42-49dc-be9d-f995f1119e10','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'903cfc93eee116029cadd00260119c552eb21c4a9be0d0f737394ff24e8953fe','parked',NULL);
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
INSERT INTO `pekko_sync_batch_ledger` VALUES ('32a5ae3728cdd831c37e2ce2ce6b34cdcf2e7652097565d1af3ecef90c4b4c1d','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','b9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:2',0,'mysql.snapshot-split.v1','9007199254740993','9007199254740993',2,2,'2026-10-23 07:32:53.313541'),('74709b5610089d66b331edfc1698d319987853a2587da6a6238f87e0ca3bbf37','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','b9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:0',0,'mysql.snapshot-split.v1','1','3',2,2,'2026-10-23 07:32:53.041319'),('b0fd811364666758418e86508d4ecf5c0c2a63d973b6157b69861a9a2e0bc787','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','b9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:1',1,'mysql.snapshot-split.v1','7','7',2,2,'2026-10-23 07:32:53.238566'),('cc8829acf48d12a5a744712c05f2dc722e02538ef7d6c545bcf3e801f9cc8b86','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','b9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:0',1,'mysql.snapshot-split.v1','3','3',2,2,'2026-10-23 07:32:53.101755'),('f6a732edefb5203342e876c382a36c701e2b923384b96c2cbd979c5cdbc5d8ec','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','b9c4f0539c7d681c6f0e41582c6425054645aba6dc1e573124e2f48483e31de3:1',0,'mysql.snapshot-split.v1','5','7',2,2,'2026-10-23 07:32:53.194985');
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,39,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_a9a5c11bb16f\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_a9a5c11bb16f\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'completed','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',38,0,NULL,NULL);
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
INSERT INTO `target_audit` VALUES (1,'I',-9,NULL,2,NULL,'负键🙂'),(2,'I',1,NULL,0,NULL,'初始-1'),(3,'I',2,NULL,0,NULL,'初始-2'),(4,'I',3,NULL,0,NULL,'初始-3'),(5,'I',4,NULL,0,NULL,'初始-4'),(6,'I',5,NULL,0,NULL,'初始-5'),(7,'I',6,NULL,0,NULL,'初始-6'),(8,'I',7,NULL,0,NULL,'初始-7'),(9,'I',8,NULL,0,NULL,'初始-8'),(10,'I',9007199254740993,NULL,3,NULL,'大键🙂');
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
INSERT INTO `target_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_bc6616cfd4dd` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_bc6616cfd4dd`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'6fd2e136-da64-448d-a0a2-3f976389d57b',1792740835915,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_bc6616cfd4dd\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_bc6616cfd4dd\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g�B;�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'6fd2e136-da64-448d-a0a2-3f976389d57b',1792740835915,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g�B=�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'6fd2e136-da64-448d-a0a2-3f976389d57b',1792740835915,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$54a44d16-fac3-41d6-9ae2-ad384632c873itimestamp\0\0�g�B>�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'6fd2e136-da64-448d-a0a2-3f976389d57b',1792740836245,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@5b0b1211c7e7daf6039eb906cca0e31d6ea704371842842febc97b4b8a30cbc4lsourceNodeIdfsourcekfingerprintx@540383d1c79fa941fd256bcedfd5edace6d338ca70fff52cadc6cb5c00868de6eupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g�C��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'6fd2e136-da64-448d-a0a2-3f976389d57b',1792740836345,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB5b0b1211c7e7daf6039eb906cca0e31d6ea704371842842febc97b4b8a30cbc4:0eindex\0elower\�euppera3��itimestamp\0\0�g�C��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'6fd2e136-da64-448d-a0a2-3f976389d57b',1792740836417,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB5b0b1211c7e7daf6039eb906cca0e31d6ea704371842842febc97b4b8a30cbc4:1eindexelowera3euppera7��itimestamp\0\0�g�DA�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'6fd2e136-da64-448d-a0a2-3f976389d57b',1792740836470,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB5b0b1211c7e7daf6039eb906cca0e31d6ea704371842842febc97b4b8a30cbc4:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g�Du�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'6fd2e136-da64-448d-a0a2-3f976389d57b',1792740836480,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB5b0b1211c7e7daf6039eb906cca0e31d6ea704371842842febc97b4b8a30cbc4:0�itimestamp\0\0�g�D��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-bc6616cfd4dd',90);
            DO RELEASE_LOCK('owner-probe-bc6616cfd4dd');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'a1cd6402-719f-44e3-8ca8-49f976954374','2047da61-6575-4af3-b822-a1499bb79756');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'6360b032-9c04-41d4-a6bf-309b1b1cf68a','54dfceff-1a60-42a5-9ba0-69abe7764948',1,10),(2,'6360b032-9c04-41d4-a6bf-309b1b1cf68a','54dfceff-1a60-42a5-9ba0-69abe7764948',1,10),(3,'6360b032-9c04-41d4-a6bf-309b1b1cf68a','54dfceff-1a60-42a5-9ba0-69abe7764948',1,10),(4,'6360b032-9c04-41d4-a6bf-309b1b1cf68a','54dfceff-1a60-42a5-9ba0-69abe7764948',1,15),(5,'6360b032-9c04-41d4-a6bf-309b1b1cf68a','54dfceff-1a60-42a5-9ba0-69abe7764948',1,17),(6,'6360b032-9c04-41d4-a6bf-309b1b1cf68a','54dfceff-1a60-42a5-9ba0-69abe7764948',1,19),(7,'6360b032-9c04-41d4-a6bf-309b1b1cf68a','54dfceff-1a60-42a5-9ba0-69abe7764948',1,21),(8,'6360b032-9c04-41d4-a6bf-309b1b1cf68a','54dfceff-1a60-42a5-9ba0-69abe7764948',1,21);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('6360b032-9c04-41d4-a6bf-309b1b1cf68a',1,'2047da61-6575-4af3-b822-a1499bb79756','launched');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369114,'[\"root\"]',NULL,0,0,NULL);
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',966,'control',1792740834152),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',967,'control',1792740834195),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',968,'control',1792740834221),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',969,'control',1792740835311),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',970,'journal',1792740835827),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',971,'target',1792740836062),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',972,'target',1792740836087),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',973,'source',1792740836176),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',974,'source',1792740836201),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',975,'source',1792740836297),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',976,'source',1792740836315),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',977,'source',1792740836367),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',978,'source',1792740836399),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',979,'source',1792740836435),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',980,'source',1792740836451),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',981,'source',1792740836505),('6360b032-9c04-41d4-a6bf-309b1b1cf68a','127.0.0.1:32816',982,'source',1792740836520);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('6360b032-9c04-41d4-a6bf-309b1b1cf68a','takeover-experiment',97014,'2026-10-23T07:33:53.479Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:49718|-9071762209842684156',1792740834099);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('001748ff-c4c8-481a-b61d-41303094f1aa','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":970,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740835828,10),('0a206e2b-01eb-4038-86bf-d38eb217ab3f','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":982,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836520,23),('1ff4085d-53a8-476e-9da1-2f1cf9f7d1cc','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":981,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836506,22),('3a824766-1671-433d-85e2-de637ba46897','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":976,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836315,17),('46045bd7-1674-4c4f-9398-13ea4fba2274','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":974,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836201,15),('4880bf99-15af-4e4e-91c4-49a90229e6f4','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":977,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836368,18),('528c9d6b-1ca0-4c96-9d00-4be6cb523b9c','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":979,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836435,20),('6982f0d6-eab0-48a0-835f-a89345eb8ce6','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":966,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740834154,5),('6be1999e-c553-4a70-827c-925b85f9fa77','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'owner_registered','{}',1792740834106,3),('7566c211-2668-4998-a964-129d47d05c00','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":968,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740834222,7),('78f641b0-66c4-4e96-bebb-f543ea8f86a7','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":973,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836177,14),('9b3629a2-8f3a-41e2-82d7-c7a74d1976ed','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":969,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740835311,8),('a91a55f9-8920-490e-ac09-9e438a31b764','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":972,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740836087,13),('b5691c8f-4fb5-420c-b409-b6efbbe2fb38','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":980,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836451,21),('bbdd07fb-8234-4471-a80c-4407832c5362','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":975,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836297,16),('cac739f9-ac70-4f20-91a0-a86c9f847c97','6360b032-9c04-41d4-a6bf-309b1b1cf68a','table-00','writer_active','{\"grant\":\"54a44d16-fac3-41d6-9ae2-ad384632c873\",\"permit\":\"54dfceff-1a60-42a5-9ba0-69abe7764948\"}',1792740836030,11),('cf58ec71-88e9-4f53-8adb-ffebe0a237df','6360b032-9c04-41d4-a6bf-309b1b1cf68a','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"54a44d16-fac3-41d6-9ae2-ad384632c873\",\"permit\":\"54dfceff-1a60-42a5-9ba0-69abe7764948\"}',1792740835580,9),('d18bc3e7-04fc-40b0-9855-b61f8863a51a','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":971,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740836062,12),('ede8afcf-6cfe-4999-a65c-b33b76a20279','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740834140,4),('f015ecd1-757b-478f-86eb-ae1751f536be','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":967,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740834196,6),('f83bf17d-ec60-46f1-842a-55e7ee845c80','6360b032-9c04-41d4-a6bf-309b1b1cf68a',NULL,'session_registered','{\"connection\":978,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740836399,19);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','6360b032-9c04-41d4-a6bf-309b1b1cf68a',1,'54dfceff-1a60-42a5-9ba0-69abe7764948','54a44d16-fac3-41d6-9ae2-ad384632c873','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'9a224c5d556d4d4f9db1fa7e2931d81d9b23257a785cbb1d8497dbc87bdf3b0b','active',NULL);
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,23,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_bc6616cfd4dd\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_bc6616cfd4dd\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'running','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',2,0,'54a44d16-fac3-41d6-9ae2-ad384632c873','6360b032-9c04-41d4-a6bf-309b1b1cf68a');
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_c7cc721098a7` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_c7cc721098a7`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'0d57c19c-704a-4b76-a9ec-452c9636f900',1792740841957,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_c7cc721098a7\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_c7cc721098a7\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g�Y\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'0d57c19c-704a-4b76-a9ec-452c9636f900',1792740841957,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g�Y\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'0d57c19c-704a-4b76-a9ec-452c9636f900',1792740841957,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$2f214c41-d030-44ce-9647-7972bde5d0daitimestamp\0\0�g�Y\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'0d57c19c-704a-4b76-a9ec-452c9636f900',1792740842139,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@41c0beb06938c1b2784352cb55e8520863b2a0d3b0f67c7f0d4bfde6dacad6a4lsourceNodeIdfsourcekfingerprintx@df7dd4ccc97e0d1a8afa672f4f3dc794dd30a4e886ce8b9340b497cb477277c1eupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g�Z��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'0d57c19c-704a-4b76-a9ec-452c9636f900',1792740842215,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB41c0beb06938c1b2784352cb55e8520863b2a0d3b0f67c7f0d4bfde6dacad6a4:0eindex\0elower\�euppera3��itimestamp\0\0�g�Z\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'0d57c19c-704a-4b76-a9ec-452c9636f900',1792740842271,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB41c0beb06938c1b2784352cb55e8520863b2a0d3b0f67c7f0d4bfde6dacad6a4:1eindexelowera3euppera7��itimestamp\0\0�g�[�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'0d57c19c-704a-4b76-a9ec-452c9636f900',1792740842322,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB41c0beb06938c1b2784352cb55e8520863b2a0d3b0f67c7f0d4bfde6dacad6a4:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g�[R�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'0d57c19c-704a-4b76-a9ec-452c9636f900',1792740842333,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB41c0beb06938c1b2784352cb55e8520863b2a0d3b0f67c7f0d4bfde6dacad6a4:0�itimestamp\0\0�g�[]�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-c7cc721098a7',90);
            DO RELEASE_LOCK('owner-probe-c7cc721098a7');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'fb0131a3-1d00-42f1-ab04-911548be0955','446bb74e-820a-4a72-8bcc-4da7a9fb956a');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'060dfe59-6c11-4442-88b6-83194b5ff650','a7d02272-8943-477b-b6f3-f2b34725a624',1,10),(2,'060dfe59-6c11-4442-88b6-83194b5ff650','a7d02272-8943-477b-b6f3-f2b34725a624',1,10),(3,'060dfe59-6c11-4442-88b6-83194b5ff650','a7d02272-8943-477b-b6f3-f2b34725a624',1,10),(4,'060dfe59-6c11-4442-88b6-83194b5ff650','a7d02272-8943-477b-b6f3-f2b34725a624',1,15),(5,'060dfe59-6c11-4442-88b6-83194b5ff650','a7d02272-8943-477b-b6f3-f2b34725a624',1,17),(6,'060dfe59-6c11-4442-88b6-83194b5ff650','a7d02272-8943-477b-b6f3-f2b34725a624',1,19),(7,'060dfe59-6c11-4442-88b6-83194b5ff650','a7d02272-8943-477b-b6f3-f2b34725a624',1,21),(8,'060dfe59-6c11-4442-88b6-83194b5ff650','a7d02272-8943-477b-b6f3-f2b34725a624',1,21);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('060dfe59-6c11-4442-88b6-83194b5ff650',1,'446bb74e-820a-4a72-8bcc-4da7a9fb956a','launched');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369193,'[\"root\"]',NULL,0,0,NULL);
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1028,'control',1792740840226),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1029,'control',1792740840290),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1030,'control',1792740840352),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1031,'control',1792740841448),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1032,'journal',1792740841912),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1033,'target',1792740842053),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1034,'target',1792740842069),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1035,'source',1792740842103),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1036,'source',1792740842119),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1037,'source',1792740842178),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1038,'source',1792740842197),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1039,'source',1792740842236),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1040,'source',1792740842252),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1041,'source',1792740842287),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1042,'source',1792740842303),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1043,'source',1792740842358),('060dfe59-6c11-4442-88b6-83194b5ff650','127.0.0.1:32816',1044,'source',1792740842376);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('060dfe59-6c11-4442-88b6-83194b5ff650','takeover-experiment',97062,'2026-10-23T07:33:59.694Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:49850|2126573955632886801',1792740840181);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('004510c7-bd53-4996-b3b7-727301af0b65','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1031,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740841449,8),('05c48f56-872e-4923-af75-cb5de9a874fa','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1030,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740840352,7),('0c36c05a-a94b-4588-b1d8-11f4abac23df','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1032,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740841912,10),('0c63117e-93c6-4d69-8dd2-23a6b28158d8','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1029,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740840292,6),('12421fbb-e526-4634-bf20-f54302fed92b','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1034,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740842069,13),('15526556-3bb6-4938-a555-7dbb0efbfdd8','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1036,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842119,15),('27119747-8843-4e19-8ac1-13a7b4328f6c','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1037,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842178,16),('3f5556bb-ad2d-4bfd-a04c-e7da48d79afd','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1028,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740840228,5),('4e03b033-be1c-48fe-b592-440649744c3c','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'owner_registered','{}',1792740840186,3),('52687439-3940-46e1-ac8a-63305e8fffec','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1038,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842198,17),('58509a4d-6354-4588-8a52-e3b1c68092b0','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740840214,4),('58617322-a34a-4668-aca2-26787944e669','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1033,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740842053,12),('5a8897ee-2366-4113-832b-dc493f86a837','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1035,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842104,14),('6a170cfd-704e-40d8-8483-02ff1f43c5cb','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1041,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842287,20),('6a5e25d3-f0b4-4435-992e-f6e58339e127','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1044,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842376,23),('71b7837f-4fc9-46a1-9a1f-85c3e2e5d986','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1042,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842303,21),('87ee02e1-8598-4ad7-a697-a8b9bcdd7766','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1039,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842236,18),('a60ad751-2ab4-4284-b3c7-c66d47e089a1','060dfe59-6c11-4442-88b6-83194b5ff650','table-00','writer_active','{\"grant\":\"2f214c41-d030-44ce-9647-7972bde5d0da\",\"permit\":\"a7d02272-8943-477b-b6f3-f2b34725a624\"}',1792740842027,11),('a873074e-a411-41d8-bdc9-1405c0ea875d','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1040,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842253,19),('c92a5f1e-7e27-416c-9597-127fa3db5097','060dfe59-6c11-4442-88b6-83194b5ff650','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"2f214c41-d030-44ce-9647-7972bde5d0da\",\"permit\":\"a7d02272-8943-477b-b6f3-f2b34725a624\"}',1792740841734,9),('fdb0d063-1543-40b9-aa8c-db3cec8a8d20','060dfe59-6c11-4442-88b6-83194b5ff650',NULL,'session_registered','{\"connection\":1043,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740842358,22);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','060dfe59-6c11-4442-88b6-83194b5ff650',1,'a7d02272-8943-477b-b6f3-f2b34725a624','2f214c41-d030-44ce-9647-7972bde5d0da','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'9c38f9a384f2b2028ef846e71a609b7ccce21f6429cddd5fc62beb024fa2a2fd','active',NULL);
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,23,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_c7cc721098a7\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_c7cc721098a7\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'running','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',2,0,'2f214c41-d030-44ce-9647-7972bde5d0da','060dfe59-6c11-4442-88b6-83194b5ff650');
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_d562efd76d3d` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_d562efd76d3d`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'4b44e2d2-c1f8-408b-aa8e-21cbedb1a103',1792740413232,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_d562efd76d3d\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_d562efd76d3d\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g�\�+�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'4b44e2d2-c1f8-408b-aa8e-21cbedb1a103',1792740413232,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g�\�+�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'4b44e2d2-c1f8-408b-aa8e-21cbedb1a103',1792740413232,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$c725fe78-1c18-4267-af3c-706164b2e84fitimestamp\0\0�g�\�,�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'4b44e2d2-c1f8-408b-aa8e-21cbedb1a103',1792740413443,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446lsourceNodeIdfsourcekfingerprintx@1ad1522f90cd402829127cd0311f8f4d35791f574a9ff9abc92a61d3efd843b7eupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'4b44e2d2-c1f8-408b-aa8e-21cbedb1a103',1792740413510,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:0eindex\0elower\�euppera3��itimestamp\0\0�g�\�F�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'4b44e2d2-c1f8-408b-aa8e-21cbedb1a103',1792740413561,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:1eindexelowera3euppera7��itimestamp\0\0�g�\�y�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'4b44e2d2-c1f8-408b-aa8e-21cbedb1a103',1792740413606,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g�Ц�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'4b44e2d2-c1f8-408b-aa8e-21cbedb1a103',1792740413615,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:0�itimestamp\0\0�g�Ю�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(9,0,'workflow-table-00',9,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740416465,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$d7c7c99d-26d3-453f-8b99-d1487087cc58itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(10,0,'workflow-table-00',10,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740416572,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.RetrySnapshotSplitbidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:0gattempt�itimestamp\0\0�g�\�<�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(11,0,'workflow-table-00',11,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740416800,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:0mbatchSequence\0gbatchIdx@e11095a5c5edb5ee8a7714e1288450d609b1553fdf79f4954bff75a8ffacfbd3fcursor�dkindwmysql.snapshot-split.v1evaluea1jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�\� �',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(12,0,'workflow-table-00',12,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740416928,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:0mbatchSequencegbatchIdx@08ed45c6b47d81ad71c62cbc59c90e533f4e5886d46c9e80ebe9b82d10d0d412fcursor�dkindwmysql.snapshot-split.v1evaluea3jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�ݠ�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(13,0,'workflow-table-00',13,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740416936,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:0gattempt�itimestamp\0\0�g�ݨ�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(14,0,'workflow-table-00',14,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740416988,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:1�itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(15,0,'workflow-table-00',15,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740417106,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:1mbatchSequence\0gbatchIdx@e5df08eae8064c0da461a1a0ad1a25a4c551b126ceddf154f2139125b8158061fcursor�dkindwmysql.snapshot-split.v1evaluea5jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�\�R�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(16,0,'workflow-table-00',16,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740417154,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:1mbatchSequencegbatchIdx@b5af1cfc4a7557d2c36eafda87a03039e560c9c10e71819c203882a7145f6b8bfcursor�dkindwmysql.snapshot-split.v1evaluea7jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�ނ�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(17,0,'workflow-table-00',17,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740417166,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:1gattempt\0�itimestamp\0\0�g�ލ�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(18,0,'workflow-table-00',18,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740417173,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:2�itimestamp\0\0�g�ޕ�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(19,0,'workflow-table-00',19,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740417251,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:2mbatchSequence\0gbatchIdx@14de319190da640226045894eba7f948103eff26cfea6de1bf2433f42b9c3f7ffcursor�dkindwmysql.snapshot-split.v1evaluep9007199254740993jupperBoundp9007199254740993�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(20,0,'workflow-table-00',20,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740417256,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxB6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:2gattempt\0�itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(21,0,'workflow-table-00',21,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740417260,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RetireSnapshotWindow$�itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(22,0,'workflow-table-00',22,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740417267,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex>cn.xuyinyin.magic.workflow.snapshot.FinishSnapshotEnumeration$�itimestamp\0\0�g�\�\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(23,0,'workflow-table-00',23,'046f1806-a69e-4b2d-8784-2e9c71300389',1792740417278,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfresult�fstatusicompletedgsuccess\�gmessagex\'Workflow executed successfully in 762msmrowsProcessed\nphasRowsProcessed\�hduration�khasDuration\�knodeResults��fnodeIdfsourcehnodeTypenmysql.snapshotfstatusicompletedgmessage`jhasMessage\�hduration�khasDuration\���fnodeIdftargethnodeTypekmysql.writefstatusicompletedgmessage`jhasMessage\�hduration�khasDuration\����itimestamp\0\0�g�\���',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-d562efd76d3d',90);
            DO RELEASE_LOCK('owner-probe-d562efd76d3d');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'0ca9fb0b-8075-4839-a519-2f6328b6a4a8','7f20c568-fe93-4d59-86b9-af683a37596e');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'f75da789-04a2-43a9-89cb-1ce0ea70d411','8fc902ea-75f9-456a-b20b-b4174a2da02f',1,10),(2,'f75da789-04a2-43a9-89cb-1ce0ea70d411','8fc902ea-75f9-456a-b20b-b4174a2da02f',1,10),(3,'f75da789-04a2-43a9-89cb-1ce0ea70d411','8fc902ea-75f9-456a-b20b-b4174a2da02f',1,10),(4,'f75da789-04a2-43a9-89cb-1ce0ea70d411','8fc902ea-75f9-456a-b20b-b4174a2da02f',1,15),(5,'f75da789-04a2-43a9-89cb-1ce0ea70d411','8fc902ea-75f9-456a-b20b-b4174a2da02f',1,17),(6,'f75da789-04a2-43a9-89cb-1ce0ea70d411','8fc902ea-75f9-456a-b20b-b4174a2da02f',1,19),(7,'f75da789-04a2-43a9-89cb-1ce0ea70d411','8fc902ea-75f9-456a-b20b-b4174a2da02f',1,21),(8,'f75da789-04a2-43a9-89cb-1ce0ea70d411','8fc902ea-75f9-456a-b20b-b4174a2da02f',1,21),(9,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,37),(10,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,40),(11,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,44),(12,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,46),(13,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,46),(14,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,46),(15,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,50),(16,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,52),(17,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,52),(18,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,52),(19,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,56),(20,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,56),(21,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,56),(22,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,56),(23,'074ce632-d29f-4ac3-be80-3c363fc1a2a6','fafcdb3b-5a4f-4704-a074-d655099157d8',2,56);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('074ce632-d29f-4ac3-be80-3c363fc1a2a6',2,'7f20c568-fe93-4d59-86b9-af683a37596e','launched'),('f75da789-04a2-43a9-89cb-1ce0ea70d411',1,'7f20c568-fe93-4d59-86b9-af683a37596e','retired');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_batch_evidence` VALUES ('08ed45c6b47d81ad71c62cbc59c90e533f4e5886d46c9e80ebe9b82d10d0d412','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab'),('14de319190da640226045894eba7f948103eff26cfea6de1bf2433f42b9c3f7f','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79'),('b5af1cfc4a7557d2c36eafda87a03039e560c9c10e71819c203882a7145f6b8b','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c'),('e11095a5c5edb5ee8a7714e1288450d609b1553fdf79f4954bff75a8ffacfbd3','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62'),('e5df08eae8064c0da461a1a0ad1a25a4c551b126ceddf154f2139125b8158061','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316');
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369040,'[\"root\"]',NULL,0,0,NULL),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369828,'[\"root\"]',1792740414308,2,1,'{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37],\"observedAt\":1792740414449,\"owner\":\"f75da789-04a2-43a9-89cb-1ce0ea70d411\",\"serverStarted\":1792740369459,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]}');
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',61,'control',1792740415065),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',62,'control',1792740415104),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',63,'control',1792740415130),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',64,'control',1792740415876),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',65,'journal',1792740416325),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',66,'target',1792740416528),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',67,'target',1792740416545),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',68,'source',1792740416603),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',69,'source',1792740416621),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',70,'target',1792740416698),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',71,'target',1792740416715),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',72,'target',1792740416862),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',74,'target',1792740416910),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',75,'source',1792740417008),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',76,'source',1792740417045),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',77,'target',1792740417069),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',78,'target',1792740417084),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',79,'target',1792740417121),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',80,'target',1792740417135),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',81,'source',1792740417189),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',82,'source',1792740417202),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',83,'target',1792740417220),('074ce632-d29f-4ac3-be80-3c363fc1a2a6','127.0.0.1:32816',84,'target',1792740417234),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',21,'control',1792740411863),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',22,'control',1792740411894),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',23,'control',1792740411916),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',24,'control',1792740412722),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',25,'journal',1792740413190),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',26,'target',1792740413354),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',27,'target',1792740413371),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',28,'source',1792740413406),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',29,'source',1792740413423),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',30,'source',1792740413477),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',31,'source',1792740413494),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',32,'source',1792740413530),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',33,'source',1792740413545),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',34,'source',1792740413577),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',35,'source',1792740413590),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',36,'source',1792740413640),('f75da789-04a2-43a9-89cb-1ce0ea70d411','127.0.0.1:32816',37,'source',1792740413652);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('074ce632-d29f-4ac3-be80-3c363fc1a2a6','takeover-experiment',93386,'2026-10-23T07:26:54.578Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:63600|-4666699626980985945',1792740415031),('f75da789-04a2-43a9-89cb-1ce0ea70d411','takeover-experiment',93378,'2026-10-23T07:26:51.367Z','db_drained','031bc478-de2e-4042-8855-08a3a4c07a04',1,1,'{\"confirmedAt\":1792740414278,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"031bc478-de2e-4042-8855-08a3a4c07a04\",\"owner\":\"f75da789-04a2-43a9-89cb-1ce0ea70d411\",\"pid\":93378,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:26:51.367Z\"}','pekko://snapshot-takeover@127.0.0.1:63542|6300925025374055901',1792740414478);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('005a0c66-faf5-440c-9515-729574d1097f','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":77,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740417069,49),('027e8d54-14bc-4d37-b9e3-af6e759c9010','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":71,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740416716,44),('0e1ebedf-a9ca-4510-848d-1227d2f08f4c','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'database_observed','{\"complete\":true,\"emptyRounds\":1,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37],\"observedAt\":1792740414308,\"owner\":\"f75da789-04a2-43a9-89cb-1ce0ea70d411\",\"serverStarted\":1792740369314,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740414337,26),('0f4c8424-e142-464c-9804-6171d5137b50','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":28,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413406,14),('14c50a73-4c82-4a3d-8cfe-f5e1ade2fd0e','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":84,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740417234,56),('1b2d7ca6-4b0c-4451-bb67-555ba52debf4','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740415058,31),('1c765e12-a46f-400a-bfa6-35e0b2b03e5f','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'revoking','{\"operation\":\"031bc478-de2e-4042-8855-08a3a4c07a04\"}',1792740414248,24),('2d8af288-5872-4c59-b99c-e2b55e7feca2','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":26,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740413354,12),('3350190e-5927-4b4b-9ba9-c85778a30823','f75da789-04a2-43a9-89cb-1ce0ea70d411','table-00','writer_active','{\"grant\":\"c725fe78-1c18-4267-af3c-706164b2e84f\",\"permit\":\"8fc902ea-75f9-456a-b20b-b4174a2da02f\"}',1792740413328,11),('35a048c4-ce6b-45ea-a575-77a25749ea6c','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":33,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413545,19),('35ae22ad-4307-489a-a30b-f77f76b6e062','f75da789-04a2-43a9-89cb-1ce0ea70d411','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"c725fe78-1c18-4267-af3c-706164b2e84f\",\"permit\":\"8fc902ea-75f9-456a-b20b-b4174a2da02f\"}',1792740413010,9),('382c87eb-4833-4f3e-b868-82595960c19b','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":23,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740411917,7),('3c061f34-1864-49e6-b021-3a3d95107118','f75da789-04a2-43a9-89cb-1ce0ea70d411','table-00','old_quota_released','{\"grant\":\"c725fe78-1c18-4267-af3c-706164b2e84f\"}',1792740414501,29),('40d6ab8a-958c-4cb1-8ce0-960e5093efd0','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":35,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413591,21),('4409d88b-ba6c-46c4-93de-3d6b23a6d130','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":36,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413640,22),('451f407c-e6e8-4067-abae-8986a52600f4','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":65,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740416326,37),('47bd8a24-c14b-4c6c-9195-70eb7720c754','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":64,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740415877,35),('4832e7aa-1fc7-4633-9e5d-ad1c85bda226','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":37,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413652,23),('515b9cb0-c94c-49ab-a614-ffc5acf3ab38','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'owner_registered','{}',1792740411824,3),('52de428f-749c-451c-8344-90168f9fb891','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":34,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413577,20),('566974b1-7575-425b-97d5-620ebdca02d4','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":74,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740416910,46),('5cd6345d-4ac5-4a91-a740-192ecc485850','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":69,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740416622,42),('6806afa5-4c3c-4559-ab12-9af68ba20c46','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":83,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740417220,55),('6bf26887-1062-4077-9aaa-f80486fa87c2','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":72,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740416862,45),('7173b128-de00-4d97-8dd0-4888ab6498c7','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":78,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740417085,50),('71ce4c7e-a07f-42fc-b333-281ec5711ed6','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":81,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740417190,53),('7575fecd-5ee5-4cd4-913a-06813bad66a4','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":67,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740416546,40),('7c6ef4d9-a234-4627-b369-67bbd51b61b8','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":30,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413478,16),('90a19992-a911-4c09-b122-858364021dcf','074ce632-d29f-4ac3-be80-3c363fc1a2a6','table-00','writer_active','{\"grant\":\"d7c7c99d-26d3-453f-8b99-d1487087cc58\",\"permit\":\"fafcdb3b-5a4f-4704-a074-d655099157d8\"}',1792740416503,38),('9ed9299b-9f75-43c8-a273-48bd25f83ae7','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":62,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740415105,33),('a08e6f63-380b-4d0b-9e85-0c173f2a7bd4','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":80,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740417135,52),('a720f7a1-b541-48f6-877b-c31e3fdc1935','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":31,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413495,17),('a99bdf40-2e1b-4df0-bcf8-807a369df054','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'fenced','{\"confirmedAt\":1792740414278,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"031bc478-de2e-4042-8855-08a3a4c07a04\",\"owner\":\"f75da789-04a2-43a9-89cb-1ce0ea70d411\",\"pid\":93378,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:26:51.367Z\"}',1792740414293,25),('ab85e36b-38b7-4da2-a66d-9fce2e5c68ec','074ce632-d29f-4ac3-be80-3c363fc1a2a6','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":2,\"grant\":\"d7c7c99d-26d3-453f-8b99-d1487087cc58\",\"permit\":\"fafcdb3b-5a4f-4704-a074-d655099157d8\"}',1792740416151,36),('b23481b3-9d2b-4767-87ef-881c13948903','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":32,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413530,18),('b9df55e1-7fd2-46fd-be38-d410ebb8e61e','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'owner_registered','{}',1792740415037,30),('bd73d63d-15b2-49d3-a49b-da3151182248','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":63,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740415131,34),('be63de8d-d5e7-4cec-988d-283aec1d7039','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":68,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740416604,41),('bf1254c9-6e31-4b51-8110-22b45049a3f2','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":76,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740417045,48),('c0b97572-fa78-4e0b-8be0-8584ff4cc578','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":22,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740411895,6),('cfd4a84c-ee84-4592-bfcd-f434dda4e364','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":70,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740416698,43),('d7ef0e57-3323-4b20-ba07-7164327472b9','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":21,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740411865,5),('d964791a-42f9-4843-b413-5eb4dbf6413a','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":82,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740417202,54),('d9aa6d78-c541-49e3-8a71-75a3dec768a9','074ce632-d29f-4ac3-be80-3c363fc1a2a6','table-00','quota_released','{\"disposition\":\"completed\",\"grant\":\"d7c7c99d-26d3-453f-8b99-d1487087cc58\"}',1792740417299,58),('dc197a3c-40f1-4492-bc65-c67b6a5373f7','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":24,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740412723,8),('dd43a795-c4b1-4ae9-89e1-c6367c7ffbe7','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740411853,4),('df3467f7-55af-4013-81e4-414e20475afa','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":61,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740415067,32),('e18d377b-4ce6-4876-a7b5-a52c0d75ff6f','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'db_drained','{\"complete\":true,\"emptyRounds\":2,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37],\"observedAt\":1792740414449,\"owner\":\"f75da789-04a2-43a9-89cb-1ce0ea70d411\",\"serverStarted\":1792740369459,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740414479,27),('e624f7d8-bd16-4c08-9320-c34ef3429294','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":79,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740417121,51),('eb25365a-cd0d-4d4b-a03a-1364b1f1e28b','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":25,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740413190,10),('ec37021e-d30a-4814-9218-58568e35b857','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":29,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740413424,15),('ed5a6a12-374e-44ae-8fc5-0b2217fc5ce2','f75da789-04a2-43a9-89cb-1ce0ea70d411',NULL,'session_registered','{\"connection\":27,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740413371,13),('f029374c-b9e2-4041-b4c2-4c731734fb57','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":75,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740417008,47),('f5b388e1-9add-43c0-ad64-0f4e233a63ae','074ce632-d29f-4ac3-be80-3c363fc1a2a6',NULL,'session_registered','{\"connection\":66,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740416528,39);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','074ce632-d29f-4ac3-be80-3c363fc1a2a6',2,'fafcdb3b-5a4f-4704-a074-d655099157d8','d7c7c99d-26d3-453f-8b99-d1487087cc58','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'dd8a81ef2149e84f185044ebf7d7a551071fd58910b316881d54b2fe87621de6','parked','f75da789-04a2-43a9-89cb-1ce0ea70d411');
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
INSERT INTO `pekko_sync_batch_ledger` VALUES ('08ed45c6b47d81ad71c62cbc59c90e533f4e5886d46c9e80ebe9b82d10d0d412','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:0',1,'mysql.snapshot-split.v1','3','3',2,2,'2026-10-23 07:26:56.916816'),('14de319190da640226045894eba7f948103eff26cfea6de1bf2433f42b9c3f7f','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:2',0,'mysql.snapshot-split.v1','9007199254740993','9007199254740993',2,2,'2026-10-23 07:26:57.240369'),('b5af1cfc4a7557d2c36eafda87a03039e560c9c10e71819c203882a7145f6b8b','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:1',1,'mysql.snapshot-split.v1','7','7',2,2,'2026-10-23 07:26:57.141487'),('e11095a5c5edb5ee8a7714e1288450d609b1553fdf79f4954bff75a8ffacfbd3','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:0',0,'mysql.snapshot-split.v1','1','3',2,2,'2026-10-23 07:26:56.767788'),('e5df08eae8064c0da461a1a0ad1a25a4c551b126ceddf154f2139125b8158061','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','6f83b3f9646c43e159982d95ce80adb8ecd87ad2e47dc83617206f92e5cef446:1',0,'mysql.snapshot-split.v1','5','7',2,2,'2026-10-23 07:26:57.093147');
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,58,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_d562efd76d3d\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_d562efd76d3d\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'completed','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',57,0,NULL,NULL);
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
INSERT INTO `target_audit` VALUES (1,'I',-9,NULL,2,NULL,'负键🙂'),(2,'I',1,NULL,0,NULL,'初始-1'),(3,'I',2,NULL,0,NULL,'初始-2'),(4,'I',3,NULL,0,NULL,'初始-3'),(5,'I',4,NULL,0,NULL,'初始-4'),(6,'I',5,NULL,0,NULL,'初始-5'),(7,'I',6,NULL,0,NULL,'初始-6'),(8,'I',7,NULL,0,NULL,'初始-7'),(9,'I',8,NULL,0,NULL,'初始-8'),(10,'I',9007199254740993,NULL,3,NULL,'大键🙂');
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
INSERT INTO `target_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pekko_test_cdc_window_f8408d6c9efd` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pekko_test_cdc_window_f8408d6c9efd`;
DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-table-00',1,'aac3387a-b9af-4f00-81d4-d2eb9f59e155',1792740763377,'',_binary '�lworkflowJsony+{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_f8408d6c9efd\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_f8408d6c9efd\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}hrevisionitimestamp\0\0�g�&\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-table-00',2,'aac3387a-b9af-4f00-81d4-d2eb9f59e155',1792740763377,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdgtrigger�dkindfmanualirequestIdltakeover-onejscheduleId\�kscheduledAt itriggerId\��pworkflowRevisionitimestamp\0\0�g�&\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-table-00',3,'aac3387a-b9af-4f00-81d4-d2eb9f59e155',1792740763377,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$1c2ddc0a-bf2e-409e-91af-5100b7e32be4itimestamp\0\0�g�&\��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(4,0,'workflow-table-00',4,'aac3387a-b9af-4f00-81d4-d2eb9f59e155',1792740763572,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex<cn.xuyinyin.magic.workflow.snapshot.InitializeSnapshotSplitsdplan�bidx@c6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453dlsourceNodeIdfsourcekfingerprintx@e314be89e7d7c88ef5c6cf1df09b615f3b7c0d4fb085db2adfed42ad5b8f9b3beupperp9007199254740993hpageRowsisplitRowskparallelismlmaxPageBytes\0��itimestamp\0\0�g�\'��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-table-00',5,'aac3387a-b9af-4f00-81d4-d2eb9f59e155',1792740763640,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:0eindex\0elower\�euppera3��itimestamp\0\0�g�\'��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(6,0,'workflow-table-00',6,'aac3387a-b9af-4f00-81d4-d2eb9f59e155',1792740763695,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:1eindexelowera3euppera7��itimestamp\0\0�g�(/�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(7,0,'workflow-table-00',7,'aac3387a-b9af-4f00-81d4-d2eb9f59e155',1792740763750,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RegisterSnapshotSplitesplit�bidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:2eindexelowera7eupperp9007199254740993��itimestamp\0\0�g�(f�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(8,0,'workflow-table-00',8,'aac3387a-b9af-4f00-81d4-d2eb9f59e155',1792740763763,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:0�itimestamp\0\0�g�(s�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(9,0,'workflow-table-00',9,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767042,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdephasegrunningggrantIdx$f3a44d94-40b1-4fd1-aadb-ff597c851e1eitimestamp\0\0�g�5@�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSchedulingChanged',NULL,NULL,NULL),(10,0,'workflow-table-00',10,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767163,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.RetrySnapshotSplitbidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:0gattempt�itimestamp\0\0�g�5��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(11,0,'workflow-table-00',11,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767344,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:0mbatchSequence\0gbatchIdx@18a6aadc90ea020d3c75a56acc95e050af00980bffdafecbcabf391e1bbc782ffcursor�dkindwmysql.snapshot-split.v1evaluea1jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�6o�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(12,0,'workflow-table-00',12,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767404,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:0mbatchSequencegbatchIdx@0d4da7aefd7af53889eb39f92cea1cff003e45988a9345d8e32c536d68b12217fcursor�dkindwmysql.snapshot-split.v1evaluea3jupperBounda3�qsourceRowsScannedqtargetRowsWritten�gattempt�itimestamp\0\0�g�6��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(13,0,'workflow-table-00',13,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767414,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:0gattempt�itimestamp\0\0�g�6��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(14,0,'workflow-table-00',14,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767422,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:1�itimestamp\0\0�g�6��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(15,0,'workflow-table-00',15,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767508,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:1mbatchSequence\0gbatchIdx@ab3954804accf3cb81013f9709a7c3513f4424e3d831e2fcc40f2cded7172942fcursor�dkindwmysql.snapshot-split.v1evaluea5jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�7�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(16,0,'workflow-table-00',16,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767551,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:1mbatchSequencegbatchIdx@6bea9c8e9b2c2dc7f9f87af42ae56489883658cbc20af1762ef135bbf0a7fedefcursor�dkindwmysql.snapshot-split.v1evaluea7jupperBounda7�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�7?�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(17,0,'workflow-table-00',17,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767556,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:1gattempt\0�itimestamp\0\0�g�7C�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(18,0,'workflow-table-00',18,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767560,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.StartSnapshotSplitbidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:2�itimestamp\0\0�g�7H�',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(19,0,'workflow-table-00',19,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767626,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex6cn.xuyinyin.magic.workflow.snapshot.CommitSnapshotPagejcheckpoint�lsourceNodeIdfsourcekpartitionIdxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:2mbatchSequence\0gbatchIdx@dc72357e56e04be34aff9572f0381273bd4bbc5e588b98a4c7b7f58af9fd0789fcursor�dkindwmysql.snapshot-split.v1evaluep9007199254740993jupperBoundp9007199254740993�qsourceRowsScannedqtargetRowsWritten�gattempt\0�itimestamp\0\0�g�7��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(20,0,'workflow-table-00',20,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767630,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.CompleteSnapshotSplitbidxBc6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:2gattempt\0�itimestamp\0\0�g�7��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(21,0,'workflow-table-00',21,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767635,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex9cn.xuyinyin.magic.workflow.snapshot.RetireSnapshotWindow$�itimestamp\0\0�g�7��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(22,0,'workflow-table-00',22,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767642,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfupdate�e_typex>cn.xuyinyin.magic.workflow.snapshot.FinishSnapshotEnumeration$�itimestamp\0\0�g�7��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(23,0,'workflow-table-00',23,'bb4a99ac-bcc7-4743-85a5-e600726ea41d',1792740767653,'',_binary '�kexecutionIdx@478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fdfresult�fstatusicompletedgsuccess\�gmessagex\'Workflow executed successfully in 561msmrowsProcessed\nphasRowsProcessed\�hduration1khasDuration\�knodeResults��fnodeIdfsourcehnodeTypenmysql.snapshotfstatusicompletedgmessage`jhasMessage\�hduration1khasDuration\���fnodeIdftargethnodeTypekmysql.writefstatusicompletedgmessage`jhasMessage\�hduration1khasDuration\����itimestamp\0\0�g�7��',33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `owner_probe_journal_wait` BEFORE INSERT ON `event_journal` FOR EACH ROW BEGIN
          IF NEW.persistence_id='workflow-table-00' AND (SELECT armed FROM owner_probe_journal_gate WHERE id=1) THEN
            SET @owner_probe_wait = GET_LOCK('owner-probe-f8408d6c9efd',90);
            DO RELEASE_LOCK('owner-probe-f8408d6c9efd');
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `guardian_probe_journal_write` AFTER INSERT ON `event_journal` FOR EACH ROW BEGIN IF NEW.persistence_id='workflow-table-00' THEN INSERT INTO guardian_probe_journal_writes
            SELECT NEW.sequence_number,
            (SELECT ATTR_VALUE FROM performance_schema.session_connect_attrs WHERE PROCESSLIST_ID=CONNECTION_ID() AND ATTR_NAME='pekko_owner'),
            (SELECT permit_id FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT generation FROM pekko_snapshot_writer_permissions WHERE workflow_id='table-00'),
            (SELECT queue_sequence FROM pekko_table_admission_lock WHERE id=1); END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_controller` (
  `id` int NOT NULL,
  `epoch` bigint NOT NULL,
  `controller` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_controller` WRITE;
/*!40000 ALTER TABLE `guardian_probe_controller` DISABLE KEYS */;
INSERT INTO `guardian_probe_controller` VALUES (1,2,'5a209fe3-16d1-4783-b068-34e2deb94a7f','ae106e6a-989b-4e30-aa2b-a4ab7ba43eec');
/*!40000 ALTER TABLE `guardian_probe_controller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_journal_writes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_journal_writes` (
  `sequence_number` bigint DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `permit_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `generation` bigint DEFAULT NULL,
  `admission_sequence` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_journal_writes` WRITE;
/*!40000 ALTER TABLE `guardian_probe_journal_writes` DISABLE KEYS */;
INSERT INTO `guardian_probe_journal_writes` VALUES (1,'a209cbf4-29fa-42e2-84a0-928ae2e4fe91','bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3',1,10),(2,'a209cbf4-29fa-42e2-84a0-928ae2e4fe91','bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3',1,10),(3,'a209cbf4-29fa-42e2-84a0-928ae2e4fe91','bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3',1,10),(4,'a209cbf4-29fa-42e2-84a0-928ae2e4fe91','bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3',1,15),(5,'a209cbf4-29fa-42e2-84a0-928ae2e4fe91','bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3',1,17),(6,'a209cbf4-29fa-42e2-84a0-928ae2e4fe91','bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3',1,19),(7,'a209cbf4-29fa-42e2-84a0-928ae2e4fe91','bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3',1,21),(8,'a209cbf4-29fa-42e2-84a0-928ae2e4fe91','bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3',1,21),(9,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,37),(10,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,40),(11,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,44),(12,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,46),(13,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,46),(14,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,46),(15,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,50),(16,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,52),(17,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,52),(18,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,52),(19,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,56),(20,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,56),(21,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,56),(22,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,56),(23,'1264bd79-7744-40bd-b500-0c1f1f5617a9','46d0b6d4-aa12-452b-b26c-07c8e7f8ee55',2,56);
/*!40000 ALTER TABLE `guardian_probe_journal_writes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guardian_probe_launches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardian_probe_launches` (
  `boot` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `epoch` bigint NOT NULL,
  `guardian` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`boot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guardian_probe_launches` WRITE;
/*!40000 ALTER TABLE `guardian_probe_launches` DISABLE KEYS */;
INSERT INTO `guardian_probe_launches` VALUES ('1264bd79-7744-40bd-b500-0c1f1f5617a9',2,'ae106e6a-989b-4e30-aa2b-a4ab7ba43eec','launched'),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91',1,'ae106e6a-989b-4e30-aa2b-a4ab7ba43eec','retired');
/*!40000 ALTER TABLE `guardian_probe_launches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owner_probe_journal_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_probe_journal_gate` (
  `id` int NOT NULL,
  `armed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owner_probe_journal_gate` WRITE;
/*!40000 ALTER TABLE `owner_probe_journal_gate` DISABLE KEYS */;
INSERT INTO `owner_probe_journal_gate` VALUES (1,0);
/*!40000 ALTER TABLE `owner_probe_journal_gate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_batch_evidence` VALUES ('0d4da7aefd7af53889eb39f92cea1cff003e45988a9345d8e32c536d68b12217','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab','64f1111b810cb65a151b59cef1ebee2e78b10868318c3ab2134c1d367c4f5dab'),('18a6aadc90ea020d3c75a56acc95e050af00980bffdafecbcabf391e1bbc782f','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62','ad83aa9e14b6312096f2a07608359d4dc4e9051c37c6ab1d3350656c8ce1bd62'),('6bea9c8e9b2c2dc7f9f87af42ae56489883658cbc20af1762ef135bbf0a7fede','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c','eace11469b089c8fcfdf61353c35295a87b226fb29e99094b4c90df87b02f51c'),('ab3954804accf3cb81013f9709a7c3513f4424e3d831e2fcc40f2cded7172942','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316','4c0c3d28b1de87f613a6d3c78e3c1a584476c3657e13c9a9f0738827f0c73316'),('dc72357e56e04be34aff9572f0381273bd4bbc5e588b98a4c7b7f58af9fd0789','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79','58adeebd01937e456b903f6937b56b3ab4e8e3dff7cc66fde4fe2c7471f7dc79');
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_instances` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_uuid` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `server_started` bigint NOT NULL,
  `database_users` text COLLATE utf8mb4_bin NOT NULL,
  `empty_since` bigint DEFAULT NULL,
  `empty_rounds` int NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `observation` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`owner_id`,`instance_id`),
  KEY `pekko_snapshot_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_instances` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_instances` VALUES ('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369629,'[\"root\"]',NULL,0,0,NULL),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816','0056237a-ceb3-11f1-b168-3ea0f585eb45',1792740369966,'[\"root\"]',1792740764749,2,1,'{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127],\"observedAt\":1792740764891,\"owner\":\"a209cbf4-29fa-42e2-84a0-928ae2e4fe91\",\"serverStarted\":1792740369900,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]}');
/*!40000 ALTER TABLE `pekko_snapshot_owner_instances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owner_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owner_sessions` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `instance_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `connection_id` bigint NOT NULL,
  `role_name` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `registered_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`,`instance_id`,`connection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owner_sessions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owner_sessions` VALUES ('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',169,'control',1792740765658),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',170,'control',1792740765698),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',171,'control',1792740765728),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',172,'control',1792740766467),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',173,'journal',1792740766917),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',174,'target',1792740767104),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',175,'target',1792740767123),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',176,'source',1792740767198),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',178,'source',1792740767227),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',179,'target',1792740767300),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',180,'target',1792740767322),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',181,'target',1792740767366),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',182,'target',1792740767385),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',183,'source',1792740767443),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',184,'source',1792740767456),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',185,'target',1792740767476),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',186,'target',1792740767491),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',187,'target',1792740767522),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',188,'target',1792740767535),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',189,'source',1792740767572),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',190,'source',1792740767583),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',191,'target',1792740767598),('1264bd79-7744-40bd-b500-0c1f1f5617a9','127.0.0.1:32816',192,'target',1792740767609),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',111,'control',1792740761995),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',112,'control',1792740762028),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',113,'control',1792740762054),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',114,'control',1792740762846),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',115,'journal',1792740763324),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',116,'target',1792740763481),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',117,'target',1792740763498),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',118,'source',1792740763534),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',119,'source',1792740763551),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',120,'source',1792740763607),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',121,'source',1792740763623),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',122,'source',1792740763663),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',123,'source',1792740763679),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',124,'source',1792740763712),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',125,'source',1792740763729),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',126,'source',1792740763789),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','127.0.0.1:32816',127,'source',1792740763804);
/*!40000 ALTER TABLE `pekko_snapshot_owner_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_owners` (
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `process_id` bigint NOT NULL,
  `start_identity` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `manifest_version` bigint NOT NULL,
  `sealed_version` bigint DEFAULT NULL,
  `isolation_proof` text COLLATE utf8mb4_bin,
  `cluster_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` bigint NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_owners` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_owners` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_owners` VALUES ('1264bd79-7744-40bd-b500-0c1f1f5617a9','takeover-experiment',95620,'2026-10-23T07:32:45.068Z','active',NULL,1,NULL,NULL,'pekko://snapshot-takeover@127.0.0.1:64904|5349464456865396630',1792740765619),('a209cbf4-29fa-42e2-84a0-928ae2e4fe91','takeover-experiment',95610,'2026-10-23T07:32:41.520Z','db_drained','dd0923ce-edba-4753-84fb-25d248db0d61',1,1,'{\"confirmedAt\":1792740764664,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"dd0923ce-edba-4753-84fb-25d248db0d61\",\"owner\":\"a209cbf4-29fa-42e2-84a0-928ae2e4fe91\",\"pid\":95610,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:32:41.520Z\"}','pekko://snapshot-takeover@127.0.0.1:64817|931688959352512487',1792740764908);
/*!40000 ALTER TABLE `pekko_snapshot_owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_ownership_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_ownership_audit` (
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `details` text COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  `event_sequence` bigint NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_ownership_audit` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_ownership_audit` VALUES ('007fb9e4-7b68-4d2c-bc72-1b53f03e73cf','1264bd79-7744-40bd-b500-0c1f1f5617a9','table-00','writer_active','{\"grant\":\"f3a44d94-40b1-4fd1-aadb-ff597c851e1e\",\"permit\":\"46d0b6d4-aa12-452b-b26c-07c8e7f8ee55\"}',1792740767080,38),('01c5cf3d-c412-4545-8e22-93fa47d7029d','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":184,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740767457,48),('08c144b8-2a4c-4572-bbd3-7aa149dd2698','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":186,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767492,50),('09a63749-418f-4abc-892a-b680570292be','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":191,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767598,55),('1306e5f5-6524-4d0e-94e4-0c91db98d3be','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":188,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767536,52),('16a05551-af6b-4940-9ed0-902de36f6132','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":120,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763607,16),('1ab33f32-ea8d-4cd8-b4fb-45b19eee45f2','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":126,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763789,22),('1b3e64f7-d3ae-42bc-ac9e-ff4b08dd364e','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":113,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740762054,7),('1d73972f-a221-40d2-87e7-c4c61d31d485','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":192,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767610,56),('1e225372-a6c8-41d8-b043-adc0950cdd5d','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'owner_registered','{}',1792740761960,3),('1ebd7b6b-7216-4d64-bc91-db7ae96d2742','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":176,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740767198,41),('2279aba6-c09f-41ae-b09c-a80550d09ae0','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":183,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740767443,47),('2b973310-f61e-475b-865a-4350432a956a','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":114,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740762847,8),('2c1f81ad-65e5-4cc0-8d4a-36a770fd37c5','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":175,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767123,40),('327c04e1-7191-460a-bc45-721f978f293f','1264bd79-7744-40bd-b500-0c1f1f5617a9','table-00','quota_released','{\"disposition\":\"completed\",\"grant\":\"f3a44d94-40b1-4fd1-aadb-ff597c851e1e\"}',1792740767679,58),('3ee7fc4c-5d04-4205-88db-cdbffc6d4350','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":179,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767304,43),('4e67aa11-1730-4b41-ad97-788e33e44593','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":111,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740761996,5),('541f1c20-cce0-4610-8b4a-c01660dea34f','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":172,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740766467,35),('550fe714-8e4f-4817-b194-7aea6edfdaab','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":123,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763679,19),('64a94e89-2ea7-4af0-9061-e600ee20c822','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740761987,4),('68e4a9ae-88ab-4382-b74c-661a5ce31945','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":121,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763623,17),('69b6575c-6523-4ad4-81b5-c4956c8553ed','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":182,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767385,46),('7411cea4-72db-449a-b231-58b9521e96a3','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":189,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740767572,53),('75a6115f-2139-478f-b7ea-8ac04fabf6ab','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'db_drained','{\"complete\":true,\"emptyRounds\":2,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127],\"observedAt\":1792740764891,\"owner\":\"a209cbf4-29fa-42e2-84a0-928ae2e4fe91\",\"serverStarted\":1792740369900,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740764909,27),('7e9d84a3-6b38-4ad3-9da1-a4e6debe5406','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":190,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740767583,54),('80078412-3ef7-4848-ba58-a5c1ca016eb8','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":112,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740762029,6),('8678d962-38c3-45bb-8654-722a254f63bf','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'database_observed','{\"complete\":true,\"emptyRounds\":1,\"evidence\":{\"instance\":\"127.0.0.1:32816\",\"knownIds\":[111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127],\"observedAt\":1792740764749,\"owner\":\"a209cbf4-29fa-42e2-84a0-928ae2e4fe91\",\"serverStarted\":1792740369756,\"sessions\":[],\"transactions\":[],\"unassignedTransactions\":[],\"unattributed\":[]},\"instance\":\"127.0.0.1:32816\",\"sessions\":0,\"transactions\":0,\"unattributed\":0}',1792740764773,26),('8740a313-8aa8-4993-b6f0-022ff8ac926f','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":185,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767476,49),('875e6bad-dee7-4f9b-827d-f7962dd66d16','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'revoking','{\"operation\":\"dd0923ce-edba-4753-84fb-25d248db0d61\"}',1792740764637,24),('906272e7-b084-4280-a6d3-f20f6cf7e078','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":127,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763805,23),('9590f461-affc-495d-83f3-ac27c74f812a','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":125,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763730,21),('99bb298d-c656-407d-a10a-72fa82b0616e','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":118,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763535,14),('a2d219af-39fa-49ce-8684-d3ab7fa6a91f','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":170,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740765699,33),('a6185dc0-31c3-4e5b-820a-742c3f4d9846','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":122,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763663,18),('ab15e0a7-417f-453f-a7d5-fb4984d36ba8','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":174,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767104,39),('b3e85745-296b-4cf1-8764-384eed4c62a3','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":187,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767522,51),('b4f1f8cc-4ffe-449e-8cbe-838b41afb892','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":169,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740765660,32),('b69501f9-57aa-42bf-beb9-c40fe019a7ce','1264bd79-7744-40bd-b500-0c1f1f5617a9','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":2,\"grant\":\"f3a44d94-40b1-4fd1-aadb-ff597c851e1e\",\"permit\":\"46d0b6d4-aa12-452b-b26c-07c8e7f8ee55\"}',1792740766753,36),('bfc4cb85-37b5-49e0-96dc-11e1fdeacfaf','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'instance_registered','{\"instance\":\"127.0.0.1:32816\"}',1792740765647,31),('c4e7b3b3-2fb3-4aff-9b79-800516284c2c','a209cbf4-29fa-42e2-84a0-928ae2e4fe91','table-00','old_quota_released','{\"grant\":\"1c2ddc0a-bf2e-409e-91af-5100b7e32be4\"}',1792740764982,29),('c5bf9a06-d217-47cf-a1b8-009c14cc529f','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":116,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740763482,12),('cf2f6188-9967-421a-970d-3c42b368c607','a209cbf4-29fa-42e2-84a0-928ae2e4fe91','table-00','writer_active','{\"grant\":\"1c2ddc0a-bf2e-409e-91af-5100b7e32be4\",\"permit\":\"bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3\"}',1792740763450,11),('d0f8ba75-4064-4cd5-980d-e4133db4ecb3','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":181,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767366,45),('d468ed90-81bd-4706-9d48-8d661e9d0ea3','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":115,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740763325,10),('d73ec13c-e90e-4db2-8331-51e5f799b736','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":117,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740763498,13),('e00d9fea-c46c-48da-9f62-6419bafadc57','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":178,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740767228,42),('e7bc90bc-1a3a-4001-a59d-dfec6524f6bb','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":173,\"instance\":\"127.0.0.1:32816\",\"role\":\"journal\"}',1792740766918,37),('e9e9030b-e04a-48ff-a7a3-ea974105c71b','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":171,\"instance\":\"127.0.0.1:32816\",\"role\":\"control\"}',1792740765729,34),('ecd5ff33-cb93-435d-818f-e98833b83a6e','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":124,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763712,20),('f131c0e2-c4c7-46aa-a68f-2a1fd24fc0ab','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'owner_registered','{}',1792740765624,30),('f15f01f2-cc97-4adb-aefe-ddbdcb2228e7','1264bd79-7744-40bd-b500-0c1f1f5617a9',NULL,'session_registered','{\"connection\":180,\"instance\":\"127.0.0.1:32816\",\"role\":\"target\"}',1792740767323,44),('f2e2b385-ebb1-470c-bf7b-258906735acf','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'session_registered','{\"connection\":119,\"instance\":\"127.0.0.1:32816\",\"role\":\"source\"}',1792740763551,15),('f33d6437-9091-4e7d-9dce-e4756dfba2f4','a209cbf4-29fa-42e2-84a0-928ae2e4fe91','table-00','recovery_permitted','{\"execution\":\"478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd\",\"generation\":1,\"grant\":\"1c2ddc0a-bf2e-409e-91af-5100b7e32be4\",\"permit\":\"bb045a9f-5e51-4f9d-a0da-7bfc738b1ad3\"}',1792740763140,9),('fbadf39c-0b3c-4d43-9e89-90edd7606687','a209cbf4-29fa-42e2-84a0-928ae2e4fe91',NULL,'fenced','{\"confirmedAt\":1792740764664,\"deployment\":\"takeover-experiment\",\"details\":{\"alive\":false,\"automaticRestart\":false,\"exitCode\":137},\"operation\":\"dd0923ce-edba-4753-84fb-25d248db0d61\",\"owner\":\"a209cbf4-29fa-42e2-84a0-928ae2e4fe91\",\"pid\":95610,\"provider\":\"managed-child-jvm\",\"startIdentity\":\"2026-10-23T07:32:41.520Z\"}',1792740764676,25);
/*!40000 ALTER TABLE `pekko_snapshot_ownership_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_schedule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_schedule_triggers` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `schedule_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `scheduled_at` bigint NOT NULL,
  `trigger_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `disposition` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `recorded_at` bigint NOT NULL,
  PRIMARY KEY (`workflow_id`,`trigger_id`),
  KEY `pekko_snapshot_schedule_watermark` (`workflow_id`,`schedule_id`,`scheduled_at`),
  KEY `pekko_snapshot_schedule_execution` (`execution_id`,`disposition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_schedule_triggers` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_schedule_triggers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_snapshot_writer_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_writer_permissions` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generation` bigint NOT NULL,
  `permit_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `grant_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `definition_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `predecessor_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_snapshot_writer_permissions` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` DISABLE KEYS */;
INSERT INTO `pekko_snapshot_writer_permissions` VALUES ('table-00','1264bd79-7744-40bd-b500-0c1f1f5617a9',2,'46d0b6d4-aa12-452b-b26c-07c8e7f8ee55','f3a44d94-40b1-4fd1-aadb-ff597c851e1e','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd',1,'614b0ff9962b41c15ee7d63ee44878c09d7e06832641bfe3045e65bbf9429ca4','parked','a209cbf4-29fa-42e2-84a0-928ae2e4fe91');
/*!40000 ALTER TABLE `pekko_snapshot_writer_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
INSERT INTO `pekko_sync_batch_ledger` VALUES ('0d4da7aefd7af53889eb39f92cea1cff003e45988a9345d8e32c536d68b12217','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:0',1,'mysql.snapshot-split.v1','3','3',2,2,'2026-10-23 07:32:47.395286'),('18a6aadc90ea020d3c75a56acc95e050af00980bffdafecbcabf391e1bbc782f','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:0',0,'mysql.snapshot-split.v1','1','3',2,2,'2026-10-23 07:32:47.333258'),('6bea9c8e9b2c2dc7f9f87af42ae56489883658cbc20af1762ef135bbf0a7fede','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:1',1,'mysql.snapshot-split.v1','7','7',2,2,'2026-10-23 07:32:47.541375'),('ab3954804accf3cb81013f9709a7c3513f4424e3d831e2fcc40f2cded7172942','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:1',0,'mysql.snapshot-split.v1','5','7',2,2,'2026-10-23 07:32:47.498181'),('dc72357e56e04be34aff9572f0381273bd4bbc5e588b98a4c7b7f58af9fd0789','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','source','c6e6011d3b860841d882cc0517f507f7ece5ea1db2bd0109be6973274dd8453d:2',0,'mysql.snapshot-split.v1','9007199254740993','9007199254740993',2,2,'2026-10-23 07:32:47.615993');
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_admission_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_admission_lock` (
  `id` int NOT NULL,
  `queue_sequence` bigint NOT NULL,
  `policy_hash` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_admission_lock` WRITE;
/*!40000 ALTER TABLE `pekko_table_admission_lock` DISABLE KEYS */;
INSERT INTO `pekko_table_admission_lock` VALUES (1,58,'f2ded67ca3f256506a6594ebbe04de34532045c5a7964245da47665fde5979a7');
/*!40000 ALTER TABLE `pekko_table_admission_lock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_requests` (
  `request_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_requests` WRITE;
/*!40000 ALTER TABLE `pekko_table_requests` DISABLE KEYS */;
INSERT INTO `pekko_table_requests` VALUES ('72ee24b36b6d61d96a76c497f4b287cbc281a6b2647510b603835f4ccd62441c','table-00','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd');
/*!40000 ALTER TABLE `pekko_table_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pekko_table_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_table_tasks` (
  `workflow_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `revision` bigint NOT NULL,
  `workflow_json` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `source_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `target_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `parallelism` int NOT NULL,
  `page_bytes` int NOT NULL,
  `phase` varchar(24) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `request_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `queue_order` bigint NOT NULL,
  `not_before` bigint NOT NULL,
  `grant_id` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `owner_id` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `pekko_table_ready` (`phase`,`queue_order`,`workflow_id`),
  KEY `pekko_table_due` (`phase`,`not_before`,`workflow_id`),
  KEY `pekko_table_owner` (`owner_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pekko_table_tasks` WRITE;
/*!40000 ALTER TABLE `pekko_table_tasks` DISABLE KEYS */;
INSERT INTO `pekko_table_tasks` VALUES ('table-00',1,'{\"author\":\"test\",\"description\":\"quiescent multi-table fixture\",\"edges\":[{\"animated\":false,\"id\":\"edge\",\"source\":\"source\",\"sourceHandle\":\"out\",\"target\":\"target\",\"targetHandle\":\"in\"}],\"id\":\"table-00\",\"metadata\":{\"createdAt\":\"now\",\"updatedAt\":\"now\"},\"name\":\"table-00\",\"nodes\":[{\"config\":{\"chunkSize\":2,\"columns\":[\"id\",\"label\",\"amount\",\"note\",\"updated_at\",\"revision\"],\"database\":\"pekko_test_cdc_window_f8408d6c9efd\",\"host\":\"127.0.0.1\",\"maxPageBytes\":4096,\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"primaryKey\":\"id\",\"snapshotConsistency\":\"quiescent\",\"splitParallelism\":1,\"splitRows\":4,\"table\":\"source_rows\",\"username\":\"root\"},\"id\":\"source\",\"label\":\"source\",\"nodeType\":\"mysql.snapshot\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"source\"},{\"config\":{\"batchSize\":2,\"database\":\"pekko_test_cdc_window_f8408d6c9efd\",\"host\":\"127.0.0.1\",\"mode\":\"insert\",\"passwordEnv\":\"CDC_WINDOW_MYSQL_PASSWORD\",\"port\":32816,\"table\":\"target_rows\",\"username\":\"root\"},\"id\":\"target\",\"label\":\"target\",\"nodeType\":\"mysql.write\",\"position\":{\"x\":0.0,\"y\":0.0},\"type\":\"sink\"}],\"tags\":[],\"version\":\"1\"}','127.0.0.1:32816','127.0.0.1:32816',1,4096,'completed','478a5671ca2899bb9021f6fa17dfefec72a9773840f1b4208715013963cdb1fd','takeover-one',57,0,NULL,NULL);
/*!40000 ALTER TABLE `pekko_table_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
INSERT INTO `source_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
INSERT INTO `target_audit` VALUES (1,'I',-9,NULL,2,NULL,'负键🙂'),(2,'I',1,NULL,0,NULL,'初始-1'),(3,'I',2,NULL,0,NULL,'初始-2'),(4,'I',3,NULL,0,NULL,'初始-3'),(5,'I',4,NULL,0,NULL,'初始-4'),(6,'I',5,NULL,0,NULL,'初始-5'),(7,'I',6,NULL,0,NULL,'初始-6'),(8,'I',7,NULL,0,NULL,'初始-7'),(9,'I',8,NULL,0,NULL,'初始-8'),(10,'I',9007199254740993,NULL,3,NULL,'大键🙂');
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
INSERT INTO `target_rows` VALUES (-9,'负键🙂',-123.4500,'','2026-10-23 00:00:00.000001',2),(1,'初始-1',1.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(2,'初始-2',2.1200,NULL,'2026-10-18 01:02:03.654321',0),(3,'初始-3',3.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(4,'初始-4',4.1200,NULL,'2026-10-18 01:02:03.654321',0),(5,'初始-5',5.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(6,'初始-6',6.1200,NULL,'2026-10-18 01:02:03.654321',0),(7,'初始-7',7.1200,'  中文🙂  ','2026-10-18 01:02:03.654321',0),(8,'初始-8',8.1200,NULL,'2026-10-18 01:02:03.654321',0),(9007199254740993,'大键🙂',99999999999999.9999,NULL,'2026-10-23 23:59:59.999999',3);
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

