from pathlib import Path
import json,re,subprocess,os,hashlib,tarfile,io,shutil,difflib
repo=Path.cwd();tmp=Path('/tmp/pekko-stage-c-20261019');root=repo/'docs/experiments/2026-10-19-stage-c-sessions';root.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
settings=json.loads((tmp/'settings.json').read_text())
protected=json.loads((tmp/'protected-materials.json').read_text())
assert all(sha(Path(f).read_bytes())==h for f,h in protected.items())
frozen=json.loads((tmp/'final-source-manifest.json').read_text())
assert all(sha(Path(f).read_bytes())==h for f,h in frozen.items()), 'source changed after final freeze'
log=(tmp/'final-real-ten.log').read_text()
runs=dict(re.findall(r'CDC_RECOVERY_WINDOW_OBSERVED scenario=(\w+) evidence=(\S+)',log));assert len(runs)==8
sessions=dict(re.findall(r'CDC_SESSION_RELEASE_OBSERVED fault=([\w-]+) evidence=(\S+)',log));assert set(sessions)=={'none','cancel-T'}
assert json.loads((tmp/'final-real-result.json').read_text())['exitCode']==0
files={};records=[]
for case,folder in list(runs.items())+[("sessions/"+k,v) for k,v in sessions.items()]:
 p=Path(folder)
 if case.startswith('sessions/'):
  schema=json.loads((p/'outcome.json').read_text())['schema']
 else:schema=json.loads((p/'environment.json').read_text())['schema']
 env=os.environ.copy();env['MYSQL_PWD']=settings['CDC_WINDOW_MYSQL_PASSWORD']
 dump=subprocess.run(['docker','exec','-e','MYSQL_PWD','pekko-cdc-stage-c-20261019','mysqldump','-uroot','--single-transaction','--hex-blob','--set-gtid-purged=OFF','--skip-comments',schema],env=env,capture_output=True)
 assert dump.returncode==0,dump.stderr.decode()
 (p/'database-final.sql').write_bytes(dump.stdout)
 for f in p.iterdir():
  if f.is_file():files[case+'/'+f.name]=f.read_bytes()
 records.append(dict(scenario=case,runDirectory=p.name,schema=schema))
# Earlier runs are observations, never added to the formal coverage count.
for logfile in ['real-ten.log','formal-real-ten.log']:
 text=(tmp/logfile).read_text()
 observed=re.findall(r'(?:CDC_RECOVERY_WINDOW_OBSERVED scenario=\w+|CDC_SESSION_RELEASE_OBSERVED fault=[\w-]+) evidence=(\S+)',text)
 for folder in observed:
  p=Path(folder)
  for f in p.iterdir():
   if f.is_file():files['exploratory/'+logfile.removesuffix('.log')+'/'+p.name+'/'+f.name]=f.read_bytes()
for f in tmp.iterdir():
 if f.suffix in ('.log','.py','.diff') or (f.suffix=='.json' and f.name!='settings.json'):
  files['checks/'+f.name]=f.read_bytes()
sourcehash={}
for rel,h in frozen.items():
 data=Path(rel).read_bytes();files['source/'+rel]=data;sourcehash[rel]=h
for rel in ['build.sbt','quick-test.sh']:
 data=Path(rel).read_bytes();files['source/'+rel]=data;sourcehash[rel]=sha(data)
changed=[];patch=[];before=tmp/'before'
for rel in frozen:
 p=before/rel;old=p.read_bytes() if p.is_file() else b'';new=Path(rel).read_bytes()
 if old!=new:
  changed.append(rel);patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
files['checks/stage-c.diff']=''.join(patch).encode()
# Protect actual recovery structures and data-plane semantics separately from lifecycle edits.
unchanged=['pekko-server/src/main/scala/cn/xuyinyin/magic/workflow/nodes/sources/MySQLCdcGroupAssembler.scala','pekko-server/src/main/scala/cn/xuyinyin/magic/workflow/nodes/sinks/MySQLCdcApplySinkNode.scala']
assert all((before/f).read_bytes()==Path(f).read_bytes() for f in unchanged)
engine='pekko-server/src/main/scala/cn/xuyinyin/magic/workflow/engine/WorkflowExecutionEngine.scala'
def batch_body(t):return t[t.index('  private def processBatch('):t.index('  private def checkpoint(')]
assert batch_body((before/engine).read_text())==batch_body(Path(engine).read_text())
source=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),workingTree='Uncommitted A/B and recovery probes preserved; C scoped changes, no commit/push',sourceSha256=sourcehash,stageCFiles=changed,unchangedProtocolFiles=unchanged,processBatchBodyUnchanged=True)
(root/'source-manifest.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
image=json.loads(subprocess.check_output(['docker','inspect','pekko-cdc-stage-c-20261019']))[0]
manifest=dict(date='2026-10-19',java='Microsoft OpenJDK 17.0.14',pekko='1.1.3',debezium='3.6.1.Final',container='pekko-cdc-stage-c-20261019',image=image['Image'],containerArguments=image['Config']['Cmd'],formalRuns=records,formalJvmChildren=28,earlierRounds='two preliminary ten-case rounds preserved under exploratory; no extra coverage claimed',sourceFrozen=True,executionResult=json.loads((tmp/'final-real-result.json').read_text()))
(root/'run-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
checks=(tmp/'final-validation.log').read_text(errors='replace')
summaries=re.findall(r'Tests: succeeded (\d+), failed (\d+), canceled (\d+), ignored (\d+), pending (\d+)',checks)
assert len(summaries)==2 and summaries[0][0]=='156' and summaries[0][1]=='0' and summaries[1][1]=='0'
aborted=re.findall(r'\[info\] (\S+) \*\*\* ABORTED',checks)
assert len(aborted)==2 and all('Calcite' in n or 'MysqlSqlParserSpec' in n for n in aborted)
validation=dict(packageArtifact=json.loads((tmp/'package-result.json').read_text()),focusedTests=int(summaries[0][0]),focusedSuites=10,fullModule=dict(passed=int(summaries[1][0]),failed=0,abortedSuites=aborted,gate='evidence_incomplete'),realWindowObservations=8,realConverged=7,knownAutomaticRecoveryFailure='C2 FAIL_TERMINAL',realSessionReleaseCases=2,protectedFiles=len(protected),protectedMismatches=[],limitations=['No DDL/multiple owners/shared readers/capacity proof','Release timeout is an observation; it does not prove the driver stopped','Fence is local to an Engine/executionId','Default custom CheckpointedNodeSource adapters must supply openBatches for asynchronous resource cleanup'])
(root/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
for n in ['source-manifest.json','run-manifest.json','validation.json']:files[n]=(root/n).read_bytes()
for name,data in files.items():assert settings['CDC_WINDOW_MYSQL_PASSWORD'].encode() not in data,name
inner=json.dumps({'files':{name:sha(data) for name,data in files.items()}},ensure_ascii=False,indent=2).encode()
with tarfile.open(root/'evidence.tar.gz','w:gz') as archive:
 for name,data in list(files.items())+[('manifest.json',inner)]:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
for n in ['verify.py','verify_tests.py']:shutil.copyfile(repo/'docs/experiments/2026-10-19-recovery-windows'/n,root/n)
print(json.dumps({'archiveFiles':len(files)+1,'archiveBytes':(root/'evidence.tar.gz').stat().st_size,'protectedFiles':len(protected),'changedFiles':len(changed)}))
