package cn.xuyinyin.magic.workflow.nodes.base

import cn.xuyinyin.magic.workflow.checkpoint.SourceBatch
import org.apache.pekko.{Done, NotUsed}
import org.apache.pekko.stream.scaladsl.Source
import scala.concurrent.{ExecutionContext, Future, Promise}
import scala.util.{Failure, Success}
import scala.util.control.NonFatal

/** Execution-local resources, deliberately absent from checkpoints and source identities. */
final case class BatchSourceSession(source: Source[SourceBatch, NotUsed], close: () => Future[Done])

final class SourceAcquisitionCleanupFailed(cause: Throwable, cleanup: Throwable)
  extends IllegalStateException("source acquisition failed and resource release is unconfirmed", cause) {
  addSuppressed(cleanup)
}

object BatchSourceSession {
  /** Managed streams defer physical close until the Engine has drained its in-flight batch. */
  def resource[R](create: () => Future[R], read: R => Future[Option[SourceBatch]],
    closeResource: R => Future[Done], managed: Boolean, drainReads: Boolean = false): BatchSourceSession = {
    val scope = new SourceResourceScope
    val readLock = new AnyRef
    var pendingReads = Set.empty[Promise[Done]]
    var stopping = false
    def close(): Future[Done] = {
      val pending = readLock.synchronized { stopping = true; pendingReads.toVector.map(_.future) }
      implicit val ec: ExecutionContext = ExecutionContext.parasitic
      Future.sequence(pending).flatMap(_ => scope.close())
    }
    def readTracked(resource: R): Future[Option[SourceBatch]] = {
      if (!drainReads) return read(resource)
      val finished = Promise[Done]()
      val admitted = readLock.synchronized {
        if (stopping) false else { pendingReads += finished; true }
      }
      if (!admitted) Future.successful(None)
      else {
        val running = try read(resource) catch { case NonFatal(e) => Future.failed(e) }
        running.transform { result =>
          readLock.synchronized { pendingReads -= finished; finished.trySuccess(Done) }
          result
        }(ExecutionContext.parasitic)
      }
    }
    val source = Source.unfoldResourceAsync[SourceBatch, R](
      () => scope.acquire(create, closeResource), readTracked,
      _ => if (managed) Future.successful(Done) else close())
    BatchSourceSession(source, () => close())
  }
}

/** Reserves ownership before asynchronous acquisition; late resources cannot escape close. */
final class SourceResourceScope {
  private var closers = Vector.empty[() => Future[Done]]
  private var closing = false
  private val released = Promise[Done]()

  def acquire[R](create: () => Future[R], closeResource: R => Future[Done]): Future[R] = {
    val opened = Promise[R]()
    synchronized {
      if (closing) return Future.failed(new IllegalStateException("source session is closing"))
      closers :+= (() => opened.future.transformWith {
        case Success(resource) => try closeResource(resource) catch { case NonFatal(e) => Future.failed(e) }
        case Failure(e: SourceAcquisitionCleanupFailed) => Future.failed(e)
        case Failure(_) => Future.successful(Done)
      }(ExecutionContext.parasitic))
    }
    try create().onComplete(opened.tryComplete)(ExecutionContext.parasitic)
    catch { case NonFatal(e) => opened.tryFailure(e) }
    opened.future
  }

  def close(): Future[Done] = {
    val pending = synchronized {
      if (closing) None else { closing = true; Some(closers) }
    }
    pending.foreach { entries =>
      implicit val ec: ExecutionContext = ExecutionContext.parasitic
      // Observe all closes, including when one fails; never short-circuit release accounting.
      Future.sequence(entries.map(f => f().map[Either[Throwable, Done]](Right(_)).recover { case NonFatal(e) => Left(e) }))
        .foreach { outcomes =>
          outcomes.collectFirst { case Left(e) => e } match {
            case Some(error) => released.tryFailure(error)
            case None => released.trySuccess(Done)
          }
        }
    }
    released.future
  }
}
