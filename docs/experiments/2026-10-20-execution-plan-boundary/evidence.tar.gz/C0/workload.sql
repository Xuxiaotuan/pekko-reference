BEGIN;
UPDATE source_rows SET revision=1,label=CONCAT('window-',id),amount=amount+0.0100,note=IF(MOD(id,2)=0,NULL,'窗口-🙂'),updated_at='2026-10-19 12:34:56.123456';
UPDATE source_rows SET label='repeat-a' WHERE id=1;
UPDATE source_rows SET label='repeat-b' WHERE id=1;
UPDATE source_rows SET label='repeat-a' WHERE id=1;
UPDATE source_rows SET label='repeat-b' WHERE id=1;
UPDATE source_rows SET id=150 WHERE id=50;
COMMIT;
