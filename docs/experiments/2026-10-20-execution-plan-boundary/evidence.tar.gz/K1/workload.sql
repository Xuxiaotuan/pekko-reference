BEGIN;
UPDATE source_rows SET id=150,label='pk-window-🙂' WHERE id=50;
COMMIT;
