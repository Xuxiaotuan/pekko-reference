from pathlib import Path
import hashlib,io,json,os,re,subprocess,tarfile,zipfile
repo=Path.cwd();tmp=Path('/tmp/pekko-plan-boundary-20261020')
root=repo/'docs/experiments/2026-10-20-execution-plan-boundary'
root.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((tmp/'real-run.json').read_text());assert run['exitCode']==0
frozen=json.loads((tmp/'run-source-manifest.json').read_text())
assert all(sha((repo/p).read_bytes())==h for p,h in frozen.items())
before=json.loads((tmp/'before-manifest.json').read_text())
protected={p:h for p,h in before.items() if p.startswith('docs/experiments/')}
assert all(sha((repo/p).read_bytes())==h for p,h in protected.items())
changed=[p for p,h in before.items() if p.endswith('.scala') and sha((repo/p).read_bytes())!=h]
assert set(changed)=={'pekko-server/src/main/scala/cn/xuyinyin/magic/workflow/engine/WorkflowExecutionEngine.scala','pekko-server/src/main/scala/cn/xuyinyin/magic/workflow/actors/EventSourcedWorkflowActor.scala'}
files={}
text=(tmp/'real-ten.log').read_text()
windows=dict(re.findall(r'CDC_RECOVERY_WINDOW_OBSERVED scenario=(\w+) evidence=(\S+)',text));assert len(windows)==8
sessions=dict(re.findall(r'CDC_SESSION_RELEASE_OBSERVED fault=([\w-]+) evidence=(\S+)',text));assert set(sessions)=={'none','cancel-T'}
settings=json.loads((tmp/'settings.json').read_text())
records=[]
for case,folder in list(windows.items())+[("sessions/"+k,v) for k,v in sessions.items()]:
    p=Path(folder)
    schema=json.loads((p/('outcome.json' if case.startswith('sessions/') else 'environment.json')).read_text())['schema']
    env=os.environ.copy();env['MYSQL_PWD']=settings['CDC_WINDOW_MYSQL_PASSWORD']
    dump=subprocess.run(['docker','exec','-e','MYSQL_PWD','pekko-cdc-stage-c-20261019','mysqldump','-uroot','--single-transaction','--hex-blob','--set-gtid-purged=OFF','--skip-comments',schema],env=env,capture_output=True)
    assert dump.returncode==0,'dump failed for '+schema
    (p/'database-final.sql').write_bytes(dump.stdout)
    for f in p.iterdir():
        if f.is_file():files[case+'/'+f.name]=f.read_bytes()
    records.append(dict(scenario=case,runDirectory=p.name,schema=schema))
for rel in frozen:files['source/'+rel]=(repo/rel).read_bytes()
for name in ['baseline.log','red-plan.log','green-plan.log','integration-first.log','integration-green.log','red-invocation.log','focused-final.log','full-module-package.log','real-ten.log','real-run.json','run-real.py','collect.py']:
    files['checks/'+name]=(tmp/name).read_bytes()
for name in ['WorkflowExecutionEngine.scala','WorkflowValidator.scala']:files['before/'+name]=(tmp/name).read_bytes()
actor='pekko-server/src/main/scala/cn/xuyinyin/magic/workflow/actors/EventSourcedWorkflowActor.scala'
files['before/EventSourcedWorkflowActor.scala']=subprocess.check_output(['git','show','d046cce2dc850ea60bc3513db84378484b0a1043:'+actor])
files['checks/protected-history.json']=(json.dumps(protected,indent=2)+'\n').encode()
full=(tmp/'full-module-package.log').read_text()
assert 'Tests: succeeded 471, failed 0' in full and 'Suites: completed 77, aborted 0' in full
assert 'Tests: succeeded 56, failed 0' in (tmp/'focused-final.log').read_text()
assert 'Position(1234.0, 5678.0) was not equal to Position(0.0, 0.0)' in (tmp/'red-invocation.log').read_text()
jar=repo/'pekko-server/target/scala-2.13/pekko-reference_2.13-0.1.jar'
assert jar.is_file()
with zipfile.ZipFile(jar) as z:
    names=z.namelist()
    assert any(n.endswith('/WorkflowPlanCompiler.class') for n in names)
    assert any(n.endswith('/MySqlCdcPlan.class') for n in names)
    assert not any('WorkflowPlanCompilerSpec' in n or 'TestNodeRegistry' in n for n in names)
stage=repo/'pekko-server/target/universal/stage'
assert stage.is_dir()
package=dict(productionJar=str(jar.relative_to(repo)),sha256=sha(jar.read_bytes()),distributionJars=len(list((stage/'lib').glob('*.jar'))),planClassesPresent=True,testClassesAbsent=True,runtimeDeployment=False)
meta=json.loads(subprocess.check_output(['docker','inspect','pekko-cdc-stage-c-20261019']))[0]
source=dict(baseCommit='d046cce2dc850ea60bc3513db84378484b0a1043',sourceSha256=frozen,changedBaselineProductionFiles=changed,unchangedBaselineScalaFiles=80,protectedHistoricalFiles=len(protected),scope='DSL to in-memory runtime plan; persisted models and T/J/ACK ordering retained')
runmanifest=dict(date='2026-10-20',java='Microsoft OpenJDK 17.0.14',pekko='1.1.3',debezium='3.6.1.Final',protobuf='4.33.4',container='pekko-cdc-stage-c-20261019',image=meta['Image'],formalRuns=records,executionResult=run,scope='Ten explicitly selected ExternalIntegration cases via Test Classpath; no staged-distribution deployment')
validation=dict(baselineTests=47,focusedTests=56,fullBackend=dict(passed=471,failed=0,suites=77,aborted=0,scope='Default test excludes ExternalIntegration'),realRecoveryWindows=8,converged=7,retainedFailure='C2 FAIL_TERMINAL',releaseCases=2,historicalFilesUnchanged=len(protected),package=package,ui='unchanged; not rerun',review='Independent read-only review reported no actionable findings; no independent test rerun')
for name,value in [('source-manifest.json',source),('run-manifest.json',runmanifest),('validation.json',validation)]:
    data=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode();(root/name).write_bytes(data);files[name]=data
for name,data in files.items():assert settings['CDC_WINDOW_MYSQL_PASSWORD'].encode() not in data,name
manifest=json.dumps(dict(files={n:sha(d) for n,d in files.items()}),indent=2).encode()
with tarfile.open(root/'evidence.tar.gz','w:gz') as a:
    for name,data in list(files.items())+[('manifest.json',manifest)]:
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;a.addfile(info,io.BytesIO(data))
for name in ('verify.py','verify_sessions.py'):
    (root/name).write_bytes((repo/'docs/experiments/2026-10-20-hot-path-query'/name).read_bytes())
print(json.dumps(dict(archiveMembers=len(files)+1,archiveBytes=(root/'evidence.tar.gz').stat().st_size,protectedFiles=len(protected),frozenSourceFiles=len(frozen),package=package),indent=2))
