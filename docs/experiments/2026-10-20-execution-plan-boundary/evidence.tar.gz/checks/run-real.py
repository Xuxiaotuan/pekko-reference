from pathlib import Path
import json,subprocess,os,time,hashlib
repo=Path.cwd();tmp=Path('/tmp/pekko-plan-boundary-20261020')
s=json.loads(Path('/tmp/pekko-stage-c-20261019/settings.json').read_text())
name='pekko-cdc-stage-c-20261019'
meta=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
assert meta['Name']=='/'+name and meta['Config']['Image']=='mysql:8.4'
subprocess.run(['docker','start',name],check=True,stdout=subprocess.DEVNULL)
meta=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
ports=meta['NetworkSettings']['Ports']['3306/tcp'];assert len(ports)==1 and ports[0]['HostIp']=='127.0.0.1'
s['CDC_WINDOW_MYSQL_HOST']='127.0.0.1';s['CDC_WINDOW_MYSQL_PORT']=ports[0]['HostPort']
f=tmp/'settings.json';f.write_text(json.dumps(s));f.chmod(0o600)
env=os.environ.copy();env.update(s);env['MYSQL_PWD']=s['CDC_WINDOW_MYSQL_PASSWORD'];env['RUN_MYSQL_CDC_RECOVERY_WINDOWS']='1'
for _ in range(45):
 r=subprocess.run(['docker','exec','-e','MYSQL_PWD',name,'mysqladmin','-uroot','ping'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 if r.returncode==0:break
 time.sleep(1)
else:raise RuntimeError('isolated MySQL not ready')
manifest={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'pekko-server/src').rglob('*') if p.is_file()}
manifest['build.sbt']=hashlib.sha256((repo/'build.sbt').read_bytes()).hexdigest()
(tmp/'run-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
cp=(repo/'pekko-server/target/streams/test/fullClasspath/_global/streams/export').read_text().strip()
assert 'protobuf-java-4.33.4.jar' in cp and 'protobuf-java-4.26.1.jar' not in cp
cmd=['/Users/xujiawei/Library/Java/JavaVirtualMachines/ms-17.0.14/Contents/Home/bin/java','-Duser.timezone=UTC','-Xmx1G','-cp',cp,'org.scalatest.tools.Runner','-o','-s','cn.xuyinyin.magic.workflow.integration.RealMySQLCdcSessionReleaseSpec','-s','cn.xuyinyin.magic.workflow.integration.RealMySQLCdcRecoveryWindowsSpec']
started=time.time()
with (tmp/'real-ten.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(tmp/'real-run.json').write_text(json.dumps(dict(exitCode=r.returncode,seconds=time.time()-started,container=name,loopbackPort=ports[0]['HostPort'],protobuf='4.33.4'),indent=2)+'\n')
print('Real MySQL runner exit:',r.returncode);raise SystemExit(r.returncode)
