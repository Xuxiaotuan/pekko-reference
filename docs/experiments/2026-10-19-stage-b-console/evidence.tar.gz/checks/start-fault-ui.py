from pathlib import Path
import socket,os,subprocess,json
root=Path('/tmp/pekko-stage-b-20261019');repo=Path.cwd();live=json.load(open(root/'live.json'))
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
proxy,ui=port(),port();(root/'controls.json').write_text('{}')
env=os.environ.copy();env.update(TEST_BACKEND_URL=live['backendUrl'],TEST_CONTROL_FILE=str(root/'controls.json'),TEST_PROXY_LOG=str(root/'fault-proxy.jsonl'),TEST_PROXY_PORT=str(proxy))
p=subprocess.Popen(['node','xxt-ui/tests/live-proxy.cjs'],env=env,stdout=(root/'fault-proxy.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
env['PEKKO_API_TARGET']=f'http://127.0.0.1:{proxy}'
f=subprocess.Popen(['npm','run','dev','--','--host','127.0.0.1','--port',str(ui),'--strictPort'],cwd=repo/'xxt-ui',env=env,stdout=(root/'fault-ui.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
state=dict(proxyPid=p.pid,frontendPid=f.pid,proxyUrl=f'http://127.0.0.1:{proxy}',uiUrl=f'http://127.0.0.1:{ui}')
(root/'fault-live.json').write_text(json.dumps(state,indent=2));print(json.dumps(state))
