from pathlib import Path
import json,urllib.request,urllib.error,time
root=Path('/tmp/pekko-stage-b-20261019');base=json.load(open(root/'live.json'))['backendUrl'];records=[]
def request(method,path,data=None):
 req=urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'},method=method)
 try:
  with urllib.request.urlopen(req,timeout=10) as r:code,body=r.status,r.read().decode()
 except urllib.error.HTTPError as e:code,body=e.code,e.read().decode()
 try:body=json.loads(body)
 except ValueError:pass
 records.append(dict(method=method,path=path,request=data,status=code,response=body));return code,body
def workflow(id):
 return dict(id=id,name=id,description='B-stage loopback integration',version='1',author='integration',tags=[],nodes=[dict(id='s',type='source',nodeType='sequence.numbers',label='source',position=dict(x=0,y=0),config=dict(start=1,end=3)),dict(id='t',type='sink',nodeType='console.log',label='sink',position=dict(x=100,y=0),config={})],edges=[dict(id='e',source='s',target='t')],metadata=dict(createdAt='2026-10-19',updatedAt='2026-10-19'))
for i in range(1,5):assert request('POST','/api/v1/workflows',workflow(f'stage-b-0{i}'))[0]==201
(root/'ui-definition.json').write_text(json.dumps(workflow('stage-b-ui'),ensure_ascii=False,indent=2))
invalid=workflow('stage-b-invalid');invalid['nodes']=[];invalid['edges']=[]
assert request('POST','/api/v1/workflows',invalid)[0]==400
assert request('POST','/api/v1/workflows',workflow('stage-b-01'))[0]==409
assert request('GET','/api/v1/workflows/missing-stage-b')[0]==404
assert request('POST','/api/v1/workflows/stage-b-01/execute?requestId=stable-probe')[0]==202
assert request('POST','/api/v1/workflows/stage-b-01/execute?requestId=stable-probe')[0]==409
assert request('POST','/api/v1/schedules',dict(id='stage-b-hourly',workflowId='stage-b-01',scheduleType='fixed_rate',interval='1h'))[0]==201
for route in ['/api/v1/workflows?page=0&pageSize=2','/api/v1/workflows?page=1&pageSize=2','/api/v1/workflows?page=2&pageSize=2','/api/v1/workflows?page=-1&pageSize=0','/api/v1/workflows?page=no','/api/v1/workflows/stage-b-01','/api/history/stage-b-01','/api/v1/schedules','/api/v1/cluster/stats','/api/v1/cluster/shards','/api/v1/cluster/workflow/stage-b-01/location','/monitoring/metrics']:
 request('GET',route)
(root/'live-api-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print([(r['path'],r['status']) for r in records])
