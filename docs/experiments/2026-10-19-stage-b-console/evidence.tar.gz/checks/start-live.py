from pathlib import Path
import socket,os,subprocess,json,time,urllib.request
root=Path('/tmp/pekko-stage-b-20261019');repo=Path.cwd()
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
remote,http,ui=port(),port(),port()
config=root/'application-live.conf'
config.write_text('include "application.conf"\n'+f'''pekko.remote.artery.canonical.port = {remote}
pekko.cluster.seed-nodes = ["pekko://pekko-cluster-system@127.0.0.1:{remote}"]
http.host = "127.0.0.1"
http.port = {http}
pekko-persistence-jdbc.shared-databases.slick.db.url = "jdbc:h2:file:{root}/live-journal;MODE=MySQL;INIT=RUNSCRIPT FROM 'classpath:db/h2/pekko-persistence-schema.sql'"
''')
env=os.environ.copy();env['JAVA_HOME']='/Users/xujiawei/Library/Java/JavaVirtualMachines/ms-17.0.14/Contents/Home'
backend=subprocess.Popen([str(repo/'pekko-server/target/universal/stage/bin/pekko-reference'),f'-Dconfig.file={config}'],env=env,stdout=(root/'backend-live.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
for _ in range(60):
 try:
  with urllib.request.urlopen(f'http://127.0.0.1:{http}/health/ready',timeout=2) as r:
   if r.status==200:break
 except Exception:pass
 if backend.poll() is not None:raise SystemExit('backend exited')
 time.sleep(.5)
else:raise SystemExit('backend not ready')
env['PEKKO_API_TARGET']=f'http://127.0.0.1:{http}'
frontend=subprocess.Popen(['npm','run','dev','--','--host','127.0.0.1','--port',str(ui),'--strictPort'],cwd=repo/'xxt-ui',env=env,stdout=(root/'frontend-live.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
state=dict(backendPid=backend.pid,frontendPid=frontend.pid,backendUrl=f'http://127.0.0.1:{http}',uiUrl=f'http://127.0.0.1:{ui}',remotePort=remote)
(root/'live.json').write_text(json.dumps(state,indent=2));print(json.dumps(state))
