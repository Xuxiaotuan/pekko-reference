from pathlib import Path
import json,hashlib,tarfile,io,subprocess,shutil
repo=Path.cwd();tmp=Path('/tmp/pekko-stage-b-20261019');root=repo/'docs/experiments/2026-10-19-stage-b-console';root.mkdir(exist_ok=True)
hashof=lambda data:hashlib.sha256(data).hexdigest()
files={}
for f in tmp.iterdir():
 if f.suffix in ('.json','.jsonl','.log','.py','.conf','.png','.db') and f.name!='controls.json':files['checks/'+f.name]=f.read_bytes()
paths=list((repo/'xxt-ui/src').rglob('*'))+list((repo/'xxt-ui/tests').rglob('*'))+list((repo/'xxt-ui/examples/legacy').rglob('*'))
paths+=[repo/p for p in ['xxt-ui/package.json','xxt-ui/vite.config.ts','xxt-ui/index.html','README.md','xxt-ui/README.md','docs/MIGRATION_GUIDE.md','pekko-server/src/main/scala/cn/xuyinyin/magic/api/http/routes/ClusterRoutes.scala','pekko-server/src/main/scala/cn/xuyinyin/magic/api/http/routes/HttpRoutes.scala','pekko-server/src/test/scala/cn/xuyinyin/magic/api/http/routes/CapabilityRoutesSpec.scala']]
hashes={}
for p in paths:
 if p.is_file():
  rel=str(p.relative_to(repo));data=p.read_bytes();files['source/'+rel]=data;hashes[rel]=hashof(data)
source=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),workingTree='Stage A and earlier recovery experiments preserved; B frontend and two HTTP route edits uncommitted',productionRecoveryProtocolUnchanged=True,sourceSha256=hashes)
(root/'source-manifest.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
shutil.copyfile(tmp/'preservation.json',root/'preservation.json');shutil.copyfile(tmp/'historical-checksums.json',root/'historical-checksums.json');shutil.copyfile(tmp/'console.png',root/'console.png')
summary=dict(scope='Real local staged Pekko backend with file-H2 JDBC Journal + Vite + browser; HTTP fault proxy forwards to the same backend. This is NOT a new real-MySQL CDC recovery run.',frontendContractTestsPassed=5,backendFocusedTestsPassed=11,fullModule=dict(passed=422,completedSuites=67,abortedSuites=['MysqlSqlParserSpec','ComprehensiveCalciteTest'],exitCode=1),frontendProductionBuild='PASS with existing Vite CJS and chunk size warnings',backendPackageAndStage='PASS',browserSnapshots=len(json.load(open(tmp/'browser-checks.json'))),snapshotNote='Includes before-fix observations; not a count of independent passing automated tests',protectedFilesUnchanged=258,historicalChecksumManifestsPassed=7,observedFailuresResolved=['pending requestId lost when button unmounted','legal workflow id new collided with import route'],notValidated=['New MySQL Source/Journal/Sink recovery run','DDL, multiple owners, shared readers','70w workflow directory performance, stable snapshot pagination','Production availability or deployment'],knownBoundaries=['C2 remains historical FAIL_TERMINAL; no protocol change','Current list still enumerates Journal IDs and asks actors','Recent history is bounded to 50 entries, not full audit','Schedule API does not enforce workflow type; UI manages existing schedules only','Pending request IDs are per browser tab/session; not shared across tabs/users and not durable after closing the tab'])
(root/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
for name in ('source-manifest.json','preservation.json','historical-checksums.json','result.json'):files[name]=(root/name).read_bytes()
manifest=json.dumps({'files':{n:hashof(d) for n,d in files.items()}},ensure_ascii=False,indent=2).encode()
with tarfile.open(root/'evidence.tar.gz','w:gz') as a:
 for n,d in list(files.items())+[('manifest.json',manifest)]:
  info=tarfile.TarInfo(n);info.size=len(d);info.mode=0o644;a.addfile(info,io.BytesIO(d))
print('Archive members',len(files)+1,'bytes',(root/'evidence.tar.gz').stat().st_size)
