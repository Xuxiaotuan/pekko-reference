-- MySQL dump 10.13  Distrib 8.4.11, for Linux (aarch64)
--
-- Host: localhost    Database: pekko_test_cdc_window_115be95a3f55
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_journal`
--

DROP TABLE IF EXISTS `event_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_journal` (
  `ordering` bigint unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `writer` text COLLATE utf8mb4_bin NOT NULL,
  `write_timestamp` bigint NOT NULL,
  `adapter_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `event_payload` blob NOT NULL,
  `event_ser_id` int NOT NULL,
  `event_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `meta_payload` blob,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`persistence_id`,`sequence_number`),
  UNIQUE KEY `ordering` (`ordering`),
  UNIQUE KEY `event_journal_ordering_idx` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_journal`
--

LOCK TABLES `event_journal` WRITE;
/*!40000 ALTER TABLE `event_journal` DISABLE KEYS */;
INSERT INTO `event_journal` VALUES (1,0,'workflow-snapshot-115be95a3f55',1,'32e5a461-5c57-4a54-9763-ba68f51a185e',1792591682016,'',0xBF6C776F726B666C6F774A736F6E7904417B22617574686F72223A2274657374222C226465736372697074696F6E223A22736E617073686F742073706C6974207265636F766572792066697874757265222C226564676573223A5B7B22616E696D61746564223A66616C73652C226964223A2265646765222C22736F75726365223A22736F75726365222C22736F7572636548616E646C65223A226F7574222C22746172676574223A2273696E6B222C2274617267657448616E646C65223A22696E227D5D2C226964223A22736E617073686F742D313135626539356133663535222C226D65746164617461223A7B22637265617465644174223A226E6F77222C22757064617465644174223A226E6F77227D2C226E616D65223A22736E617073686F742D313135626539356133663535222C226E6F646573223A5B7B22636F6E666967223A7B226368756E6B53697A65223A332C22636F6C756D6E73223A5B226964222C226C6162656C222C22616D6F756E74222C226E6F7465222C22757064617465645F6174222C227265766973696F6E225D2C226461746162617365223A2270656B6B6F5F746573745F6364635F77696E646F775F313135626539356133663535222C22686F7374223A223132372E302E302E31222C226D6178506167654279746573223A343039362C2270617373776F7264456E76223A224344435F57494E444F575F4D5953514C5F50415353574F5244222C22706F7274223A33323830352C227072696D6172794B6579223A226964222C22736E617073686F74436F6E73697374656E6379223A22717569657363656E74222C2273706C6974506172616C6C656C69736D223A322C2273706C6974526F7773223A382C227461626C65223A22736F757263655F726F7773222C22757365726E616D65223A22726F6F74227D2C226964223A22736F75726365222C226C6162656C223A22736F75726365222C226E6F646554797065223A226D7973716C2E736E617073686F74222C22706F736974696F6E223A7B2278223A302E302C2279223A302E307D2C2274797065223A22736F75726365227D2C7B22636F6E666967223A7B22626174636853697A65223A332C226461746162617365223A2270656B6B6F5F746573745F6364635F77696E646F775F313135626539356133663535222C22686F7374223A223132372E302E302E31222C226D6F6465223A22696E73657274222C2270617373776F7264456E76223A224344435F57494E444F575F4D5953514C5F50415353574F5244222C22706F7274223A33323830352C227461626C65223A227461726765745F726F7773222C22757365726E616D65223A22726F6F74227D2C226964223A2273696E6B222C226C6162656C223A2273696E6B222C226E6F646554797065223A226D7973716C2E7772697465222C22706F736974696F6E223A7B2278223A302E302C2279223A302E307D2C2274797065223A2273696E6B227D5D2C2274616773223A5B5D2C2276657273696F6E223A2231227D687265766973696F6E016974696D657374616D701B000001A15ECA59D8FF,33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$WorkflowDefined',NULL,NULL,NULL),(2,0,'workflow-snapshot-115be95a3f55',2,'32e5a461-5c57-4a54-9763-ba68f51a185e',1792591682190,'',0xBF6B657865637574696F6E4964782466306361386437642D343634652D343661622D396131352D3765393663333765383562396774726967676572BF646B696E64666D616E75616C6972657175657374496470736E617073686F742D696E697469616C6A7363686564756C654964F66B7363686564756C656441742069747269676765724964F6FF70776F726B666C6F775265766973696F6E016974696D657374616D701B000001A15ECA5A89FF,33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ResumableExecutionStarted',NULL,NULL,NULL),(3,0,'workflow-snapshot-115be95a3f55',3,'32e5a461-5c57-4a54-9763-ba68f51a185e',1792591682418,'',0xBF6B657865637574696F6E4964782466306361386437642D343634652D343661622D396131352D37653936633337653835623966757064617465BF655F74797065783C636E2E787579696E79696E2E6D616769632E776F726B666C6F772E736E617073686F742E496E697469616C697A65536E617073686F7453706C69747364706C616EBF6269647840353361646636383464343936663931353062353733383762303264316265376464333132643137366263386330393135393438653461653933613562363563336C736F757263654E6F6465496466736F757263656B66696E6765727072696E74784037623330346466653337656165666138353264363531353366303835326463613736333332396632376164646636323835636461613662663839303535333331657570706572F66870616765526F7773036973706C6974526F7773086B706172616C6C656C69736D026C6D6178506167654279746573191000FFFF6974696D657374616D701B000001A15ECA5B6FFF,33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(4,0,'workflow-snapshot-115be95a3f55',4,'32e5a461-5c57-4a54-9763-ba68f51a185e',1792591682497,'',0xBF6B657865637574696F6E4964782466306361386437642D343634652D343661622D396131352D37653936633337653835623966757064617465BF655F74797065783E636E2E787579696E79696E2E6D616769632E776F726B666C6F772E736E617073686F742E46696E697368536E617073686F74456E756D65726174696F6E24FF6974696D657374616D701B000001A15ECA5BC1FF,33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$SnapshotSplitsUpdated',NULL,NULL,NULL),(5,0,'workflow-snapshot-115be95a3f55',5,'32e5a461-5c57-4a54-9763-ba68f51a185e',1792591682535,'',0xBF6B657865637574696F6E4964782466306361386437642D343634652D343661622D396131352D37653936633337653835623966726573756C74BF6673746174757369636F6D706C657465646773756363657373F5676D6573736167657827576F726B666C6F77206578656375746564207375636365737366756C6C7920696E203236326D736D726F777350726F6365737365640070686173526F777350726F636573736564F5686475726174696F6E1901066B6861734475726174696F6EF56B6E6F6465526573756C74739FBF666E6F6465496466736F75726365686E6F6465547970656E6D7973716C2E736E617073686F746673746174757369636F6D706C65746564676D657373616765606A6861734D657373616765F4686475726174696F6E1901066B6861734475726174696F6EF5FFBF666E6F646549646473696E6B686E6F6465547970656B6D7973716C2E77726974656673746174757369636F6D706C65746564676D657373616765606A6861734D657373616765F4686475726174696F6E1901066B6861734475726174696F6EF5FFFFFF6974696D657374616D701B000001A15ECA5BE6FF,33,'cn.xuyinyin.magic.workflow.events.WorkflowEvents$ExecutionCompleted',NULL,NULL,NULL);
/*!40000 ALTER TABLE `event_journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_tag`
--

DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `event_id` bigint unsigned NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`event_id`,`tag`),
  CONSTRAINT `event_tag_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_journal` (`ordering`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_tag`
--

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pekko_snapshot_batch_evidence`
--

DROP TABLE IF EXISTS `pekko_snapshot_batch_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_snapshot_batch_evidence` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `source_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `target_sha256` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pekko_snapshot_batch_evidence`
--

LOCK TABLES `pekko_snapshot_batch_evidence` WRITE;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_snapshot_batch_evidence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pekko_sync_batch_ledger`
--

DROP TABLE IF EXISTS `pekko_sync_batch_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pekko_sync_batch_ledger` (
  `batch_id` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `execution_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `source_node_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `partition_id` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `batch_sequence` bigint NOT NULL,
  `cursor_kind` varchar(64) COLLATE utf8mb4_bin NOT NULL DEFAULT 'mysql.numeric-pk',
  `cursor_value` longtext COLLATE utf8mb4_bin NOT NULL,
  `upper_bound` longtext COLLATE utf8mb4_bin NOT NULL,
  `source_rows` bigint NOT NULL,
  `target_rows` bigint NOT NULL,
  `committed_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_execution_partition_sequence` (`execution_id`,`source_node_id`,`partition_id`,`batch_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pekko_sync_batch_ledger`
--

LOCK TABLES `pekko_sync_batch_ledger` WRITE;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `pekko_sync_batch_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot`
--

DROP TABLE IF EXISTS `snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snapshot` (
  `persistence_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `sequence_number` bigint NOT NULL,
  `created` bigint NOT NULL,
  `snapshot_ser_id` int NOT NULL,
  `snapshot_ser_manifest` text COLLATE utf8mb4_bin NOT NULL,
  `snapshot_payload` blob NOT NULL,
  `meta_ser_id` int DEFAULT NULL,
  `meta_ser_manifest` text COLLATE utf8mb4_bin,
  `meta_payload` blob,
  PRIMARY KEY (`persistence_id`,`sequence_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot`
--

LOCK TABLES `snapshot` WRITE;
/*!40000 ALTER TABLE `snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `source_rows`
--

DROP TABLE IF EXISTS `source_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `source_rows`
--

LOCK TABLES `source_rows` WRITE;
/*!40000 ALTER TABLE `source_rows` DISABLE KEYS */;
/*!40000 ALTER TABLE `source_rows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_audit`
--

DROP TABLE IF EXISTS `target_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `op` varchar(1) COLLATE utf8mb4_bin DEFAULT NULL,
  `row_id` bigint DEFAULT NULL,
  `old_revision` int DEFAULT NULL,
  `new_revision` int DEFAULT NULL,
  `old_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `new_label` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`audit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_audit`
--

LOCK TABLES `target_audit` WRITE;
/*!40000 ALTER TABLE `target_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_rows`
--

DROP TABLE IF EXISTS `target_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_rows` (
  `id` bigint NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `amount` decimal(18,4) NOT NULL,
  `note` varchar(240) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `revision` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_rows`
--

LOCK TABLES `target_rows` WRITE;
/*!40000 ALTER TABLE `target_rows` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_rows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_insert` AFTER INSERT ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,new_revision,new_label) VALUES ('I',NEW.id,NEW.revision,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_update` AFTER UPDATE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,new_revision,old_label,new_label) VALUES ('U',NEW.id,OLD.revision,NEW.revision,OLD.label,NEW.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `audit_delete` AFTER DELETE ON `target_rows` FOR EACH ROW INSERT INTO target_audit (op,row_id,old_revision,old_label) VALUES ('D',OLD.id,OLD.revision,OLD.label) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Dumping routines for database 'pekko_test_cdc_window_115be95a3f55'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-21 14:28:56
