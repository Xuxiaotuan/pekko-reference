from pathlib import Path
p=Path('server/src/test/scala/cn/xuyinyin/magic/workflow/integration/RealMySQLSnapshotSplitProcess.scala');s=p.read_text().replace('Set("T_J", "CHANGED", "COMMIT_LOST", "COMMIT_ABSENT", "RETRY_EXHAUSTED")','Set("T_J", "STOP_T", "CHANGED", "COMMIT_LOST", "COMMIT_ABSENT", "RETRY_EXHAUSTED")').replace('Set("T_J", "CHANGED").contains(fault)', 'Set("T_J", "STOP_T", "CHANGED").contains(fault)')
s=s.replace('fault == "EOF" && id.endsWith(":0")','Set("EOF", "EOF_J_LOST").contains(fault) && id.endsWith(":0")')
s=s.replace('      case "STOP" => actor ! EventSourcedWorkflowActor.Stop','''      case "STOP" => actor ! EventSourcedWorkflowActor.Stop
      case "WAIT_STOP" =>
        kit.createTestProbe[Any]().expectTerminated(actor, 30.seconds)
        emit("OWNER_STOPPED", "allSourcePoolsClosed" -> JsBoolean(pools.iterator().asScala.forall(_.isClosed)))''')
p.write_text(s)
p=Path('server/src/test/scala/cn/xuyinyin/magic/workflow/integration/RealMySQLSnapshotSplitSpec.scala');s=p.read_text().replace('"J_LOST", "COMMIT_LOST"','"EOF_J_LOST", "STOP_T", "J_LOST", "COMMIT_LOST"')
s=s.replace('Set("J_LOST", "COMMIT_LOST", "COMMIT_ABSENT")','Set("EOF_J_LOST", "STOP_T", "J_LOST", "COMMIT_LOST", "COMMIT_ABSENT")')
s=s.replace('''            } else original.send(if (scenario == "J_LOST") "DROP_J" else "DROP_RESPONSE")''','''            } else if (scenario == "STOP_T") {
              original.send("STOP"); original.send("RELEASE"); original.send("WAIT_STOP")
              original.awaitEvent("OWNER_STOPPED").fields("allSourcePoolsClosed") shouldBe JsBoolean(true)
              original.kill()
              recovered = start("recover", "recovered"); recovered.awaitEvent("PROCESS_READY")
            } else original.send(if (Set("J_LOST", "EOF_J_LOST").contains(scenario)) "DROP_J" else "DROP_RESPONSE")''')
p.write_text(s)
p=Path('server/src/test/scala/cn/xuyinyin/magic/connectors/mysql/sink/MySQLSinkNodeSpec.scala');s=p.read_text().replace('  "MySQLSinkNode" should {','''  "MySQLSinkNode" should {
    "report unconfirmed split target release instead of allowing a retry" in {
      withFixture { fixture =>
        fixture.initializeLedger(); fixture.initializeSplitEvidence(); fixture.failSplitClose = true
        val batch = sourceBatch(0L, "1", Vector(row(1))).copy(partitionId = "plan:0",
          cursor = SourceCursor(cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.CursorKind, "1", "10"))
        val failed = intercept[cn.xuyinyin.magic.workflow.engine.CdcExecutionException] {
          Await.result(fixture.node.commitBatch(sinkNode(100), "w", "e", batch, batch.rows, _ => ()), 5.seconds)
        }
        failed.failure.releaseConfirmed shouldBe false
        fixture.selectCount("sink_rows") shouldBe 1
      }
    }
''')
s=s.replace('  private final class H2Fixture(failInnerSink: Boolean, claimHook: String => Unit) {','  private final class H2Fixture(failInnerSink: Boolean, claimHook: String => Unit) {\n    var failSplitClose = false')
needle='''        val dataSource = new HikariDataSource(config)
        dataSources :+= dataSource'''
s=s.replace(needle,'''        val dataSource = new HikariDataSource(config) {
          override def close(): Unit = { super.close(); if (failSplitClose) throw new IllegalStateException("injected target close observation failure") }
        }
        dataSources :+= dataSource''')
p.write_text(s)
