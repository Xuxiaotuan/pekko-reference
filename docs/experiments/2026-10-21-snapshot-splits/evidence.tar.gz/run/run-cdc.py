from pathlib import Path
import os,json,subprocess,time,sys
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference');tmp=Path('/tmp/pekko-snapshot-splits-20261021')
env=os.environ.copy();env.update(json.loads(tmp.joinpath('settings.json').read_text()));env['RUN_MYSQL_CDC_RECOVERY_WINDOWS']='1'
cp=(repo/'server/target/streams/test/fullClasspath/_global/streams/export').read_text().strip()
assert 'protobuf-java-4.33.4.jar' in cp
cmd=['/Users/xujiawei/Library/Java/JavaVirtualMachines/ms-17.0.14/Contents/Home/bin/java','-Duser.timezone=UTC','-Xmx1G','-cp',cp,'org.scalatest.tools.Runner','-o']
for suite in ['RealMySQLCdcAutomaticRecoverySpec','RealMySQLCdcRecoveryWindowsSpec','RealMySQLCdcSessionReleaseSpec']:cmd+=['-s','cn.xuyinyin.magic.workflow.integration.'+suite]
start=time.time()
with tmp.joinpath('cdc-regression.log').open('w') as log:r=subprocess.run(cmd,env=env,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
tmp.joinpath('cdc-regression.json').write_text(json.dumps(dict(exitCode=r.returncode,seconds=time.time()-start),indent=2));print('CDC regression exit:',r.returncode);sys.exit(r.returncode)
