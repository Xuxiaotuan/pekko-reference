from pathlib import Path
p=Path('server/src/main/scala/cn/xuyinyin/magic/connectors/mysql/sink/MySQLSinkNode.scala');s=p.read_text().replace('with CheckpointedNodeSink {','with CheckpointedNodeSink with cn.xuyinyin.magic.workflow.spi.SnapshotSplitSink {')
pos=s.index('  override def commitBatch(')
s=s[:pos]+'''  override def validateSnapshotReady(node: WorkflowDSL.Node)(implicit ec: ExecutionContext): Future[Done] = Future {
    val config = MySQLSinkConfig.parse(node, getenv)
    val ds = createSplitDataSource(config.host, config.port, config.database, config.username, config.password)
    try {
      val c = ds.getConnection
      try {
        val statement = c.prepareStatement("SELECT batch_id, source_sha256, target_sha256 FROM pekko_snapshot_batch_evidence WHERE 1=0")
        try { val rows = statement.executeQuery(); rows.close(); Done } finally statement.close()
      } finally c.close()
    } finally ds.close()
  }(ec)

  /** Split workers have no per-table idle connections; one physical target connection per active commit. */
  protected[sink] def createSplitDataSource(host: String, port: Int, database: String, username: String, password: String): HikariDataSource = {
    val config = new HikariConfig()
    config.setJdbcUrl(s"jdbc:mysql://$host:$port/$database?rewriteBatchedStatements=true&useSSL=false&allowPublicKeyRetrieval=true&connectionTimeZone=UTC&forceConnectionTimeZoneToSession=true&socketTimeout=10000&connectTimeout=5000")
    config.setUsername(username); config.setPassword(password); config.setDriverClassName("com.mysql.cj.jdbc.Driver")
    config.setMaximumPoolSize(1); config.setMinimumIdle(0); config.setConnectionTimeout(10000)
    new HikariDataSource(config)
  }

'''+s[pos:]
# Only commitBatch receives the new factory; all legacy code paths retain their original factory.
start=s.index('  override def commitBatch(');end=s.index('  protected[sink] def beforeLedgerClaim',start)
block=s[start:end].replace('val dataSource = createDataSource(config.host, config.port, config.database, config.username, config.password)', '''val dataSource = if (batch.cursor.kind == cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.CursorKind)
      createSplitDataSource(config.host, config.port, config.database, config.username, config.password)
    else createDataSource(config.host, config.port, config.database, config.username, config.password)''')
s=s[:start]+block+s[end:]
start=s.index('  private def commitCheckpointedBatch(');end=s.index('  private def findLedger(',start);block=s[start:end]
block=block.replace('    var connection: Connection = null','''    val split = batch.cursor.kind == cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.CursorKind
    var commitStarted = false
    var connection: Connection = null
    def evidence(c: Connection, insert: Boolean): Unit = if (split) {
      val sourceHash = cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.rowsDigest(batch.rows)
      val targetHash = cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.rowsDigest(transformedRows)
      val statement = c.prepareStatement(if (insert)
        "INSERT INTO pekko_snapshot_batch_evidence (batch_id,source_sha256,target_sha256) VALUES (?,?,?)"
        else "SELECT source_sha256,target_sha256 FROM pekko_snapshot_batch_evidence WHERE batch_id=?")
      try {
        statement.setString(1, batch.batchId)
        if (insert) { statement.setString(2, sourceHash); statement.setString(3, targetHash); statement.executeUpdate(); () }
        else {
          val rs = statement.executeQuery()
          try {
            if (!rs.next() || rs.getString(1) != sourceHash || rs.getString(2) != targetHash)
              throw new cn.xuyinyin.magic.workflow.engine.CdcExecutionException(
                cn.xuyinyin.magic.workflow.engine.ExecutionFailure("protocol_conflict", "snapshot-evidence", Some(batch.batchId)),
                new IllegalStateException("snapshot batch content conflicts with committed evidence"))
          } finally rs.close()
        }
      } finally statement.close()
    }''')
block=block.replace('if (existing == expected) AlreadyCommitted(existing.checkpoint)','if (existing == expected) { evidence(connection, insert = false); AlreadyCommitted(existing.checkpoint) }')
block=block.replace('              connection.commit()','              evidence(connection, insert = true)\n              commitStarted = true\n              connection.commit()')
block=block.replace('case Some(existing) if existing == expected => AlreadyCommitted(existing.checkpoint)', 'case Some(existing) if existing == expected => evidence(connection, insert = false); AlreadyCommitted(existing.checkpoint)')
block=block.replace('    } catch {\n      case exception: IllegalStateException =>','''    } catch {
      case exception: Exception if split && commitStarted =>
        rollback(connection)
        throw new cn.xuyinyin.magic.workflow.engine.CdcExecutionException(
          cn.xuyinyin.magic.workflow.engine.ExecutionFailure("commit_outcome_unknown", "snapshot-commit", Some(batch.batchId)), exception)
      case exception: IllegalStateException =>''')
s=s[:start]+block+s[end:];p.write_text(s)
p=Path('server/src/main/scala/cn/xuyinyin/magic/workflow/execution/WorkflowExecutionEngine.scala');s=p.read_text().replace('''      return control.continueIfActive().flatMap(_ => sink.validateReady(preparedSink.connectorNode, runtimeOnLog)(jdbcBlockingEc))
        .flatMap(_ => new''','''      val ready = sink match {
        case capable: cn.xuyinyin.magic.workflow.spi.SnapshotSplitSink => capable.validateSnapshotReady(preparedSink.connectorNode)(jdbcBlockingEc)
        case _ => Future.failed(new IllegalStateException("snapshot split sink capability missing"))
      }
      return control.continueIfActive().flatMap(_ => sink.validateReady(preparedSink.connectorNode, runtimeOnLog)(jdbcBlockingEc))
        .flatMap(_ => ready)
        .flatMap(_ => new''');p.write_text(s)
p=Path('server/src/test/scala/cn/xuyinyin/magic/connectors/mysql/sink/MySQLSinkNodeSpec.scala');s=p.read_text();needle='''      override protected[sink] def createInnerSink(
''';idx=s.index(needle,s.index('  private final class H2Fixture'))
s=s[:idx]+'''      override protected[sink] def createSplitDataSource(host: String, port: Int, database: String, username: String, password: String): HikariDataSource =
        createDataSource(host, port, database, username, password)

'''+s[idx:];p.write_text(s)
