from pathlib import Path
import json,collections,hashlib
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference');tmp=Path('/tmp/pekko-snapshot-splits-20261021')
log=max(tmp.glob('real-matrix*.json'),key=lambda p:p.stat().st_mtime)
run=json.loads(log.read_text());end=log.stat().st_mtime;start=end-run['seconds']
folders=sorted([p.parent for p in (repo/'target/snapshot-splits').glob('*/environment.json') if start<=p.stat().st_mtime<=end])
assert len(folders)==20,len(folders)
summary=[]
for folder in folders:
 env=json.loads((folder/'environment.json').read_text());result=json.loads((folder/'result.json').read_text());final=json.loads((folder/'final.json').read_text());comparison=final['comparison']
 events=json.loads((folder/'events.json').read_text());raw=events['original']+events['recovered']
 max_reader=0
 for stream in events.values():
  active=set()
  for e in stream:
   if e['kind']=='READER_OPEN':
    assert e['split'] not in active
    active.add(e['split']);max_reader=max(max_reader,len(active))
   elif e['kind']=='READER_CLOSED':active.discard(e['split'])
 assert max_reader<=2
 states=[e['state'] for e in raw if e['kind']=='J_CONFIRMED']
 max_window=max((len(s['splits']) for s in states),default=0);assert max_window<=16
 blockers={p['blocked'] for s in states for p in s['splits'] if p['blocked']}
 summary.append(dict(scenario=env['scenario'],directory=folder.name,schema=env['schema'],classification=result['classification'],
  sourceRows=comparison['sourceCount'],targetRows=comparison['targetCount'],missing=len(comparison['missingKeys']),extra=len(comparison['extraKeys']),
  fieldDifferences=len(comparison['fieldDifferences']),equal=comparison['equal'],auditRows=len(final['audit']),ledgerRows=len(final['T']),
  maxReaderSessions=max_reader,maxWindow=max_window,maxAttempts=max((p['attempts'] for s in states for p in s['splits']),default=0),
  blockedReasons=sorted(blockers),D='N/A',allSourcePoolsClosed=final['J']['allSourcePoolsClosed']))
assert collections.Counter(v['classification'] for v in summary)=={'converged':14,'safe_pause':6}
manifest=dict(baseCommit='9881fa26a75d625cb96ff44589ba67ea1a939aab',snapshotRun=log.name,exitCode=run['exitCode'],seconds=run['seconds'],
 sourceManifestSha256=hashlib.sha256(tmp.joinpath('source-manifest.json').read_bytes()).hexdigest(),scenarios=summary,
 scope='single-table quiescent snapshot; D is not applicable; no CDC protocol change or cross-table capacity claim')
(tmp/'snapshot-summary.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(tmp/'formal-folders.json').write_text(json.dumps([str(p) for p in folders],indent=2))
for s in summary: print(s['scenario'],s['classification'],str(s['sourceRows'])+'->'+str(s['targetRows']),'fields-diff='+str(s['fieldDifferences']),'attempts='+str(s['maxAttempts']))
