from pathlib import Path
p=Path('server/src/main/scala/cn/xuyinyin/magic/connectors/mysql/source/MySQLSnapshotSourceNode.scala')
s=p.read_text().replace('with CheckpointedNodeSource {','with CheckpointedNodeSource with cn.xuyinyin.magic.workflow.spi.SnapshotSplitSource {')
pos=s.index('  protected[source] def createDataSource(')
s=s[:pos]+'''  override def discoverSplit(node: WorkflowDSL.Node, plan: cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitPlanState,
    lower: Option[String], index: Long)(implicit ec: ExecutionContext): Future[Option[cn.xuyinyin.magic.workflow.snapshot.SnapshotSplit]] = Future {
    val config = MySQLSnapshotSourceConfig.parse(node, getenv)
    plan.upper.flatMap { upper =>
      val ds = createDataSource(config.host, config.port, config.database, config.username, config.password)
      var connection: Connection = null
      try {
        connection = ds.getConnection
        val projection = resolveProjection(connection, config)
        val predicate = lower.fold("")(_ => s"${quote(projection.primaryKey)} > ? AND ")
        val sql = s"SELECT MAX(chunk_key) FROM (SELECT ${quote(projection.primaryKey)} AS chunk_key FROM ${quote(projection.table)} " +
          s"WHERE $predicate${quote(projection.primaryKey)} <= ? ORDER BY ${quote(projection.primaryKey)} LIMIT ?) AS chunk_keys"
        val statement = connection.prepareStatement(sql)
        try {
          var p = 1
          lower.foreach { key => statement.setBigDecimal(p, new java.math.BigDecimal(key)); p += 1 }
          statement.setBigDecimal(p, new java.math.BigDecimal(upper)); statement.setInt(p + 1, plan.splitRows)
          val rs = statement.executeQuery()
          try { rs.next(); Option(rs.getObject(1)).map(v => cn.xuyinyin.magic.workflow.snapshot.SnapshotSplit(
            s"${plan.id}:$index", index, lower, canonicalDecimal(v))) } finally rs.close()
        } finally statement.close()
      } finally { close(connection); close(ds) }
    }
  }

  override def openSplit(node: WorkflowDSL.Node, executionId: String, plan: cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitPlanState,
    split: cn.xuyinyin.magic.workflow.snapshot.SnapshotSplit, checkpoint: Option[BatchCheckpoint], onLog: String => Unit,
    closeEc: ExecutionContext)(implicit ec: ExecutionContext): BatchSourceSession = {
    require(plan.sourceNodeId == node.id && split.id == s"${plan.id}:${split.index}", "snapshot split identity mismatch")
    checkpoint.foreach { c => require(c.partitionId == split.id && c.sourceNodeId == node.id &&
      c.cursor.upperBound == split.upper && c.cursor.kind == cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.CursorKind,
      "snapshot split checkpoint mismatch") }
    val config = MySQLSnapshotSourceConfig.parse(node, getenv).copy(chunkSize = plan.pageRows)
    BatchSourceSession.resource[BatchReader](
      () => Future {
        val reader = openBatchReader(config, split.upper, checkpoint.map(_.cursor.value).orElse(split.lower),
          checkpoint.fold(0L)(_.batchSequence + 1L))
        reader.partition = split.id
        reader.cursorKind = cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.CursorKind
        reader.maxPageBytes = plan.maxPageBytes
        reader
      }(ec),
      r => Future(r.nextBatch(node.id, executionId))(ec),
      r => Future { r.close(); Done }(closeEc), managed = false, drainReads = true)
  }

'''+s[pos:]
s=s.replace('    private var cursor = initialCursor','''    var partition: String = PartitionId
    var cursorKind: String = "mysql.numeric-pk"
    var maxPageBytes: Int = Int.MaxValue
    private var cursor = initialCursor''')
s=s.replace('          var lastCursor: Option[String] = None\n','          var lastCursor: Option[String] = None\n          var encodedBytes = 0L\n')
s=s.replace('            rows += rowAsJson(resultSet)','''            val row = rowAsJson(resultSet)
            encodedBytes += row.getBytes(java.nio.charset.StandardCharsets.UTF_8).length
            require(encodedBytes <= maxPageBytes, "snapshot page exceeds maxPageBytes; pagination must not change within an execution")
            rows += row''')
s=s.replace('partitionId = PartitionId,\n              batchSequence', 'partitionId = partition,\n              batchSequence').replace('BatchId.sha256(executionId, sourceNodeId, PartitionId, sequence)','BatchId.sha256(executionId, sourceNodeId, partition, sequence)').replace('SourceCursor("mysql.numeric-pk", nextCursor, upperBound)','SourceCursor(cursorKind, nextCursor, upperBound)')
p.write_text(s)
