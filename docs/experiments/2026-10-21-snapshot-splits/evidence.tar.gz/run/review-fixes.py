from pathlib import Path
root=Path('server/src/main/scala/cn/xuyinyin/magic')
p=root/'workflow/snapshot/SnapshotSplitExecutor.scala';s=p.read_text()
s=s.replace('onLog: String => Unit, blockingEc: ExecutionContext, closeEc: ExecutionContext)', 'onLog: String => Unit, blockingEc: ExecutionContext, closeEc: ExecutionContext,\n  cancelled: () => Boolean = () => false, releaseUnconfirmed: Throwable => Unit = _ => ())')
s=s.replace('  private def positive(','''  private val unsafeRelease = new java.util.concurrent.atomic.AtomicBoolean(false)
  private def active(): Future[Done] =
    if (unsafeRelease.get()) Future.failed(new CdcExecutionException(
      ExecutionFailure(ExecutionFailure.ReleaseUnknown, "snapshot-admission", releaseConfirmed = false),
      new IllegalStateException("new snapshot work blocked by unconfirmed release")))
    else ensureActive()

  private def positive(''')
s=s.replace('<- ensureActive()', '<- active()').replace('= ensureActive().flatMap', '= active().flatMap').replace('else ensureActive().flatMap', 'else active().flatMap').replace('      ensureActive().flatMap', '      active().flatMap').replace('=> ensureActive().flatMap', '=> active().flatMap')
start=s.index('    begun <- if (!p.started)');end=s.index('\n  private def attempt(',start)
s=s[:start]+'''    done <- if (p.completed) Future.successful(Done) else {
      val begin = if (!p.started) write(StartSnapshotSplit(split.id))
        else if (p.attempts < 3) write(RetrySnapshotSplit(split.id, p.attempts + 1))
        else write(BlockSnapshotSplit(split.id, ExecutionFailure.BudgetExhausted)).map(_ => fail(ExecutionFailure.BudgetExhausted))
      begin.flatMap { begun =>
        val current = begun.splits.find(_.split.id == split.id).get
        val running = try attempt(begun.plan, current) catch { case NonFatal(e) => Future.failed(e) }
        running.recoverWith { case NonFatal(error) =>
          val failure = ExecutionFailure.from(error, "snapshot")
          if (!failure.releaseConfirmed) { unsafeRelease.set(true); releaseUnconfirmed(error) }
          if (cancelled()) Future.failed(error)
          else if (failure.releaseConfirmed && ExecutionFailure.Retryable(failure.code))
            org.apache.pekko.pattern.after(200.millis, system.classicSystem.scheduler)(runSplit(split))(ec)
          else write(BlockSnapshotSplit(split.id, failure.code)).flatMap(_ => Future.failed(error))
        }
      }
    }
  } yield done
''' +s[end:]
p.write_text(s)
p=root/'workflow/execution/ReliableExecutionControl.scala';s=p.read_text().replace('  def removeSession(', '  def isCancellationRequested: Boolean = cancelled.get()\n\n  def removeSession(')
s=s.replace('''          case None => Future.successful(Done)''','''          case None => Option(closeFailure.get()).fold[Future[Done]](Future.successful(Done))(Future.failed)''');p.write_text(s)
p=root/'workflow/execution/WorkflowExecutionEngine.scala';s=p.read_text().replace('      val ready = sink match {','      def ready: Future[Done] = sink match {').replace('runtimeOnLog, jdbcBlockingEc, closeEc).run())','runtimeOnLog, jdbcBlockingEc, closeEc, () => control.isCancellationRequested,\n          error => { control.closeFailure.compareAndSet(null, error); () }).run())');p.write_text(s)
p=root/'connectors/mysql/source/MySQLSnapshotSourceNode.scala';s=p.read_text()
s=s.replace('''        dataSource = createDataSource(config.host, config.port, config.database, config.username, config.password)
        connection = dataSource.getConnection
        val projection = resolveProjection(connection, config)
        val upperBound = maxPrimaryKey(connection, projection)''','''        dataSource = if (node.config.fields.contains("splitRows"))
          createSplitDataSource(config.host, config.port, config.database, config.username, config.password)
        else createDataSource(config.host, config.port, config.database, config.username, config.password)
        connection = dataSource.getConnection
        val projection = resolveProjection(connection, config)
        val upperBound = maxPrimaryKey(connection, projection, node.config.fields.contains("splitRows"))''')
s=s.replace('''      val ds = createDataSource(config.host, config.port, config.database, config.username, config.password)''','''      val ds = createSplitDataSource(config.host, config.port, config.database, config.username, config.password)''')
s=s.replace('''        val statement = connection.prepareStatement(sql)
        try {''','''        val statement = connection.prepareStatement(sql)
        statement.setQueryTimeout(30)
        try {''')
s=s.replace('''checkpoint.fold(0L)(_.batchSequence + 1L))''','''checkpoint.fold(0L)(_.batchSequence + 1L), splitMode = true)''')
pos=s.index('  protected[source] def createDataSource(')
s=s[:pos]+'''  protected[source] def createSplitDataSource(host: String, port: Int, database: String, username: String, password: String): HikariDataSource = {
    val config = new HikariConfig()
    config.setJdbcUrl(s"jdbc:mysql://$host:$port/$database?useSSL=false&allowPublicKeyRetrieval=true&connectionTimeZone=UTC&forceConnectionTimeZoneToSession=true&useCursorFetch=true&socketTimeout=30000&connectTimeout=5000")
    config.setUsername(username); config.setPassword(password); config.setDriverClassName("com.mysql.cj.jdbc.Driver")
    config.setMaximumPoolSize(1); config.setMinimumIdle(0); config.setConnectionTimeout(10000)
    new HikariDataSource(config)
  }

'''+s[pos:]
s=s.replace('''    sequence: Long
  ): BatchReader''','''    sequence: Long,
    splitMode: Boolean = false
  ): BatchReader''')
s=s.replace('''      dataSource = createDataSource(config.host, config.port, config.database, config.username, config.password)
      connection = dataSource.getConnection''','''      dataSource = if (splitMode) createSplitDataSource(config.host, config.port, config.database, config.username, config.password)
        else createDataSource(config.host, config.port, config.database, config.username, config.password)
      connection = dataSource.getConnection''')
s=s.replace('''  private def maxPrimaryKey(connection: Connection, projection: ResolvedProjection): Option[String] = {''','''  private def maxPrimaryKey(connection: Connection, projection: ResolvedProjection, bounded: Boolean = false): Option[String] = {''')
s=s.replace('''    val statement = connection.prepareStatement(s"SELECT MAX(${quote(projection.primaryKey)}) FROM ${quote(projection.table)}")
    try {''','''    val statement = connection.prepareStatement(s"SELECT MAX(${quote(projection.primaryKey)}) FROM ${quote(projection.table)}")
    if (bounded) statement.setQueryTimeout(30)
    try {''')
s=s.replace('''      val statement = connection.prepareStatement(sql)
      try {''','''      val statement = connection.prepareStatement(sql)
      if (cursorKind == cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.CursorKind) {
        statement.setQueryTimeout(30)
        statement.setFetchSize(math.min(config.chunkSize, 128))
      }
      try {''')
s=s.replace('''            encodedBytes += row.getBytes(java.nio.charset.StandardCharsets.UTF_8).length
            require(encodedBytes <= maxPageBytes, "snapshot page exceeds maxPageBytes; pagination must not change within an execution")''','''            if (maxPageBytes != Int.MaxValue) {
              encodedBytes += row.getBytes(java.nio.charset.StandardCharsets.UTF_8).length
              require(encodedBytes <= maxPageBytes, "snapshot page exceeds maxPageBytes; pagination must not change within an execution")
            }''')
p.write_text(s)
p=root/'connectors/mysql/sink/MySQLSinkNode.scala';s=p.read_text()
start=s.index('  override def commitBatch(');end=s.index('  protected[sink] def beforeLedgerClaim',start);block=s[start:end].replace('    } finally closeDataSource(dataSource)','''    } finally {
      if (batch.cursor.kind == cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.CursorKind) closeSplitResource(dataSource, batch.batchId)
      else closeDataSource(dataSource)
    }''');s=s[:start]+block+s[end:]
start=s.index('  private def commitCheckpointedBatch(');end=s.index('  private def findLedger(',start);block=s[start:end].replace('    } finally closeConnection(connection)','    } finally { if (split) closeSplitResource(connection, batch.batchId) else closeConnection(connection) }');s=s[:start]+block+s[end:]
pos=s.index('  private def findLedger(')
s=s[:pos]+'''  private def closeSplitResource(resource: AutoCloseable, batchId: String): Unit = if (resource != null) {
    try resource.close()
    catch { case NonFatal(error) => throw new cn.xuyinyin.magic.workflow.engine.CdcExecutionException(
      cn.xuyinyin.magic.workflow.engine.ExecutionFailure("local_release_unconfirmed", "snapshot-target-close", Some(batchId), releaseConfirmed = false), error) }
  }

'''+s[pos:];p.write_text(s)
# Keep test adapters on their H2 database while exercising real statement timeout configuration.
p=Path('server/src/test/scala/cn/xuyinyin/magic/connectors/mysql/source/MySQLSnapshotSourceNodeSpec.scala');s=p.read_text();idx=s.index('    val node = new MySQLSnapshotSourceNode {',s.index('  private final class H2Fixture'))+len('    val node = new MySQLSnapshotSourceNode {')
s=s[:idx]+'''
      override protected[source] def createSplitDataSource(host: String, port: Int, database: String, username: String, password: String): HikariDataSource = newDataSource()
'''+s[idx:];p.write_text(s)
p=Path('server/src/test/scala/cn/xuyinyin/magic/workflow/integration/RealMySQLSnapshotSplitProcess.scala');s=p.read_text();needle='''    val source = new MySQLSnapshotSourceNode {''';s=s.replace(needle,needle+'''
      override def createSplitDataSource(h: String, p: Int, d: String, u: String, pw: String): HikariDataSource = {
        val ds = super.createSplitDataSource(h, p, d, u, pw); pools.add(ds); ds
      }''');p.write_text(s)
