from pathlib import Path
root=Path('server/src/main/scala/cn/xuyinyin/magic')
p=root/'workflow/snapshot/SnapshotSplitState.scala'
s=p.read_text().replace('sealed trait SnapshotSplitUpdate extends CborSerializable','@com.fasterxml.jackson.annotation.JsonTypeInfo(use = com.fasterxml.jackson.annotation.JsonTypeInfo.Id.CLASS, property = "_type")\nsealed trait SnapshotSplitUpdate extends CborSerializable')
p.write_text(s)
p=root/'workflow/events/WorkflowEvents.scala';s=p.read_text().replace('  final case class ExecutionSkipped(','''  final case class SnapshotSplitsUpdated(executionId: String, update: cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitUpdate, timestamp: Long) extends WorkflowEvent
  final case class SnapshotExecutionPaused(executionId: String, reason: String, timestamp: Long) extends WorkflowEvent
  final case class ExecutionSkipped(''');p.write_text(s)
p=root/'workflow/execution/ReliableRunContext.scala';s=p.read_text().replace('checkpointCommitted: BatchCheckpoint => Future[Done]\n','checkpointCommitted: BatchCheckpoint => Future[Done],\n  splitContext: Option[SnapshotSplitRunContext] = None\n');s+='''
final case class SnapshotSplitRunContext(
  read: () => Future[Option[cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState]],
  update: cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitUpdate => Future[cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState]
)
''';p.write_text(s)
p=root/'workflow/actors/EventSourcedWorkflowActor.scala';s=p.read_text().replace('object EventSourcedWorkflowActor {','object EventSourcedWorkflowActor {\n  import cn.xuyinyin.magic.workflow.snapshot._\n  import cn.xuyinyin.magic.workflow.execution.SnapshotSplitRunContext')
s=s.replace('  final case class GetSummary(','''  final case class ReadSnapshotSplits(executionId: String, attemptId: String, replyTo: ActorRef[Reply]) extends Command
  final case class UpdateSnapshotSplits(executionId: String, attemptId: String, update: SnapshotSplitUpdate, replyTo: ActorRef[Reply]) extends Command
  final case class SnapshotSplitsRead(value: Option[SnapshotSplitState]) extends Reply
  final case class SnapshotSplitsStored(value: SnapshotSplitState) extends Reply
  final case class GetSummary(''')
s=s.replace('workflowSourceProgress: Option[WorkflowSourceProgress] = None\n','''workflowSourceProgress: Option[WorkflowSourceProgress] = None,
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_ABSENT)
    splitSnapshot: Option[SnapshotSplitState] = None
''')
s=s.replace('    case DefineWorkflow(_, _, replyTo) if', '''    case ReadSnapshotSplits(id, token, replyTo) =>
      if (token != activeAttemptId.get() || !state.currentExecution.exists(_.executionId == id)) rejectCheckpoint(replyTo, "stale snapshot execution")
      else immediate(replyTo, SnapshotSplitsRead(state.splitSnapshot))
    case UpdateSnapshotSplits(id, token, update, replyTo) =>
      if (token != activeAttemptId.get() || !state.currentExecution.exists(_.executionId == id)) rejectCheckpoint(replyTo, "stale snapshot execution")
      else {
        val validIdentity = update match {
          case CommitSnapshotPage(c, _) => c.batchId == BatchId.sha256(id, c.sourceNodeId, c.partitionId, c.batchSequence)
          case InitializeSnapshotSplits(p) => reliableSourceNodeId(state).contains(p.sourceNodeId)
          case _ => true
        }
        val next = if (validIdentity) scala.util.Try(SnapshotSplitState.advance(state.splitSnapshot, update)).toOption.flatten else None
        next match {
          case Some(value) => Effect.persist(SnapshotSplitsUpdated(id, update, now())).thenReply(replyTo)(_ => SnapshotSplitsStored(value))
          case None => rejectCheckpoint(replyTo, "snapshot split update rejected")
        }
      }
    case DefineWorkflow(_, _, replyTo) if''')
# Either is not Option; preserve safe rejection of malformed decimal values.
s=s.replace('scala.util.Try(SnapshotSplitState.advance(state.splitSnapshot, update)).toOption.flatten','scala.util.Try(SnapshotSplitState.advance(state.splitSnapshot, update)).toOption.flatMap(_.toOption)')
s=s.replace('      if (!result.success && recovery.eligible(state)) {','''      if (!result.success && decodeWorkflow(state).exists(executionEngine.supportsSplitSnapshot)) {
        releaseRecoveryGateAfter(Effect.persist(SnapshotExecutionPaused(executionId, result.failure.fold("snapshot_execution_failed")(_.code), now())), recoveryGate)
      } else if (!result.success && recovery.eligible(state)) {''')
s=s.replace('      if (recovery.eligible(state)) recovery.decide(state, failure)','''      if (decodeWorkflow(state).exists(executionEngine.supportsSplitSnapshot))
        releaseRecoveryGateAfter(Effect.persist(SnapshotExecutionPaused(executionId, failure.code, now())), recoveryGate)
      else if (recovery.eligible(state)) recovery.decide(state, failure)''')
s=s.replace('    case RecoverInterrupted(executionId) if state.currentExecution.exists(_.executionId == executionId) && recovery.eligible(state) =>','''    case RecoverInterrupted(executionId) if state.currentExecution.exists(_.executionId == executionId) && state.status.value == "snapshot_blocked" =>
      releaseRecoveryGateAfter(Effect.none, recoveryGate)
    case RecoverInterrupted(executionId) if state.currentExecution.exists(_.executionId == executionId) && recovery.eligible(state) =>''')
s=s.replace('case _: InitializeSnapshot | _: AdvanceCheckpoint | _: InitializeFromAttempt | _: CheckpointFromAttempt | _: EngineFinished | _: EngineCrashed => true','case _: ReadSnapshotSplits | _: UpdateSnapshotSplits | _: InitializeSnapshot | _: AdvanceCheckpoint | _: InitializeFromAttempt | _: CheckpointFromAttempt | _: EngineFinished | _: EngineCrashed => true')
# Add optional runtime-only bridge, leaving durable legacy value objects untouched.
needle='''        case other => scala.concurrent.Future.failed(new IllegalStateException(s"unexpected checkpoint reply: ${other.getClass.getSimpleName}"))
      }
    )'''
replacement='''        case other => scala.concurrent.Future.failed(new IllegalStateException(s"unexpected checkpoint reply: ${other.getClass.getSimpleName}"))
      },
      Some(SnapshotSplitRunContext(
        () => context.self.ask[Reply](r => ReadSnapshotSplits(execution.executionId, token, r)).flatMap {
          case SnapshotSplitsRead(value) => scala.concurrent.Future.successful(value)
          case _ => scala.concurrent.Future.failed(new CdcExecutionException(ExecutionFailure(ExecutionFailure.ProtocolConflict, "snapshot-read"), new IllegalStateException("snapshot read rejected")))
        },
        update => context.self.ask[Reply](r => UpdateSnapshotSplits(execution.executionId, token, update, r)).flatMap {
          case SnapshotSplitsStored(value) => scala.concurrent.Future.successful(value)
          case CheckpointRejected(_) => scala.concurrent.Future.failed(new CdcExecutionException(ExecutionFailure(ExecutionFailure.ProtocolConflict, "snapshot-journal"), new IllegalStateException("snapshot update explicitly rejected")))
          case _ => scala.concurrent.Future.failed(new IllegalStateException("unexpected snapshot update reply"))
        }
      ))
    )'''
assert needle in s;s=s.replace(needle,replacement);p.write_text(s)
p=root/'workflow/actors/WorkflowStateTransitions.scala';s=p.read_text().replace('    case ExecutionCompleted(','''    case SnapshotSplitsUpdated(id, update, _) => state.currentExecution match {
      case Some(c) if c.executionId == id => state.copy(splitSnapshot = Some(
        cn.xuyinyin.magic.workflow.snapshot.SnapshotSplitState.advance(state.splitSnapshot, update).fold(e => throw new IllegalStateException(e), identity)))
      case _ => state
    }
    case SnapshotExecutionPaused(id, _, _) => state.currentExecution match {
      case Some(c) if c.executionId == id => state.copy(status = WorkflowStatus("snapshot_blocked"))
      case _ => state
    }
    case ExecutionCompleted(''');s=s.replace('      currentExecution = Some(execution),','      currentExecution = Some(execution),\n      splitSnapshot = None,');s=s.replace('state.copy(status = status, currentExecution = None, recentExecutions', 'state.copy(status = status, currentExecution = None, splitSnapshot = None, recentExecutions');p.write_text(s)
