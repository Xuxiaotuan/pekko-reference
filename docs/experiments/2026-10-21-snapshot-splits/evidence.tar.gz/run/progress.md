# Single-table snapshot Split implementation
Base: 9881fa2; user authorizes implementation and real MySQL experiments, no commit/push.
1. RED/GREEN opt-in validation and durable split state contracts.
2. Keyset split discovery/read + per-split executor, durable retries and release gates.
3. Real MySQL Sink digest evidence; preserve legacy paths.
4. Real MySQL Actor Journal process-window tests + full field reconciliation.
5. Compatibility/full local/CDC regressions; evidence/source manifests and final review.
Scope: static source, single owner, bounded planning windows, no transforms, no cross-table scheduling.
State/source stage: first combined green 30 tests (5 new contracts/state, 24 snapshot including new range/resume, 1 legacy 18-fixture CBOR test). Contract RED was a real false-vs-true assertion; new model/source APIs initially failed compilation until wired. Preserve distinction.
Ruling: use windows of <=16 discovered actual-key ranges, process each window concurrently, retire completed windows only. Window barrier deliberately bounds out-of-order metadata.
Ruling: first step supports direct mysql.write only, no transforms or online source mutation; opt-in splitRows plus explicit quiescent contract.
First real matrix: 14/14 passed, 10 converged and 4 safe pauses; retain all artifacts, do not count pauses as convergence. Baseline initial fixture had PK remap collisions; two-stage remapping fixed the fixture, old setup-failure log retained.
Fresh review: five concerns (release-unknown admission, swallowed target close, unbounded JDBC read, completed-reply loss, driver buffering). One corrective pass with new RED cases, followed by full suite and real rerun.
Review corrections complete: 57 focused tests pass, including legacy 18 CBOR byte equality and new nonempty state CBOR. EOF_J_LOST real RED snapshot_blocked retained in target/snapshot-splits/*/failure.json, then real GREEN. Admission real RED 6 readers >2, then GREEN. Target/metadata close false-release and timeout=0 REDs then GREEN.
Frozen server/src + build manifest: 237 files in source-manifest.json. No source/test edits after formal run began.
Formal snapshot run: real-matrix-1792592417024368000.json exit 0, 20 tests, 14 converged/6 safe pauses. Paths in formal-folders.json, independent summary in snapshot-summary.json. Includes real Snapshot Store recovery, SLEEP timeout ~30 s then retry, STOP_T, 6 MiB wide value rejection and target-close observation failure.
Full backend: backend-full-verified-4g.log exit 0, 515/515, 88 suites. Prior 1 GiB runs (including ignored JVM_OPTS) were force-ended, retain logs; actual successful JVM verified -Xmx4g via -J flag. package.log exit 0; package-check.json verifies schema/runtime/old FQN/no tests in JAR.
Historical experiments: 181 files, all hashes unchanged. cdc-protected-source.json verifies 15 CDC/checkpoint/failure source files unchanged. Current branch and HEAD unchanged, no staging/commit/push.
Remaining: finish existing real CDC 27-case run (run-cdc.py session, cdc-regression.log); gather its new folders/dumps, package all experimental materials plus before/after frozen source and logs (exclude settings.json credentials), write README/result/verify/SHA256SUMS, run independent verifier and final diff/source/history checks. MySQL container pekko-cdc-stage-c-20261019 was initially stopped and started by this task; stop only after exports if no other processes remain. Do not remove databases/volumes.
