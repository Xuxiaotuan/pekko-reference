from pathlib import Path
import json,os,subprocess,re
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference');tmp=Path('/tmp/pekko-snapshot-splits-20261021');out=tmp/'sql';out.mkdir(exist_ok=True)
s=json.loads(tmp.joinpath('settings.json').read_text());env=os.environ.copy();env['MYSQL_PWD']=s['CDC_WINDOW_MYSQL_PASSWORD']
schemas={json.loads(p.read_text())['schema'] for p in (repo/'target/snapshot-splits').glob('*/environment.json')}
for schema in sorted(schemas):
 assert re.fullmatch('pekko_test_cdc_window_[a-f0-9]{12}',schema)
 f=out/(schema+'.sql')
 if f.exists():continue
 with f.open('wb') as stream:
  subprocess.run(['docker','exec','-e','MYSQL_PWD','pekko-cdc-stage-c-20261019','mysqldump','-u'+s['CDC_WINDOW_MYSQL_USER'],
   '--no-tablespaces','--set-gtid-purged=OFF','--hex-blob','--single-transaction','--routines','--triggers',schema],env=env,stdout=stream,check=True)
print('Snapshot experiment SQL dumps:',len(schemas))
