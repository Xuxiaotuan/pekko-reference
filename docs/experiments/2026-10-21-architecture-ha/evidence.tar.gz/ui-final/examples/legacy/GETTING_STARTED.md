# XXT-UI 快速开始指南

## 🎯 项目概述

XXT-UI 是 Pekko DataFusion Arrow 系统的前端展示层，提供可视化的系统管理和监控界面。

## 📦 安装步骤

### 1. 进入项目目录

```bash
cd xxt-ui
```

### 2. 安装依赖

```bash
npm install
```

这将安装所有必需的依赖包，包括：
- React 18
- TypeScript
- Vite
- Ant Design 5
- Axios
- React Router
- 等等...

### 3. 启动开发服务器

```bash
npm run dev
```

服务器将在 http://localhost:3000 启动

### 4. 构建生产版本（可选）

```bash
npm run build
```

## 🔧 配置说明

### 后端API地址配置

默认情况下，前端会将 `/api` 请求代理到 `http://localhost:8080`

如需修改后端地址，请编辑 `vite.config.ts`:

```typescript
export default defineConfig({
  server: {
    proxy: {
      '/api': {
        target: 'http://your-backend-url:port',  // 修改这里
        changeOrigin: true,
      },
    },
  },
})
```

## 🚀 功能模块

### 1. 仪表盘 (`/dashboard`)
- 系统状态总览
- 任务统计
- 集群信息
- 性能指标

### 2. SQL控制台 (`/sql`)
- SQL查询编辑
- 查询结果展示
- 查询历史（规划中）

### 3. 任务监控 (`/tasks`)
- 任务列表
- 任务状态
- 任务详情（规划中）

### 4. 集群状态 (`/cluster`)
- 节点信息
- 集群拓扑
- 资源监控（规划中）

### 5. DAG编辑器 (`/dag`)
- 可视化流程编排（规划中）
- 任务依赖管理（规划中）

## 📁 项目结构

```
xxt-ui/
├── public/                 # 静态资源
├── src/
│   ├── api/               # API客户端
│   │   ├── client.ts      # Axios配置
│   │   └── services.ts    # API服务定义
│   ├── components/        # 公共组件
│   │   └── Layout/
│   │       └── AppLayout.tsx  # 主布局组件
│   ├── pages/             # 页面组件
│   │   ├── Dashboard.tsx
│   │   ├── SQLConsole.tsx
│   │   ├── TaskMonitor.tsx
│   │   ├── ClusterStatus.tsx
│   │   └── DAGEditor.tsx
│   ├── types/             # TypeScript类型
│   │   └── index.ts
│   ├── App.tsx            # 根组件
│   ├── App.css            # 全局样式
│   ├── main.tsx           # 入口文件
│   └── index.css          # 基础样式
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

## 🔌 API集成

### 主要API端点

| 端点 | 方法 | 描述 |
|------|------|------|
| `/api/v1/status` | GET | API状态 |
| `/api/v1/tasks` | POST | 提交任务 |
| `/api/v1/tasks/statistics` | GET | 任务统计 |
| `/api/v1/tasks/{id}` | GET | 任务详情 |
| `/api/v1/cluster/status` | GET | 集群状态 |
| `/api/v1/sql/execute` | POST | 执行SQL |
| `/monitoring/metrics` | GET | 系统指标 |
| `/health` | GET | 健康检查 |

### API调用示例

```typescript
import { taskAPI } from '@/api/services'

// 获取任务统计
const stats = await taskAPI.getStatistics()

// 提交任务
const result = await taskAPI.submitTask({
  taskType: 'sql',
  sql: 'SELECT * FROM users'
})
```

## 🛠️ 开发指南

### 添加新页面

1. 在 `src/pages/` 下创建新组件
2. 在 `src/App.tsx` 中添加路由
3. 在 `src/components/Layout/AppLayout.tsx` 中添加菜单项

### 添加新API

1. 在 `src/types/index.ts` 中定义类型
2. 在 `src/api/services.ts` 中添加API方法
3. 在组件中使用

### 代码规范

- 使用 TypeScript 严格模式
- 遵循 ESLint 规则
- 使用 Prettier 格式化代码
- 组件使用函数式写法 + Hooks

运行代码检查：
```bash
npm run lint
```

格式化代码：
```bash
npm run format
```

## ⚠️ 注意事项

1. **依赖安装**: 首次运行前必须执行 `npm install`
2. **后端服务**: 确保后端服务（localhost:8080）已启动
3. **浏览器支持**: 建议使用最新版 Chrome/Firefox/Edge
4. **开发模式**: 开发时会自动热重载，无需手动刷新

## 🐛 常见问题

### 问题1: npm install 失败

**解决方案**:
```bash
# 清除缓存
npm cache clean --force

# 重新安装
npm install
```

### 问题2: API请求失败

**检查项**:
1. 后端服务是否运行
2. 后端地址配置是否正确
3. 浏览器控制台是否有CORS错误

### 问题3: 端口被占用

**解决方案**:
```bash
# 修改 vite.config.ts 中的端口
server: {
  port: 3001  // 改为其他端口
}
```

## 📚 参考资源

- [React官方文档](https://react.dev/)
- [Ant Design组件库](https://ant.design/)
- [Vite官方文档](https://vitejs.dev/)
- [TypeScript文档](https://www.typescriptlang.org/)

## 🤝 贡献指南

欢迎贡献代码！提交PR前请确保：
1. 代码通过lint检查
2. 添加必要的注释
3. 更新相关文档

## 📝 更新日志

### v0.1.0 (2024-11)
- ✅ 初始化项目结构
- ✅ 实现基础布局和路由
- ✅ 完成Dashboard页面
- ✅ 实现SQL Console基础版
- ✅ 添加API客户端和类型定义
