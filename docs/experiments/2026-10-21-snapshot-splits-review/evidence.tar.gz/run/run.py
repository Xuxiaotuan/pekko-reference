from pathlib import Path
import os,json,subprocess,time,sys
repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference')
s=json.loads(Path('/tmp/pekko-snapshot-review-20261021/settings.json').read_text())
env=os.environ.copy();env.update(s);env['RUN_MYSQL_SNAPSHOT_SPLITS']='1'
cp=(repo/'server/target/streams/test/fullClasspath/_global/streams/export').read_text().strip()
cmd=['/Users/xujiawei/Library/Java/JavaVirtualMachines/ms-17.0.14/Contents/Home/bin/java','-Duser.timezone=UTC','-Xmx1G','-cp',cp,'org.scalatest.tools.Runner','-o','-s','cn.xuyinyin.magic.workflow.integration.RealMySQLSnapshotSplitSpec']
name=sys.argv[1] if len(sys.argv)>1 else 'matrix'
if name!='matrix':cmd+=['-z',name]
p=Path('/tmp/pekko-snapshot-review-20261021')
start=time.time()
base='real-'+name
if p.joinpath(base+'.log').exists():base+='-'+str(time.time_ns())
with p.joinpath(base+'.log').open('w') as f:r=subprocess.run(cmd,env=env,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
p.joinpath(base+'.json').write_text(json.dumps(dict(exitCode=r.returncode,seconds=time.time()-start),indent=2))
print('Real snapshot runner:',name,'exit:',r.returncode)
sys.exit(r.returncode)
