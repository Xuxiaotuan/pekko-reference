from pathlib import Path
import base64,hashlib,io,json,os,subprocess,tarfile,zipfile

repo=Path('/Users/xujiawei/magic/scala-workbench/pekko-reference')
out=repo/'docs/experiments/2026-10-24-guardian-os-final-matrix'
old=repo/'docs/experiments/2026-10-24-guardian-os-restart'
raw=repo/'target/guardian-os-uniform-20261024'
private=Path('/Users/xujiawei/.local/share/pekko-experiments/guardian-os-20261024/private')
sha=lambda data:hashlib.sha256(data).hexdigest()
def save(name,value):(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
frozen=json.loads((out/'frozen-runtime.json').read_text())
runtime=repo/'target/guardian-os-runtimes'/frozen['runtime']
for name,digest in frozen['sourceManifest'].items():assert sha((repo/name).read_bytes())==digest,name
for name,digest in frozen['runtimeManifest'].items():assert sha((runtime/name).read_bytes())==digest,name
boundary=json.loads((old/'source-boundary.json').read_text())
for name,digest in boundary['preservedTrackedFiles'].items():assert sha((repo/name).read_bytes())==digest,name
for name,target in boundary['preservedSymlinks'].items():assert os.readlink(repo/name)==target
boundary['previousPublicMaterials']={str(p.relative_to(repo)):sha(p.read_bytes()) for p in sorted(old.rglob('*')) if p.is_file()}
save('source-boundary.json',boundary)
files={}
for p in sorted(raw.rglob('*')):
 if p.is_file():files['matrix/'+str(p.relative_to(raw))]=p.read_bytes()
for name in ['classes.jar','test-classes.jar','source.zip','source-manifest.json','runtime-manifest.json']:
 files['runtime/'+name]=(runtime/name).read_bytes()
for name in ['2026-10-24-guardian-os-restart','2026-10-23-supervisor-jvm-recovery','2026-10-22-table-scheduling']:
 files['verifiers/'+name+'/verify.py']=(out.parent/name/'verify.py').read_bytes()
for p in sorted(out.iterdir()):
 if p.suffix=='.log' or p.name.endswith('.log.0') or p.suffix=='.txt':files['logs/'+p.name]=p.read_bytes()
 if p.suffix=='.jsonl':files['actor/'+p.name]=p.read_bytes()
for name in ['actor-probe-runs.json','actor-sbt-thread-observations.json']:
 files['actor/'+name]=(out/name).read_bytes()
for name in ['resources-before.json','resources-after.json','resources-after-first.json','data-after-cleanup.json','data-after-cleanup-local-zone.json','post-cleanup-initial-comparison.json','machine-info.json','environment-recovery.json','matrix-exit.json','resource-verifier-red.json','resource-verifier-green.json','offline-verifier-revisions.json','verifier-initial.py']:
 files[name]=(out/name).read_bytes()
files['logs/final-build.log']=Path('/tmp/pekko-os-final-build.log').read_bytes()
files['sources/resources.py']=(out/'resources.py').read_bytes()
files['sources/verify.py']=(out/'verify.py').read_bytes()
files['sources/ActorShutdownProbe.scala']=(repo/'server/src/test/scala/cn/xuyinyin/magic/actor/ActorShutdownProbe.scala').read_bytes()
files['orchestration/package.py']=Path(__file__).read_bytes()
files['build/package.jar']=(repo/'server/target/scala-2.13/pekko-reference_2.13-0.1.jar').read_bytes()
for artifact,names in {
 'pekko-actor-testkit-typed_2.13-1.1.3-sources.jar':[
 'org/apache/pekko/actor/testkit/typed/scaladsl/ActorTestKit.scala',
 'org/apache/pekko/actor/testkit/typed/scaladsl/ScalaTestWithActorTestKit.scala',
 'org/apache/pekko/actor/testkit/typed/internal/TestProbeImpl.scala'],
 'pekko-actor_2.13-1.1.3-sources.jar':[
 'org/apache/pekko/actor/dungeon/Children.scala',
 'org/apache/pekko/actor/dungeon/ChildrenContainer.scala']}.items():
 p=next(Path('/Users/xujiawei/Library/Caches/Coursier').rglob(artifact))
 with zipfile.ZipFile(p) as z:
  for name in names:files['pekko-1.1.3/'+name]=z.read(name)
# Scan actual private values and nested class/source/J payloads, not just obvious labels.
secrets=[json.loads((private/'environment.json').read_text())['CDC_WINDOW_MYSQL_PASSWORD'].encode()]
for p in private.rglob('*.der'):
 data=p.read_bytes();secrets.extend([data,data[-32:]])
secrets={s for s in secrets if len(s)>=24}
patterns=set(secrets)|{base64.b64encode(s) for s in secrets}|{s.hex().encode() for s in secrets}|{s.hex().upper().encode() for s in secrets}
scanned=0
def scan(name,data):
 global scanned
 scanned+=1
 assert not any(p in data for p in patterns),'private value in '+name
 if name.endswith(('.jar','.zip')):
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   for n in z.namelist():
    if not n.endswith('/'):scan(name+'!'+n,z.read(n))
 elif name.endswith('.json'):
  def walk(v):
   if isinstance(v,dict):
    for k,x in v.items():
     if k=='payload_base64' and x:scan(name+'!CBOR',base64.b64decode(x))
     walk(x)
   elif isinstance(v,list):
    for x in v:walk(x)
  walk(json.loads(data))
for name,data in files.items():scan(name,data)
for p in out.iterdir():
 if p.is_file() and not p.name.startswith(('evidence.tar','archive-manifest','SHA256SUMS')):scan(p.name,p.read_bytes())
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz',compresslevel=6) as tar:
 for name,data in sorted(files.items()):
  member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;tar.addfile(member,io.BytesIO(data))
blob=buffer.getvalue();(out/'evidence.tar.gz').write_bytes(blob)
save('archive-manifest.json',{'archiveSha256':sha(blob),'bytes':len(blob),'files':{n:sha(v) for n,v in sorted(files.items())},'credentialEntriesScanned':scanned})
save('result.json',{'baseline':boundary['baseline'],'runtime':frozen['runtime'],'run':'matrix-1792851871492514517',
 'sameVersionFullMatrix':'passed','acceptedCases':12,'converged':8,'safePause':4,'rows':80,'fieldValues':480,
 'postCleanupDataUnchangedCases':12,'D':'N/A','physicalResourceExitConfirmed':True,'allLogicalRecordsCleared':False,
 'backend':{'testsSucceeded':586,'failed':0,'suitesCompleted':111,'aborted':0,'package':True},
 'actorSpec':{'standalonePassed':True,'wholeSuitePassed':True,'originalTimeoutReproducedThisRound':False,'originalTestModified':False,'exactOldTrigger':'not established','diagnosisStatus':'evidence_incomplete'},
 'productionGuardianRestartImplemented':False,'productionProtocolChanged':False,'committed':False,'pushed':False,
 'previousFailureArchive':'../2026-10-24-guardian-os-restart/README.md','archiveBytes':len(blob),'archiveEntries':len(files)})
checksum_names=sorted(p for p in out.iterdir() if p.is_file() and p.name not in ('SHA256SUMS','verification-result.json','verification-historical.json','verification-console.log'))
(out/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in checksum_names))
print(json.dumps({'archiveBytes':len(blob),'entries':len(files),'scanned':scanned}))
