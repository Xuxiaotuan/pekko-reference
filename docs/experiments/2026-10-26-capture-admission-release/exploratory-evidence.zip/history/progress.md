# A0/B0 execution ledger — plan: docs/development/plans/2026-10-26-capture-admission-and-release.md
Scope: test facilities and real isolated MySQL probes only; no production protocol, commit or push.
Ruling: work in existing feature checkout; only prior untracked plan existed. Do not create another checkout or alter Git configuration.
Ruling: user continuation authorizes A0/B0 probes and isolated fixture writes; the plan text saying no database authorization describes its previous authoring turn.
Ruling: no factory/provider dependency change; extend existing Debezium real builder in Test only.
Verifier: six negative unit tests observed RED (missing verifier), then GREEN; original logs retained.
Build: two initial Test compile attempts passed; dependency suite 2/2. Final build removes only probe warnings.
Preflight: source/state distinct UUIDs verified over leased TCP slot a; no other user connection/transaction before execution.
Production A1/A2/B1 remain unstarted until actual A0/B0 results are reviewed.
