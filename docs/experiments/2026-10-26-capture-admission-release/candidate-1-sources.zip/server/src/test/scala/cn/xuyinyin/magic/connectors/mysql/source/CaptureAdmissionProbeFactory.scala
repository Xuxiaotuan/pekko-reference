package cn.xuyinyin.magic.connectors.mysql.source

import io.debezium.embedded.Connect
import io.debezium.engine.{DebeziumEngine, RecordChangeEvent}
import io.debezium.engine.format.ChangeEventFormat
import org.apache.kafka.connect.source.SourceRecord
import spray.json._
import java.util.Properties
import scala.jdk.CollectionConverters._

/** Test-only observation. All records and original committers pass through unchanged. */
final class CaptureAdmissionProbeFactory(heartbeatMillis: Int, emit: (String, JsObject) => Unit)
  extends DebeziumEngineFactory {
  override def create(props: Properties): DebeziumEngineAccess = {
    props.setProperty("heartbeat.interval.ms", heartbeatMillis.toString)
    emit("EFFECTIVE_CONFIG", JsObject("heartbeatMillis" -> JsNumber(heartbeatMillis),
      "snapshotMode" -> JsString(props.getProperty("snapshot.mode")),
      "batchSize" -> JsString(props.getProperty("max.batch.size"))))
    new RealDebeziumEngineAccess(props, (consumer, completion) => {
      val observed = new DebeziumEngine.ChangeConsumer[RecordChangeEvent[SourceRecord]] {
        override def supportsTombstoneEvents(): Boolean = true
        override def handleBatch(records: java.util.List[RecordChangeEvent[SourceRecord]],
          committer: DebeziumEngine.RecordCommitter[RecordChangeEvent[SourceRecord]]): Unit = {
          records.asScala.foreach { e =>
            val r = e.record()
            emit("ORIGINAL_RECORD", JsObject("schema" -> JsString(Option(r.valueSchema()).map(_.name()).getOrElse("null")),
              "offset" -> MySQLCdcSourceNode.cursorValue(r).parseJson,
              "value" -> JsString(String.valueOf(r.value()))))
          }
          consumer.handleBatch(records, committer)
          emit("ORIGINAL_CALLBACK_RETURNED", JsObject())
        }
      }
      val lifecycle = new DebeziumEngine.ConnectorCallback {
        override def connectorStarted(): Unit = emit("CONNECTOR_STARTED", JsObject())
        override def taskStarted(): Unit = emit("TASK_STARTED", JsObject())
        override def pollingStarted(): Unit = emit("POLLING_STARTED", JsObject())
        override def pollingStopped(): Unit = emit("POLLING_STOPPED", JsObject())
        override def taskStopped(): Unit = emit("TASK_STOPPED", JsObject())
        override def connectorStopped(): Unit = emit("CONNECTOR_STOPPED", JsObject())
      }
      DebeziumEngine.create[SourceRecord, Connect](ChangeEventFormat.of[Connect](classOf[Connect]))
        .using(props).using(completion).using(lifecycle).notifying(observed).build()
    })
  }
}
