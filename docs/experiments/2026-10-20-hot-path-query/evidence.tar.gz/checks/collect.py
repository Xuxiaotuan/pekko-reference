from pathlib import Path
import json,re,subprocess,os,hashlib,tarfile,io
repo=Path.cwd();tmp=Path('/tmp/pekko-deep-20261020');root=repo/'docs/experiments/2026-10-20-hot-path-query'
sha=lambda data:hashlib.sha256(data).hexdigest()
settings=json.loads((tmp/'settings.json').read_text())
assert json.loads((tmp/'real-run.json').read_text())['exitCode']==0
frozen=json.loads((tmp/'run-source-manifest.json').read_text());assert all(sha((repo/p).read_bytes())==h for p,h in frozen.items())
protected=json.loads((tmp/'protected-experiments.json').read_text());assert all(sha((repo/p).read_bytes())==h for p,h in protected.items())
text=(tmp/'real-ten.log').read_text()
runs=dict(re.findall(r'CDC_RECOVERY_WINDOW_OBSERVED scenario=(\w+) evidence=(\S+)',text));assert len(runs)==8
sessions=dict(re.findall(r'CDC_SESSION_RELEASE_OBSERVED fault=([\w-]+) evidence=(\S+)',text));assert set(sessions)=={'none','cancel-T'}
files={};records=[]
for case,folder in list(runs.items())+[("sessions/"+k,v) for k,v in sessions.items()]:
 p=Path(folder);schema=json.loads((p/('outcome.json' if case.startswith('sessions/') else 'environment.json')).read_text())['schema']
 if not (p/'database-final.sql').exists():
  env=os.environ.copy();env['MYSQL_PWD']=settings['CDC_WINDOW_MYSQL_PASSWORD']
  dump=subprocess.run(['docker','exec','-e','MYSQL_PWD','pekko-cdc-stage-c-20261019','mysqldump','-uroot','--single-transaction','--hex-blob','--set-gtid-purged=OFF','--skip-comments',schema],env=env,capture_output=True)
  assert dump.returncode==0,'dump failed for '+schema
  (p/'database-final.sql').write_bytes(dump.stdout)
 for f in p.iterdir():
  if f.is_file():files[case+'/'+f.name]=f.read_bytes()
 records.append(dict(scenario=case,runDirectory=p.name,schema=schema))
for name in ['red-final.log','red-statement-count.log','green.log','focused-final.log','focused-latest.log','full-module.log','real-ten.log','ui-test.log','ui-build.log','package.log','dependency.json','package.json','real-run.json','protected-experiments.json','run-real.py','collect.py']:
 files['checks/'+name]=(tmp/name).read_bytes()
for name in ['build.sbt','MySQLCdcApplySinkNode.scala','WorkflowQueryService.scala']:files['before/'+name]=(tmp/name).read_bytes()
for rel,h in frozen.items():files['source/'+rel]=(repo/rel).read_bytes()
for rel in ['README.md','docs/CODE_STRUCTURE.md','docs/CONFIGURATION.md']:files['source/'+rel]=(repo/rel).read_bytes()
base=(tmp/'base-head.txt').read_text().strip()
protectedProtocol=[]
for folder in ['actors','events','checkpoint','engine','nodes/cdc','nodes/sources']:
 for p in (repo/'pekko-server/src/main/scala/cn/xuyinyin/magic/workflow'/folder).rglob('*.scala'):
  rel=str(p.relative_to(repo));old=subprocess.check_output(['git','show',base+':'+rel]);assert old==p.read_bytes(),rel
  protectedProtocol.append(rel)
source=dict(baseCommit=base,sourceSha256=frozen,unchangedProtocolFiles=protectedProtocol,unchangedProtocolFileCount=len(protectedProtocol),scope='Bounded query service, transaction-local statement reuse, Protobuf alignment; event identity and T/J/ACK protocol retained')
(root/'source-manifest.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
meta=json.loads(subprocess.check_output(['docker','inspect','pekko-cdc-stage-c-20261019']))[0]
run=dict(date='2026-10-20',java='Microsoft OpenJDK 17.0.14',pekko='1.1.3',debezium='3.6.1.Final',protobuf='4.33.4',container='pekko-cdc-stage-c-20261019',image=meta['Image'],arguments=meta['Config']['Cmd'],formalRuns=records,executionResult=json.loads((tmp/'real-run.json').read_text()),testBoundary='Default test excludes ExternalIntegration; formal ten cases ran explicitly through Test Classpath; no staged-distribution deployment claimed')
(root/'run-manifest.json').write_text(json.dumps(run,ensure_ascii=False,indent=2)+'\n')
focused=(tmp/'focused-latest.log').read_text();full=(tmp/'full-module.log').read_text()
assert 'Tests: succeeded 67, failed 0' in focused and 'Tests: succeeded 462, failed 0' in full
assert 'Suites: completed 76, aborted 0' in full
validation=dict(focusedTests=67,focusedSuites=8,defaultModule=dict(passed=462,failed=0,abortedSuites=0,exitCode=0,gate='PASS',scope='Local default test gate, excludes ExternalIntegration'),ui=dict(tests=5,build='PASS',browserE2E='not rerun; no UI production source changes'),formalRealCases=10,convergedWindows=7,knownRecoveryFailure='C2 FAIL_TERMINAL',realReleaseCases=2,protectedHistoricalFiles=len(protected),protectedMismatches=[],package=json.loads((tmp/'package.json').read_text()),efficiency=dict(layer='H2 Connection.prepareStatement calls',events=64,targetBefore=64,targetAfter=1,groupSelectAfter=1,groupInsertAfter=1,notMeasured=['MySQL roundtrip reduction','throughput speedup','700k-task capacity']))
(root/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
for name in ['source-manifest.json','run-manifest.json','validation.json']:files[name]=(root/name).read_bytes()
for name,data in files.items():assert settings['CDC_WINDOW_MYSQL_PASSWORD'].encode() not in data,name
inner=json.dumps(dict(files={name:sha(data) for name,data in files.items()}),ensure_ascii=False,indent=2).encode()
with tarfile.open(root/'evidence.tar.gz','w:gz') as archive:
 for name,data in list(files.items())+[('manifest.json',inner)]:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archiveMembers=len(files)+1,archiveBytes=(root/'evidence.tar.gz').stat().st_size,protectedFiles=len(protected),unchangedProtocolFiles=len(protectedProtocol))))
